"""业务逻辑：问诊闭环、学工台账、辅导员看板、报告与留痕。

所有面向页面/JSON 的结构都在本模块组装，HTTP 层只负责路由与响应。
"""
from __future__ import annotations

import json
import re
import secrets
import sqlite3
import threading
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from typing import Any

from . import ai_engine, config, database, seed_data
from .database import GENESIS_HASH, chain_hash, json_load
from .errors import AppError, bad_request, forbidden, not_found, unauthorized
from .security import (
    hash_password,
    new_csrf_token,
    new_session_token,
    token_digest,
    verify_password,
)

_LOGIN_FAILURES: dict[str, list[float]] = {}
_LOGIN_LOCK = threading.Lock()
_LOGIN_WINDOW = 300
_LOGIN_MAX = 8

INTENT_ORDER = ai_engine.INTENTS
STATUSES = ["待跟进", "跟进中", "已闭环"]
COLLEGE = "信息工程学院"


# ---------------------------------------------------------------------------
# 通用工具
# ---------------------------------------------------------------------------
def _now() -> datetime:
    return datetime.now().astimezone()


def _iso(moment: datetime) -> str:
    return moment.isoformat(timespec="seconds")


def _today() -> str:
    return _now().strftime("%Y-%m-%d")


def _clean_period(days: Any) -> int:
    try:
        value = int(days)
    except (TypeError, ValueError):
        return 14
    return value if value in {7, 14, 30, 90} else 14


def _pct(part: float, total: float) -> int:
    if not total:
        return 0
    return int(round(part / total * 100))


def _md(value: str | None) -> str:
    dt = database.parse_iso(value)
    return dt.strftime("%m-%d") if dt else ""


def _dt_text(value: str | None, with_time: bool = True) -> str:
    dt = database.parse_iso(value)
    if not dt:
        return ""
    return dt.strftime("%Y-%m-%d %H:%M" if with_time else "%Y-%m-%d")


def _user_row(connection: sqlite3.Connection, user_id: int) -> sqlite3.Row | None:
    return connection.execute(
        """SELECT u.*, c.name AS class_name, c.major AS class_major, c.grade AS class_grade
           FROM users u LEFT JOIN classes c ON c.id = u.class_id WHERE u.id = ?""",
        (user_id,),
    ).fetchone()


def user_public(row: sqlite3.Row | dict) -> dict[str, Any]:
    data = dict(row)
    tags = json_load(data.get("tags"), [])
    return {
        "id": data["id"],
        "username": data["username"],
        "name": data["name"],
        "role": data["role"],
        "student_no": data.get("student_no") or "",
        "class_id": data.get("class_id"),
        "class_name": data.get("class_name") or "",
        "major": data.get("major") or data.get("class_major") or "",
        "grade": data.get("class_grade") or "",
        "email": data.get("email") or "",
        "phone": data.get("phone") or "",
        "avatar": (data.get("name") or "?")[:1],
        "tags": tags if isinstance(tags, list) else [],
        "last_login_at": data.get("last_login_at"),
    }


def require_role(user: dict, role: str | None = None) -> None:
    if role and user["role"] != role:
        raise forbidden("当前角色无权访问该功能")


def _owned_class_ids(connection: sqlite3.Connection, user: dict) -> list[int]:
    rows = connection.execute(
        "SELECT id FROM classes WHERE counselor_id = ? ORDER BY id", (user["id"],)
    ).fetchall()
    return [row["id"] for row in rows]


def _ensure_class_access(connection: sqlite3.Connection, user: dict, class_id: int) -> None:
    if user["role"] == "counselor":
        if class_id not in _owned_class_ids(connection, user):
            raise forbidden("只能查看自己所辖班级的数据")
    elif user.get("class_id") != class_id:
        raise forbidden("只能查看本班级数据")


def _ensure_student_access(connection: sqlite3.Connection, user: dict, student_row: sqlite3.Row) -> None:
    if user["role"] == "student" and student_row["id"] != user["id"]:
        raise forbidden("只能查看本人的学情数据")
    if user["role"] == "counselor":
        _ensure_class_access(connection, user, student_row["class_id"])


# ---------------------------------------------------------------------------
# 认证
# ---------------------------------------------------------------------------
def login(username: str, password: str, ip: str) -> tuple[str, str, dict]:
    username = (username or "").strip()
    if not username or not password:
        raise bad_request("请输入账号与密码")
    key = f"{ip}|{username.lower()}"
    now = _now().timestamp()
    with _LOGIN_LOCK:
        attempts = [item for item in _LOGIN_FAILURES.get(key, []) if now - item < _LOGIN_WINDOW]
        _LOGIN_FAILURES[key] = attempts
        if len(attempts) >= _LOGIN_MAX:
            raise AppError(429, "TOO_MANY_ATTEMPTS", "尝试次数过多，请 5 分钟后再试")

    with database.db() as connection:
        row = connection.execute(
            """SELECT u.*, c.name AS class_name, c.major AS class_major, c.grade AS class_grade
               FROM users u LEFT JOIN classes c ON c.id = u.class_id
               WHERE u.username = ? COLLATE NOCASE""",
            (username,),
        ).fetchone()
        if not row or not verify_password(password, row["password_hash"]):
            with _LOGIN_LOCK:
                _LOGIN_FAILURES.setdefault(key, []).append(now)
            raise unauthorized("账号或密码不正确")
        token = new_session_token()
        csrf = new_csrf_token()
        created = _now()
        expires = created + timedelta(days=config.SESSION_DAYS)
        connection.execute(
            "INSERT INTO sessions(token_hash, user_id, csrf_token, created_at, expires_at) VALUES (?, ?, ?, ?, ?)",
            (token_digest(token), row["id"], csrf, _iso(created), _iso(expires)),
        )
        connection.execute("UPDATE users SET last_login_at = ? WHERE id = ?", (_iso(created), row["id"]))
        with _LOGIN_LOCK:
            _LOGIN_FAILURES.pop(key, None)
        database.append_audit(
            connection,
            actor=row["name"],
            actor_id=row["id"],
            action="登录平台",
            target=row["username"],
            detail="学生端" if row["role"] == "student" else "辅导员工作台",
            at=_iso(created),
        )
        user = user_public(row)
    return token, csrf, user


def get_session(token: str | None) -> dict[str, Any] | None:
    if not token:
        return None
    digest = token_digest(token)
    with database.db() as connection:
        row = connection.execute(
            """SELECT s.csrf_token, s.expires_at,
                      u.*, c.name AS class_name, c.major AS class_major, c.grade AS class_grade
               FROM sessions s
               JOIN users u ON u.id = s.user_id
               LEFT JOIN classes c ON c.id = u.class_id
               WHERE s.token_hash = ?""",
            (digest,),
        ).fetchone()
        if not row:
            return None
        expires = database.parse_iso(row["expires_at"])
        if not expires or expires < _now():
            connection.execute("DELETE FROM sessions WHERE token_hash = ?", (digest,))
            return None
        return {"user": user_public(row), "csrf": row["csrf_token"], "token": token}


def logout(token: str | None) -> None:
    if not token:
        return
    with database.db() as connection:
        connection.execute("DELETE FROM sessions WHERE token_hash = ?", (token_digest(token),))


# ---------------------------------------------------------------------------
# 元数据
# ---------------------------------------------------------------------------
def meta(user: dict) -> dict[str, Any]:
    with database.db() as connection:
        class_rows = connection.execute(
            "SELECT c.*, (SELECT COUNT(*) FROM users u WHERE u.class_id = c.id AND u.role='student') AS student_count "
            "FROM classes c ORDER BY c.id"
        ).fetchall()
        if user["role"] == "counselor":
            classes = [
                {
                    "id": row["id"],
                    "name": row["name"],
                    "major": row["major"],
                    "grade": row["grade"],
                    "student_count": row["student_count"],
                    "selected": row["id"] == user.get("class_id"),
                }
                for row in class_rows
                if row["counselor_id"] == user["id"]
            ]
        else:
            classes = [
                {
                    "id": row["id"],
                    "name": row["name"],
                    "major": row["major"],
                    "grade": row["grade"],
                    "student_count": row["student_count"],
                    "selected": row["id"] == user.get("class_id"),
                }
                for row in class_rows
                if row["id"] == user.get("class_id")
            ]
        courses = [
            row["course"]
            for row in connection.execute(
                "SELECT DISTINCT course FROM knowledge_points ORDER BY course"
            )
        ]
        courses.sort(key=lambda item: (
            seed_data.COURSE_ORDER.index(item) if item in seed_data.COURSE_ORDER else 99
        ))
        types = [
            row["type"] for row in connection.execute(
                "SELECT type, COUNT(*) AS n FROM resources GROUP BY type ORDER BY n DESC"
            )
        ]
        types.sort(key=lambda item: (
            seed_data.RESOURCE_TYPES.index(item) if item in seed_data.RESOURCE_TYPES else 99
        ))
    return {
        "courses": courses,
        "classes": classes,
        "resource_types": types,
        "intents": INTENT_ORDER,
        "statuses": STATUSES,
        "ai": ai_engine.agent_status(),
        "app": {"name": config.APP_NAME, "version": config.APP_VERSION, "college": COLLEGE},
    }


# ---------------------------------------------------------------------------
# 诊断结果序列化
# ---------------------------------------------------------------------------
def _diagnosis_public(row: sqlite3.Row | dict) -> dict[str, Any]:
    data = dict(row)
    return {
        "id": data["id"],
        "public_id": data["public_id"],
        "student_id": data["student_id"],
        "class_id": data["class_id"],
        "question": data["question"],
        "course": data["course"],
        "intent": data["intent"],
        "intent_confidence": data["intent_confidence"],
        "difficulty": data["difficulty"],
        "mastery": data["mastery"],
        "weak_points": json_load(data["weak_points"], []),
        "misconceptions": json_load(data["misconceptions"], []),
        "ability_gaps": json_load(data["ability_gaps"], []),
        "tags": json_load(data["tags"], []),
        "summary": data["summary"],
        "structured": json_load(data["structured"], {}),
        "ai_mode": data["ai_mode"],
        "duration_ms": data["duration_ms"],
        "created_at": data["created_at"],
        "created_text": _dt_text(data["created_at"]),
        "student_name": data.get("student_name") or "",
        "student_no": data.get("student_no") or "",
        "class_name": data.get("class_name") or "",
    }


def _resource_public(row: sqlite3.Row | dict, learned: bool = False) -> dict[str, Any]:
    data = dict(row)
    return {
        "id": data["id"],
        "title": data["title"],
        "type": data["type"],
        "course": data["course"],
        "kp_ids": json_load(data.get("kp_ids"), []),
        "level": data["level"],
        "minutes": data["minutes"],
        "summary": data["summary"],
        "source": data["source"] if "source" in data else "校本知识库",
        "learned": learned,
    }


def _ledger_public(row: sqlite3.Row | dict) -> dict[str, Any]:
    data = dict(row)
    return {
        "id": data["id"],
        "code": data["code"],
        "seq": data["seq"],
        "diagnosis_id": data["diagnosis_id"],
        "student_id": data["student_id"],
        "student_name": data.get("student_name") or "",
        "student_no": data.get("student_no") or "",
        "class_id": data["class_id"],
        "class_name": data.get("class_name") or "",
        "course": data.get("course") or "",
        "intent": data.get("intent") or "",
        "problem": data["problem"],
        "diagnosis_summary": data["diagnosis_summary"],
        "weak_points": json_load(data["weak_points"], []),
        "weak_point_names": [
            item.get("name") for item in json_load(data["weak_points"], []) if isinstance(item, dict)
        ],
        "resource_summary": data["resource_summary"],
        "help_time": data["help_time"],
        "help_date": _dt_text(data["help_time"], with_time=False),
        "help_text": _dt_text(data["help_time"]),
        "status": data["status"],
        "follow_up": data["follow_up"],
        "suggestion": data["suggestion"],
        "created_at": data["created_at"],
        "updated_at": data["updated_at"],
        "hash": data["hash"],
        "prev_hash": data["prev_hash"],
        "hash_short": data["hash"][:16],
        "mastery": data.get("mastery"),
        "difficulty": data.get("difficulty"),
    }


# ---------------------------------------------------------------------------
# 学生端
# ---------------------------------------------------------------------------
def _all_diagnoses(connection: sqlite3.Connection, student_id: int) -> list[sqlite3.Row]:
    return connection.execute(
        """SELECT d.*, u.name AS student_name, u.student_no, c.name AS class_name
           FROM diagnoses d JOIN users u ON u.id = d.student_id
           JOIN classes c ON c.id = d.class_id
           WHERE d.student_id = ? ORDER BY d.created_at DESC, d.id DESC""",
        (student_id,),
    ).fetchall()


def _aggregate_weak(rows: list[dict]) -> list[dict]:
    bucket: dict[str, dict] = {}
    for row in rows:
        for item in json_load(row.get("weak_points"), []):
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or "").strip()
            if not name:
                continue
            entry = bucket.setdefault(name, {
                "name": name,
                "course": item.get("course") or row.get("course") or "",
                "count": 0,
                "mastery_sum": 0,
            })
            entry["count"] += 1
            entry["mastery_sum"] += int(item.get("mastery") or 0)
    result = []
    for entry in bucket.values():
        result.append({
            "name": entry["name"],
            "course": entry["course"],
            "count": entry["count"],
            "mastery": int(round(entry["mastery_sum"] / max(entry["count"], 1))),
        })
    result.sort(key=lambda item: (-item["count"], item["mastery"]))
    return result


def _aggregate_abilities(rows: list[dict]) -> list[dict]:
    bucket: dict[str, list[int]] = defaultdict(list)
    notes: dict[str, str] = {}
    for row in rows:
        for item in json_load(row.get("ability_gaps"), []):
            if isinstance(item, dict) and item.get("name"):
                bucket[item["name"]].append(int(item.get("score") or 0))
                notes.setdefault(item["name"], str(item.get("note") or ""))
    result = [
        {"name": name, "score": int(round(sum(values) / len(values))), "note": notes.get(name, "")}
        for name, values in bucket.items()
        if values
    ]
    result.sort(key=lambda item: item["score"])
    return result


def _intent_dist(rows: list[dict]) -> list[dict]:
    counter = Counter(row["intent"] for row in rows)
    return [
        {"label": label, "count": counter.get(label, 0), "pct": _pct(counter.get(label, 0), len(rows))}
        for label in INTENT_ORDER
    ]


def _course_dist(rows: list[dict]) -> list[dict]:
    counter = Counter(row["course"] for row in rows)
    return [
        {"label": label, "count": count, "pct": _pct(count, len(rows))}
        for label, count in counter.most_common()
    ]


def _streak_days(rows: list[dict]) -> int:
    days = {row["created_at"][:10] for row in rows if row.get("created_at")}
    if not days:
        return 0
    streak = 0
    cursor = _now().date()
    if cursor.isoformat() not in days:
        cursor -= timedelta(days=1)
    while cursor.isoformat() in days:
        streak += 1
        cursor -= timedelta(days=1)
    return streak


def _diagnosis_summaries(rows: list[dict]) -> list[dict]:
    return [
        {
            "id": row["id"],
            "public_id": row["public_id"],
            "course": row["course"],
            "intent": row["intent"],
            "mastery": row["mastery"],
            "difficulty": row["difficulty"],
            "created_at": row["created_at"],
            "created_text": _dt_text(row["created_at"]),
            "weak_names": [
                item.get("name") for item in json_load(row["weak_points"], []) if isinstance(item, dict)
            ],
        }
        for row in rows
    ]


def student_overview(user: dict) -> dict[str, Any]:
    with database.db() as connection:
        student = _user_row(connection, user["id"])
        if not student:
            raise not_found("学生信息不存在")
        rows = [dict(row) for row in _all_diagnoses(connection, user["id"])]
        ledgers = [dict(row) for row in connection.execute(
            "SELECT * FROM ledgers WHERE student_id = ? ORDER BY help_time DESC", (user["id"],)
        )]
        learned = [dict(row) for row in connection.execute(
            """SELECT r.*, lr.completed_at, lr.created_at AS learned_at
               FROM learning_records lr JOIN resources r ON r.id = lr.resource_id
               WHERE lr.student_id = ? AND lr.status = 'completed'
               ORDER BY lr.created_at DESC""",
            (user["id"],),
        )]
        counselor = connection.execute(
            "SELECT u.name, u.email FROM users u JOIN classes c ON c.counselor_id = u.id WHERE c.id = ?",
            (user["class_id"],),
        ).fetchone() if user["class_id"] else None

    avg_mastery = int(round(sum(row["mastery"] for row in rows) / len(rows))) if rows else 0
    pending = sum(1 for row in ledgers if row["status"] != "已闭环")
    closed = sum(1 for row in ledgers if row["status"] == "已闭环")
    weak = _aggregate_weak(rows)
    recent = rows[:5]
    trend_rows = list(reversed(rows[:10]))
    recommendations: list[dict] = []
    learned_ids = {row["id"] for row in learned}
    with database.db() as connection:
        resources = [dict(row) for row in connection.execute(
            "SELECT * FROM resources ORDER BY id"
        )]
    if weak:
        recs = ai_engine.recommend_resources(
            rows[0]["intent"] if rows else "知识点不会",
            weak[0]["course"] if weak else "",
            [item["name"] for item in weak[:3]],
            avg_mastery or 60,
            resources,
        )
    else:
        general = [item for item in resources if item["course"] == "通用能力"][:4]
        recs = [
            {**item, "reason": "尚未产生诊断记录，先用通用学习策略建立节奏。", "relevance": 0.6}
            for item in general
        ]
    recommendations = [
        {**_resource_public(item), "reason": item["reason"], "relevance": item["relevance"],
         "learned": item["id"] in learned_ids}
        for item in recs[:4]
    ]

    return {
        "profile": {**user_public(student), "counselor_name": counselor["name"] if counselor else ""},
        "class": {
            "id": student["class_id"],
            "name": student["class_name"] or "",
            "major": student["class_major"] or "",
            "grade": student["class_grade"] or "",
        },
        "stats": {
            "diagnoses": len(rows),
            "courses": len({row["course"] for row in rows}),
            "avg_mastery": avg_mastery,
            "learned": len(learned),
            "pending": pending,
            "closed": closed,
            "streak": _streak_days(rows),
            "closure_rate": _pct(closed, len(ledgers)),
        },
        "trend": [
            {"date": _md(row["created_at"]), "mastery": row["mastery"], "course": row["course"]}
            for row in trend_rows
        ],
        "abilities": _aggregate_abilities(rows),
        "intent_dist": _intent_dist(rows),
        "weak_points": weak[:6],
        "recent": _diagnosis_summaries(recent),
        "recommendations": recommendations,
        "learned": [
            {**_resource_public(row), "learned": True, "learned_at": row.get("learned_at")}
            for row in learned[:4]
        ],
    }


def create_diagnosis(user: dict, question: str, when: datetime | None = None) -> dict[str, Any]:
    require_role(user, "student")
    question = re.sub(r"\s+", " ", (question or "")).strip()
    if len(question) < 6:
        raise bad_request("请多描述一点你的学习困惑，至少 6 个字")
    if len(question) > config.MAX_QUESTION_CHARS:
        raise bad_request(f"问题过长，请控制在 {config.MAX_QUESTION_CHARS} 字以内")
    when = when or _now()
    analysis = ai_engine.analyze(question)
    weak_json = json.dumps(analysis["weak_points"], ensure_ascii=False)

    with database.db() as connection:
        student = _user_row(connection, user["id"])
        if not student or not student["class_id"]:
            raise bad_request("当前账号未绑定班级，无法生成台账")
        day = when.strftime("%Y-%m-%d")
        seq = database.daily_sequence(connection, "diagnoses", "DX", day)
        public_id = f"DX-{day.replace('-', '')}-{seq:03d}"
        connection.execute(
            """INSERT INTO diagnoses(public_id, student_id, class_id, question, course, intent,
                   intent_confidence, difficulty, mastery, weak_points, misconceptions, ability_gaps,
                   tags, summary, structured, ai_mode, duration_ms, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                public_id, student["id"], student["class_id"], question, analysis["course"],
                analysis["intent"], analysis["intent_confidence"], analysis["difficulty"],
                analysis["mastery"], weak_json,
                json.dumps(analysis["misconceptions"], ensure_ascii=False),
                json.dumps(analysis["ability_gaps"], ensure_ascii=False),
                json.dumps(analysis["tags"], ensure_ascii=False),
                analysis["summary"],
                json.dumps(analysis["structured"], ensure_ascii=False),
                analysis["ai_mode"], analysis["duration_ms"], _iso(when),
            ),
        )
        diagnosis_id = connection.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
        for index, item in enumerate(analysis["recommendations"]):
            connection.execute(
                "INSERT INTO recommendations(diagnosis_id, resource_id, reason, relevance, sort_order) "
                "VALUES (?, ?, ?, ?, ?)",
                (diagnosis_id, item["id"], item["reason"], item["relevance"], index),
            )
        ledger = _insert_ledger(
            connection, student, diagnosis_id, public_id, question, analysis, when
        )
        database.append_audit(
            connection,
            actor=student["name"],
            actor_id=student["id"],
            action="学生发起 AI 问诊",
            target=public_id,
            detail=f"{analysis['intent']} · {analysis['course']} · 掌握度 {analysis['mastery']}",
            at=_iso(when),
        )
        database.append_audit(
            connection,
            actor="AI 台账 Agent",
            actor_id=None,
            action="自动生成学工台账",
            target=ledger["code"],
            detail=f"来源问诊 {public_id}，已推送 {len(analysis['recommendations'])} 份资源",
            at=_iso(when),
        )
        return _diagnosis_detail_conn(connection, diagnosis_id, with_student=True)


def _insert_ledger(
    connection: sqlite3.Connection,
    student: sqlite3.Row | dict,
    diagnosis_id: int,
    public_id: str,
    question: str,
    analysis: dict,
    when: datetime,
) -> dict[str, Any]:
    seq = database.next_sequence(connection, "ledgers", "seq")
    code = f"XG-{when.strftime('%Y')}-{seq:05d}"
    weak_json = json.dumps(analysis["weak_points"], ensure_ascii=False)
    resource_summary = "、".join(item["title"] for item in analysis["recommendations"][:3])
    if len(analysis["recommendations"]) > 3:
        resource_summary += f" 等 {len(analysis['recommendations'])} 份"
    suggestion = {
        "知识点不会": "建议 3 日内安排 20 分钟一对一讲解，重点检查概念适用条件，并布置 2 道基础题当堂验证。",
        "方法不当": "建议布置 1 组变式题，要求写出“条件—工具—结论”链条，下次面谈检查解题步骤而非只看答案。",
        "心态困惑": "建议 24 小时内开展谈心谈话，先稳定情绪再拆解任务；如持续两周失眠或情绪低落，及时转介心理中心。",
        "复习迷茫": "建议协助制定 14 天复习表，按学分权重排序，每周检查一次执行情况并在台账中更新。",
    }[analysis["intent"]]
    previous = connection.execute(
        "SELECT hash FROM ledgers ORDER BY seq DESC LIMIT 1"
    ).fetchone()
    prev_hash = previous["hash"] if previous else GENESIS_HASH
    payload = {
        "code": code,
        "seq": seq,
        "diagnosis_id": diagnosis_id,
        "student_id": student["id"],
        "class_id": student["class_id"],
        "problem": question,
        "diagnosis_summary": analysis["summary"],
        "weak_points": weak_json,
        "resource_summary": resource_summary,
        "help_time": _iso(when),
        "created_at": _iso(when),
    }
    digest = chain_hash(prev_hash, payload)
    connection.execute(
        """INSERT INTO ledgers(code, seq, diagnosis_id, student_id, class_id, counselor_id,
               problem, diagnosis_summary, weak_points, resource_summary, help_time,
               status, follow_up, suggestion, created_at, updated_at, hash, prev_hash)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '待跟进', '', ?, ?, ?, ?, ?)""",
        (
            code, seq, diagnosis_id, student["id"], student["class_id"], None,
            question, analysis["summary"], weak_json, resource_summary, _iso(when),
            suggestion, _iso(when), _iso(when), digest, prev_hash,
        ),
    )
    row = connection.execute(
        """SELECT l.*, u.name AS student_name, u.student_no, c.name AS class_name,
                  d.course, d.intent, d.mastery, d.difficulty
           FROM ledgers l JOIN users u ON u.id = l.student_id
           JOIN classes c ON c.id = l.class_id
           JOIN diagnoses d ON d.id = l.diagnosis_id WHERE l.id = last_insert_rowid()"""
    ).fetchone()
    return _ledger_public(row)


def _diagnosis_detail_conn(
    connection: sqlite3.Connection, diagnosis_id: int, with_student: bool = False
) -> dict[str, Any]:
    row = connection.execute(
        """SELECT d.*, u.name AS student_name, u.student_no, c.name AS class_name
           FROM diagnoses d JOIN users u ON u.id = d.student_id
           JOIN classes c ON c.id = d.class_id WHERE d.id = ?""",
        (diagnosis_id,),
    ).fetchone()
    if not row:
        raise not_found("诊断记录不存在")
    diagnosis = _diagnosis_public(row)
    resources = connection.execute(
        """SELECT r.*, rec.reason, rec.relevance, rec.sort_order,
                  (SELECT COUNT(*) FROM learning_records lr
                   WHERE lr.student_id = d.student_id AND lr.resource_id = r.id AND lr.status = 'completed') AS learned
           FROM recommendations rec JOIN resources r ON r.id = rec.resource_id
           JOIN diagnoses d ON d.id = rec.diagnosis_id
           WHERE rec.diagnosis_id = ? ORDER BY rec.sort_order""",
        (diagnosis_id,),
    ).fetchall()
    ledger = connection.execute(
        """SELECT l.*, u.name AS student_name, u.student_no, c.name AS class_name,
                  d.course, d.intent, d.mastery, d.difficulty
           FROM ledgers l JOIN users u ON u.id = l.student_id
           JOIN classes c ON c.id = l.class_id
           JOIN diagnoses d ON d.id = l.diagnosis_id WHERE l.diagnosis_id = ?""",
        (diagnosis_id,),
    ).fetchone()
    result = {
        "diagnosis": diagnosis,
        "recommendations": [
            {**_resource_public(item), "reason": item["reason"], "relevance": item["relevance"],
             "learned": bool(item["learned"])}
            for item in resources
        ],
        "ledger": _ledger_public(ledger) if ledger else None,
        "agent": ai_engine.agent_status(),
    }
    if with_student:
        result["student"] = {
            "id": row["student_id"],
            "name": row["student_name"],
            "student_no": row["student_no"],
            "class_name": row["class_name"],
        }
    return result


def get_diagnosis_detail(user: dict, diagnosis_id: int) -> dict[str, Any]:
    with database.db() as connection:
        row = connection.execute("SELECT * FROM diagnoses WHERE id = ?", (diagnosis_id,)).fetchone()
        if not row:
            raise not_found("诊断记录不存在")
        if user["role"] == "student" and row["student_id"] != user["id"]:
            raise forbidden("只能查看本人的诊断记录")
        if user["role"] == "counselor":
            _ensure_class_access(connection, user, row["class_id"])
        return _diagnosis_detail_conn(connection, diagnosis_id, with_student=user["role"] == "counselor")


def list_student_diagnoses(user: dict, filters: dict) -> dict[str, Any]:
    require_role(user, "student")
    with database.db() as connection:
        rows = [dict(row) for row in _all_diagnoses(connection, user["id"])]
    course = (filters.get("course") or "").strip()
    intent = (filters.get("intent") or "").strip()
    if course:
        rows = [row for row in rows if row["course"] == course]
    if intent:
        rows = [row for row in rows if row["intent"] == intent]
    page = max(1, int(filters.get("page") or 1))
    size = 10
    total = len(rows)
    items = _diagnosis_summaries(rows[(page - 1) * size: page * size])
    return {"items": items, "total": total, "page": page, "pages": max(1, (total + size - 1) // size)}


def list_resources(user: dict, filters: dict) -> dict[str, Any]:
    require_role(user, "student")
    with database.db() as connection:
        rows = [dict(row) for row in connection.execute("SELECT * FROM resources ORDER BY id")]
        learned_ids = {
            row["resource_id"] for row in connection.execute(
                "SELECT resource_id FROM learning_records WHERE student_id = ? AND status = 'completed'",
                (user["id"],),
            )
        }
    course = (filters.get("course") or "").strip()
    rtype = (filters.get("type") or "").strip()
    keyword = (filters.get("q") or "").strip().lower()
    if course:
        rows = [row for row in rows if row["course"] == course]
    if rtype:
        rows = [row for row in rows if row["type"] == rtype]
    if keyword:
        rows = [
            row for row in rows
            if keyword in row["title"].lower() or keyword in row["summary"].lower()
            or keyword in row["course"].lower()
        ]
    return {
        "items": [
            {
                **_resource_public(row, learned=row["id"] in learned_ids),
                "kp_names": json_load(row["kp_ids"], []),
            }
            for row in rows
        ],
        "total": len(rows),
    }


def get_resource(user: dict, resource_id: int) -> dict[str, Any]:
    with database.db() as connection:
        row = connection.execute("SELECT * FROM resources WHERE id = ?", (resource_id,)).fetchone()
        if not row:
            raise not_found("学习资源不存在")
        learned = None
        if user["role"] == "student":
            learned = connection.execute(
                "SELECT 1 FROM learning_records WHERE student_id = ? AND resource_id = ? AND status = 'completed'",
                (user["id"], resource_id),
            ).fetchone()
        related = connection.execute(
            "SELECT id, title, type, course FROM resources WHERE course = ? AND id != ? LIMIT 4",
            (row["course"], resource_id),
        ).fetchall()
    return {
        **_resource_public(row, learned=bool(learned)),
        "content": row["content"],
        "related": [dict(item) for item in related],
    }


def mark_learning(user: dict, resource_id: int, diagnosis_id: int | None = None) -> dict[str, Any]:
    require_role(user, "student")
    with database.db() as connection:
        resource = connection.execute("SELECT * FROM resources WHERE id = ?", (resource_id,)).fetchone()
        if not resource:
            raise not_found("学习资源不存在")
        exists = connection.execute(
            "SELECT id FROM learning_records WHERE student_id = ? AND resource_id = ? AND status = 'completed'",
            (user["id"], resource_id),
        ).fetchone()
        now = _iso(_now())
        if not exists:
            if diagnosis_id:
                owned = connection.execute(
                    "SELECT 1 FROM diagnoses WHERE id = ? AND student_id = ?",
                    (diagnosis_id, user["id"]),
                ).fetchone()
                if not owned:
                    diagnosis_id = None
            connection.execute(
                """INSERT INTO learning_records(student_id, resource_id, diagnosis_id, status, created_at, completed_at)
                   VALUES (?, ?, ?, 'completed', ?, ?)""",
                (user["id"], resource_id, diagnosis_id, now, now),
            )
            database.append_audit(
                connection,
                actor=user["name"],
                actor_id=user["id"],
                action="完成学习资源",
                target=resource["title"],
                detail=f"{resource['type']} · {resource['course']}",
                at=now,
            )
        return {"ok": True, "learned": True, "resource_id": resource_id}


def student_profile(user: dict) -> dict[str, Any]:
    require_role(user, "student")
    overview = student_overview(user)
    with database.db() as connection:
        diagnoses = [dict(row) for row in _all_diagnoses(connection, user["id"])]
        learned = [dict(row) for row in connection.execute(
            """SELECT r.title, r.type, r.course, lr.created_at
               FROM learning_records lr JOIN resources r ON r.id = lr.resource_id
               WHERE lr.student_id = ? AND lr.status = 'completed'
               ORDER BY lr.created_at DESC""",
            (user["id"],),
        )]
        ledgers = [dict(row) for row in connection.execute(
            "SELECT * FROM ledgers WHERE student_id = ? ORDER BY help_time DESC", (user["id"],)
        )]
        activity: dict[str, int] = defaultdict(int)
        for row in diagnoses:
            activity[row["created_at"][:10]] += 1
        for row in learned:
            activity[row["created_at"][:10]] += 1
        heatmap = []
        cursor = _now().date() - timedelta(days=55)
        for _ in range(56):
            key = cursor.isoformat()
            heatmap.append({"date": key, "count": activity.get(key, 0)})
            cursor += timedelta(days=1)

    timeline = []
    for row in diagnoses[:20]:
        weak = [item.get("name") for item in json_load(row["weak_points"], []) if isinstance(item, dict)]
        timeline.append({
            "type": "diagnosis",
            "id": row["id"],
            "date": row["created_at"],
            "title": f"AI 学情问诊 · {row['course']}",
            "desc": f"{row['intent']}｜掌握度 {row['mastery']}｜{'、'.join(weak[:2])}",
            "badge": row["intent"],
        })
    for row in learned[:12]:
        timeline.append({
            "type": "resource",
            "id": None,
            "date": row["created_at"],
            "title": f"完成学习资源 · {row['title'][:30]}",
            "desc": f"{row['type']}｜{row['course']}",
            "badge": "学习",
        })
    with database.db() as connection:
        ledger_rows = [dict(row) for row in connection.execute(
            """SELECT l.*, d.course AS course FROM ledgers l
               JOIN diagnoses d ON d.id = l.diagnosis_id
               WHERE l.student_id = ? ORDER BY l.help_time DESC LIMIT 12""",
            (user["id"],),
        )]
    for row in ledger_rows:
        timeline.append({
            "type": "ledger",
            "id": row["id"],
            "date": row["help_time"],
            "title": f"学工台账 · {row['code']}",
            "desc": f"状态：{row['status']}｜{row.get('course') or ''}",
            "badge": row["status"],
        })
    timeline.sort(key=lambda item: item["date"], reverse=True)
    return {
        **overview,
        "timeline": timeline[:30],
        "heatmap": heatmap,
        "ledger_count": len(ledgers),
    }


# ---------------------------------------------------------------------------
# 辅导员端
# ---------------------------------------------------------------------------
def _range_start(days: int) -> str:
    return _iso(_now() - timedelta(days=days - 1)).replace("T", " ")[:10]


def _class_scope(user: dict, class_id: int | None) -> tuple[list[int], str]:
    with database.db() as connection:
        owned = _owned_class_ids(connection, user)
        if not owned:
            raise forbidden("当前账号尚未绑定班级")
        if class_id:
            if class_id not in owned:
                raise forbidden("只能查看自己所辖班级")
            row = connection.execute("SELECT name FROM classes WHERE id = ?", (class_id,)).fetchone()
            return [class_id], (row["name"] if row else "")
        return owned, "全部班级"


def counselor_overview(user: dict, days: int = 14, class_id: int | None = None) -> dict[str, Any]:
    require_role(user, "counselor")
    days = _clean_period(days)
    start = _range_start(days)
    class_ids, scope_name = _class_scope(user, class_id)
    placeholders = ",".join("?" for _ in class_ids)
    with database.db() as connection:
        students = [dict(row) for row in connection.execute(
            f"""SELECT u.*, c.name AS class_name FROM users u JOIN classes c ON c.id = u.class_id
                WHERE u.role = 'student' AND u.class_id IN ({placeholders}) ORDER BY u.student_no""",
            class_ids,
        )]
        diagnoses = [dict(row) for row in connection.execute(
            f"""SELECT d.*, u.name AS student_name, u.student_no FROM diagnoses d
                JOIN users u ON u.id = d.student_id
                WHERE d.class_id IN ({placeholders}) AND substr(d.created_at,1,10) >= ?
                ORDER BY d.created_at DESC""",
            (*class_ids, start),
        )]
        ledgers = [dict(row) for row in connection.execute(
            f"""SELECT l.*, u.name AS student_name, u.student_no, d.course, d.intent, d.mastery, d.difficulty
                FROM ledgers l JOIN users u ON u.id = l.student_id
                JOIN diagnoses d ON d.id = l.diagnosis_id
                WHERE l.class_id IN ({placeholders}) AND substr(l.help_time,1,10) >= ?
                ORDER BY l.help_time DESC""",
            (*class_ids, start),
        )]
        recent_ledger_rows = connection.execute(
            f"""SELECT l.*, u.name AS student_name, u.student_no, d.course, d.intent, d.mastery, d.difficulty
                FROM ledgers l JOIN users u ON u.id = l.student_id
                JOIN diagnoses d ON d.id = l.diagnosis_id
                WHERE l.class_id IN ({placeholders})
                ORDER BY l.help_time DESC LIMIT 6""",
            class_ids,
        ).fetchall()
        today = _today()
        today_count = connection.execute(
            f"SELECT COUNT(*) AS n FROM diagnoses WHERE class_id IN ({placeholders}) AND substr(created_at,1,10) = ?",
            (*class_ids, today),
        ).fetchone()["n"]
        pending_total = connection.execute(
            f"SELECT COUNT(*) AS n FROM ledgers WHERE class_id IN ({placeholders}) AND status != '已闭环'",
            class_ids,
        ).fetchone()["n"]

    student_ids = {row["id"] for row in students}
    active_ids = {row["student_id"] for row in diagnoses if row["student_id"] in student_ids}
    total_students = len(students)
    avg_mastery = int(round(sum(row["mastery"] for row in diagnoses) / len(diagnoses))) if diagnoses else 0
    closed = sum(1 for row in ledgers if row["status"] == "已闭环")
    pending = sum(1 for row in ledgers if row["status"] == "待跟进")
    following = sum(1 for row in ledgers if row["status"] == "跟进中")
    priority = len({row["student_id"] for row in ledgers if row["status"] != "已闭环"})
    weak = _aggregate_weak(diagnoses)
    intents = _intent_dist(diagnoses)
    courses = _course_dist(diagnoses)

    trend_days = [(_now() - timedelta(days=offset)).strftime("%Y-%m-%d") for offset in range(days - 1, -1, -1)]
    diag_by_day = Counter(row["created_at"][:10] for row in diagnoses)
    ledger_by_day = Counter(row["help_time"][:10] for row in ledgers)
    trend = [
        {
            "date": day,
            "label": day[5:],
            "diagnoses": diag_by_day.get(day, 0),
            "ledgers": ledger_by_day.get(day, 0),
        }
        for day in trend_days
    ]

    ledger_by_student: dict[int, list[dict]] = defaultdict(list)
    for row in ledgers:
        ledger_by_student[row["student_id"]].append(row)
    diag_by_student: dict[int, list[dict]] = defaultdict(list)
    for row in diagnoses:
        diag_by_student[row["student_id"]].append(row)

    risk_students = []
    for student in students:
        records = diag_by_student.get(student["id"], [])
        student_ledgers = ledger_by_student.get(student["id"], [])
        student_pending = sum(1 for item in student_ledgers if item["status"] != "已闭环")
        avg = int(round(sum(item["mastery"] for item in records) / len(records))) if records else 0
        last = records[0]["created_at"] if records else ""
        score = 0
        reasons: list[str] = []
        if records:
            if avg < 45:
                score += 3
                reasons.append(f"平均掌握度仅 {avg}")
            elif avg < 55:
                score += 2
                reasons.append(f"平均掌握度 {avg} 偏低")
            if len(records) >= 3:
                score += 1
                reasons.append(f"近 {days} 天问诊 {len(records)} 次")
            if records[0]["intent"] in {"心态困惑", "复习迷茫"}:
                score += 1
                reasons.append("最近一次为情绪/复习类求助")
        if student_pending >= 2:
            score += 2
            reasons.append(f"{student_pending} 条台账待跟进")
        elif student_pending == 1:
            score += 1
            reasons.append("有 1 条台账待跟进")
        level = "高" if score >= 5 else ("中" if score >= 3 else "低")
        if student_pending or (records and (avg < 55 or len(records) >= 2)):
            risk_students.append({
                "id": student["id"],
                "name": student["name"],
                "student_no": student["student_no"],
                "class_name": student["class_name"],
                "avatar": student["name"][:1],
                "avg_mastery": avg,
                "diagnoses": len(records),
                "pending": student_pending,
                "last_at": last,
                "last_text": _dt_text(last),
                "level": level,
                "score": score,
                "reason": "；".join(reasons[:2]) or "学情数据待补充",
            })
    risk_students.sort(key=lambda item: (-item["score"], item["avg_mastery"]))
    top_risk = risk_students[:6]

    top_intent = max(intents, key=lambda item: item["count"]) if intents else {"label": "知识点不会", "pct": 0}
    suggestions: list[str] = []
    if pending_total:
        suggestions.append(f"优先处理 {pending_total} 条未闭环台账，建议按掌握度从低到高排序逐一谈话。")
    if weak:
        suggestions.append(f"针对高频薄弱点「{weak[0]['name']}」安排一次 30 分钟专题串讲，覆盖 {weak[0]['count']} 人次。")
    if top_intent["label"] == "心态困惑" or (
        next((item["pct"] for item in intents if item["label"] == "心态困惑"), 0) >= 20
    ):
        suggestions.append("情绪类求助占比偏高，建议本周开展一次考前减压主题班会，并关注 2—3 名重点学生。")
    if total_students and _pct(len(active_ids), total_students) < 60:
        suggestions.append(
            f"当前问诊覆盖率 {_pct(len(active_ids), total_students)}%，可结合晚点名说明平台用法，扩大主动求助面。"
        )
    suggestions.append("下周对高风险学生安排一对一谈话，谈话记录可直接补录到对应台账的跟进栏。")

    ai_summary = (
        f"近 {days} 天，{len(active_ids)} 名学生发起 {len(diagnoses)} 次问诊，覆盖 "
        f"{len({row['course'] for row in diagnoses})} 门课程；问题类型以「{top_intent['label']}」为主"
        f"（{top_intent['pct']}%），高频薄弱点为「{weak[0]['name'] if weak else '待积累'}」"
        f"（{weak[0]['count'] if weak else 0} 次）。当前 {pending_total} 条台账未闭环，"
        f"本周期自动生成 {len(ledgers)} 条台账，闭环率 {_pct(closed, len(ledgers))}%。"
    )

    return {
        "scope": {"class_ids": class_ids, "class_name": scope_name, "days": days, "start": start},
        "stats": {
            "students": total_students,
            "active": len(active_ids),
            "coverage": _pct(len(active_ids), total_students),
            "diagnoses": len(diagnoses),
            "today": today_count,
            "ledgers": len(ledgers),
            "pending": pending,
            "following": following,
            "closed": closed,
            "closure_rate": _pct(closed, len(ledgers)),
            "avg_mastery": avg_mastery,
            "pending_total": pending_total,
            "priority_students": priority,
        },
        "intents": intents,
        "courses": courses,
        "weak_points": weak[:7],
        "trend": trend,
        "risk_students": top_risk,
        "recent_ledgers": [_ledger_public(row) for row in recent_ledger_rows],
        "ai_summary": ai_summary,
        "suggestions": suggestions,
        "generated_at": _iso(_now()),
    }


def _student_risk_summary(records: list[dict], student_ledgers: list[dict]) -> dict[str, Any]:
    avg = int(round(sum(item["mastery"] for item in records) / len(records))) if records else 0
    pending = sum(1 for item in student_ledgers if item["status"] != "已闭环")
    score = 0
    reasons: list[str] = []
    if records:
        if avg < 45:
            score += 3
            reasons.append(f"平均掌握度仅 {avg}")
        elif avg < 55:
            score += 2
            reasons.append(f"平均掌握度 {avg} 偏低")
        if len(records) >= 3:
            score += 1
            reasons.append(f"累计问诊 {len(records)} 次")
        if records[0]["intent"] in {"心态困惑", "复习迷茫"}:
            score += 1
            reasons.append("最近一次为情绪/复习类求助")
    if pending >= 2:
        score += 2
        reasons.append(f"{pending} 条台账待跟进")
    elif pending == 1:
        score += 1
        reasons.append("有 1 条台账待跟进")
    level = "高" if score >= 5 else ("中" if score >= 3 else "低")
    return {
        "avg_mastery": avg,
        "pending": pending,
        "level": level,
        "score": score,
        "reason": "；".join(reasons[:2]) or "暂无明显风险",
        "last_at": records[0]["created_at"] if records else "",
        "last_text": _dt_text(records[0]["created_at"]) if records else "暂无问诊",
    }


def counselor_students(user: dict, filters: dict) -> dict[str, Any]:
    require_role(user, "counselor")
    class_ids, scope_name = _class_scope(user, int(filters["class_id"]) if filters.get("class_id") else None)
    placeholders = ",".join("?" for _ in class_ids)
    with database.db() as connection:
        students = [dict(row) for row in connection.execute(
            f"""SELECT u.*, c.name AS class_name FROM users u JOIN classes c ON c.id = u.class_id
                WHERE u.role = 'student' AND u.class_id IN ({placeholders}) ORDER BY u.student_no""",
            class_ids,
        )]
        diagnoses = [dict(row) for row in connection.execute(
            f"SELECT * FROM diagnoses WHERE class_id IN ({placeholders}) ORDER BY created_at DESC",
            class_ids,
        )]
        ledgers = [dict(row) for row in connection.execute(
            f"SELECT * FROM ledgers WHERE class_id IN ({placeholders}) ORDER BY help_time DESC",
            class_ids,
        )]
    diag_by_student: dict[int, list[dict]] = defaultdict(list)
    for row in diagnoses:
        diag_by_student[row["student_id"]].append(row)
    ledger_by_student: dict[int, list[dict]] = defaultdict(list)
    for row in ledgers:
        ledger_by_student[row["student_id"]].append(row)

    rows = []
    for student in students:
        records = diag_by_student.get(student["id"], [])
        student_ledgers = ledger_by_student.get(student["id"], [])
        risk = _student_risk_summary(records, student_ledgers)
        weak = _aggregate_weak(records)
        rows.append({
            "id": student["id"],
            "name": student["name"],
            "student_no": student["student_no"],
            "class_name": student["class_name"],
            "avatar": student["name"][:1],
            "diagnoses": len(records),
            "avg_mastery": risk["avg_mastery"],
            "pending": risk["pending"],
            "last_at": risk["last_at"],
            "last_text": risk["last_text"],
            "risk": risk["level"],
            "risk_score": risk["score"],
            "risk_reason": risk["reason"],
            "top_weak": weak[0]["name"] if weak else "",
            "last_intent": records[0]["intent"] if records else "",
        })
    search = (filters.get("q") or "").strip().lower()
    if search:
        rows = [
            row for row in rows
            if search in row["name"].lower() or search in row["student_no"].lower()
            or search in (row["top_weak"] or "").lower()
        ]
    risk_filter = filters.get("risk") or "all"
    if risk_filter != "all":
        rows = [row for row in rows if row["risk"] == risk_filter]
    status_filter = filters.get("status") or "all"
    if status_filter == "active":
        rows = [row for row in rows if row["diagnoses"] > 0]
    elif status_filter == "silent":
        rows = [row for row in rows if row["diagnoses"] == 0]
    rows.sort(key=lambda item: (-item["risk_score"], -item["diagnoses"], item["student_no"]))
    summary = {
        "total": len(students),
        "active": sum(1 for row in rows if row["diagnoses"] > 0),
        "high": sum(1 for row in rows if row["risk"] == "高"),
        "pending": sum(row["pending"] for row in rows),
    }
    return {"items": rows, "total": len(rows), "summary": summary, "scope_name": scope_name}


def counselor_student_detail(user: dict, student_id: int) -> dict[str, Any]:
    require_role(user, "counselor")
    with database.db() as connection:
        student = _user_row(connection, student_id)
        if not student or student["role"] != "student":
            raise not_found("学生不存在")
        _ensure_student_access(connection, user, student)
        public = user_public(student)
        ledgers = [dict(row) for row in connection.execute(
            """SELECT l.*, u.name AS student_name, u.student_no, c.name AS class_name,
                      d.course, d.intent, d.mastery, d.difficulty
               FROM ledgers l JOIN users u ON u.id = l.student_id
               JOIN classes c ON c.id = l.class_id
               JOIN diagnoses d ON d.id = l.diagnosis_id
               WHERE l.student_id = ? ORDER BY l.help_time DESC""",
            (student_id,),
        )]
        records = [dict(row) for row in _all_diagnoses(connection, student_id)]
    overview = student_overview(public)
    overview["ledgers"] = [_ledger_public(row) for row in ledgers]
    overview["diagnoses"] = _diagnosis_summaries(records)
    overview["risk"] = _student_risk_summary(records, ledgers)
    overview["report_ready"] = bool(records)
    return overview


def list_ledgers(user: dict, filters: dict) -> dict[str, Any]:
    require_role(user, "counselor")
    rows = _filtered_ledgers(user, filters)
    summary_rows = _filtered_ledgers(user, {**filters, "status": ""})
    page = max(1, int(filters.get("page") or 1))
    size = min(50, max(5, int(filters.get("page_size") or 10)))
    total = len(rows)
    items = rows[(page - 1) * size: page * size]
    summary = {
        "total": len(summary_rows),
        "pending": sum(1 for row in summary_rows if row["status"] == "待跟进"),
        "following": sum(1 for row in summary_rows if row["status"] == "跟进中"),
        "closed": sum(1 for row in summary_rows if row["status"] == "已闭环"),
        "students": len({row["student_id"] for row in summary_rows}),
        "courses": len({row["course"] for row in summary_rows if row.get("course")}),
    }
    return {
        "items": items,
        "total": total,
        "page": page,
        "pages": max(1, (total + size - 1) // size),
        "page_size": size,
        "summary": summary,
    }


def _filtered_ledgers(user: dict, filters: dict) -> list[dict]:
    class_ids, _ = _class_scope(user, int(filters["class_id"]) if filters.get("class_id") else None)
    placeholders = ",".join("?" for _ in class_ids)
    sql = f"""SELECT l.*, u.name AS student_name, u.student_no, c.name AS class_name,
                     d.course, d.intent, d.mastery, d.difficulty
              FROM ledgers l JOIN users u ON u.id = l.student_id
              JOIN classes c ON c.id = l.class_id
              JOIN diagnoses d ON d.id = l.diagnosis_id
              WHERE l.class_id IN ({placeholders})"""
    params: list[Any] = list(class_ids)
    keyword = (filters.get("q") or "").strip()
    if keyword:
        sql += " AND (u.name LIKE ? OR u.student_no LIKE ? OR l.code LIKE ? OR l.problem LIKE ?)"
        like = f"%{keyword}%"
        params.extend([like, like, like, like])
    if filters.get("intent"):
        sql += " AND d.intent = ?"
        params.append(filters["intent"])
    if filters.get("status"):
        sql += " AND l.status = ?"
        params.append(filters["status"])
    if filters.get("course"):
        sql += " AND d.course = ?"
        params.append(filters["course"])
    if filters.get("from"):
        sql += " AND substr(l.help_time,1,10) >= ?"
        params.append(filters["from"])
    if filters.get("to"):
        sql += " AND substr(l.help_time,1,10) <= ?"
        params.append(filters["to"])
    sql += " ORDER BY l.help_time DESC, l.seq DESC"
    with database.db() as connection:
        rows = [dict(row) for row in connection.execute(sql, params)]
    return [_ledger_public(row) for row in rows]


def get_ledger(user: dict, ledger_id: int) -> dict[str, Any]:
    require_role(user, "counselor")
    with database.db() as connection:
        row = connection.execute(
            """SELECT l.*, u.name AS student_name, u.student_no, c.name AS class_name,
                      d.course, d.intent, d.mastery, d.difficulty
               FROM ledgers l JOIN users u ON u.id = l.student_id
               JOIN classes c ON c.id = l.class_id
               JOIN diagnoses d ON d.id = l.diagnosis_id WHERE l.id = ?""",
            (ledger_id,),
        ).fetchone()
        if not row:
            raise not_found("台账不存在")
        _ensure_class_access(connection, user, row["class_id"])
        ledger = _ledger_public(row)
        previous = connection.execute(
            "SELECT hash FROM ledgers WHERE seq < ? ORDER BY seq DESC LIMIT 1", (row["seq"],)
        ).fetchone()
        expected_prev = previous["hash"] if previous else GENESIS_HASH
        payload = {
            "code": row["code"], "seq": row["seq"], "diagnosis_id": row["diagnosis_id"],
            "student_id": row["student_id"], "class_id": row["class_id"],
            "problem": row["problem"], "diagnosis_summary": row["diagnosis_summary"],
            "weak_points": row["weak_points"], "resource_summary": row["resource_summary"],
            "help_time": row["help_time"], "created_at": row["created_at"],
        }
        ledger["integrity"] = (
            row["prev_hash"] == expected_prev and chain_hash(expected_prev, payload) == row["hash"]
        )
        diagnosis = _diagnosis_detail_conn(connection, row["diagnosis_id"], with_student=True)
        return {"ledger": ledger, "diagnosis": diagnosis["diagnosis"],
                "recommendations": diagnosis["recommendations"]}


def update_ledger(user: dict, ledger_id: int, payload: dict) -> dict[str, Any]:
    require_role(user, "counselor")
    status = str(payload.get("status") or "").strip()
    follow_up = str(payload.get("follow_up") or "").strip()
    if status and status not in STATUSES:
        raise bad_request("跟进状态不合法")
    if len(follow_up) > config.MAX_FOLLOWUP_CHARS:
        raise bad_request("跟进记录过长")
    with database.db() as connection:
        row = connection.execute("SELECT * FROM ledgers WHERE id = ?", (ledger_id,)).fetchone()
        if not row:
            raise not_found("台账不存在")
        _ensure_class_access(connection, user, row["class_id"])
        new_status = status or row["status"]
        new_follow = follow_up if follow_up else row["follow_up"]
        now = _iso(_now())
        connection.execute(
            "UPDATE ledgers SET status = ?, follow_up = ?, updated_at = ? WHERE id = ?",
            (new_status, new_follow, now, ledger_id),
        )
        database.append_audit(
            connection,
            actor=user["name"],
            actor_id=user["id"],
            action="更新台账跟进",
            target=row["code"],
            detail=f"{row['status']} → {new_status}",
            at=now,
        )
    return get_ledger(user, ledger_id)


# ---------------------------------------------------------------------------
# 报告
# ---------------------------------------------------------------------------
def _next_report_code(connection: sqlite3.Connection, year: str | None = None) -> str:
    year = year or str(_now().year)
    count = connection.execute(
        "SELECT COUNT(*) AS n FROM reports WHERE code LIKE ?", (f"BG-{year}-%",)
    ).fetchone()["n"]
    return f"BG-{year}-{count + 1:05d}"


def _report_hash(payload: dict) -> str:
    import hashlib

    return hashlib.sha256(
        database.canonical_json(payload).encode("utf-8")
    ).hexdigest()


def _save_report(connection: sqlite3.Connection, report: dict, actor: dict) -> dict:
    report["code"] = _next_report_code(connection)
    report["hash"] = _report_hash({
        "type": report["type"],
        "target_id": report["target_id"],
        "title": report["title"],
        "generated_at": report["generated_at"],
        "sections": report["sections"],
        "metrics": report["metrics"],
    })
    connection.execute(
        """INSERT INTO reports(code, type, target_id, title, content, generated_at, hash)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (
            report["code"], report["type"], report["target_id"], report["title"],
            json.dumps(report, ensure_ascii=False), report["generated_at"], report["hash"],
        ),
    )
    database.append_audit(
        connection,
        actor=actor["name"],
        actor_id=actor["id"],
        action="生成 AI 帮扶报告",
        target=report["code"],
        detail=report["title"],
        at=report["generated_at"],
    )
    return report


def _report_common(student: dict, records: list[dict], ledgers: list[dict], learned: list[dict], risk: dict) -> dict:
    weak = _aggregate_weak(records)
    intents = _intent_dist(records)
    avg_mastery = int(round(sum(row["mastery"] for row in records) / len(records))) if records else 0
    closed = sum(1 for row in ledgers if row["status"] == "已闭环")
    sessions = len(records)
    trend_note = "样本较少，建议持续问诊以形成趋势"
    if len(records) >= 4:
        recent = sorted(records, key=lambda row: row["created_at"])[-4:]
        delta = recent[-1]["mastery"] - recent[0]["mastery"]
        trend_note = f"最近 {len(recent)} 次问诊掌握度{'上升' if delta >= 0 else '下降'} {abs(delta)} 分"
    return {
        "weak": weak,
        "intents": intents,
        "avg_mastery": avg_mastery,
        "closed": closed,
        "sessions": sessions,
        "trend_note": trend_note,
        "risk": risk,
        "learned": learned,
    }


def _student_suggestions(records: list[dict], weak: list[dict], risk: dict) -> list[str]:
    suggestions: list[str] = []
    if weak:
        top = weak[0]
        suggestions.append(
            f"每天安排 20 分钟专攻「{top['name']}」（{top['course']}），先做 3 道基础题，再做 1 道变式题，连续 7 天。"
        )
    if records:
        intent = records[0]["intent"]
        detail = {
            "知识点不会": "采用“合书复述 + 例题重做 + 自测”的三步法，先确认概念适用条件，再进入综合题。",
            "方法不当": "建立“条件—工具—结论”解题卡，每道错题只记录思路断点，不抄答案。",
            "心态困惑": "把复习目标拆成每天可完成的最小任务，固定作息；若持续两周情绪低落，主动联系辅导员或心理中心。",
            "复习迷茫": "按学分权重与掌握度缺口排出 14 天计划，每天结束前用 10 分钟无提示自测。",
        }[intent]
        suggestions.append(detail)
    suggestions.append(
        f"两周后用同一套分层习题复测，目标把平均掌握度从 {risk['avg_mastery']} 提升到 {min(92, risk['avg_mastery'] + 10)}。"
    )
    if risk["pending"]:
        suggestions.append(f"主动向辅导员反馈 {risk['pending']} 条待跟进台账的进展，形成“求助—行动—复盘”的闭环。")
    suggestions.append("每周至少完成 2 份推荐资源，并在平台上标记“已学习”，让帮扶记录可追踪。")
    return suggestions[:5]


def build_student_report(user: dict, student_id: int) -> dict[str, Any]:
    with database.db() as connection:
        student = _user_row(connection, student_id)
        if not student:
            raise not_found("学生不存在")
        if user["role"] == "student" and student_id != user["id"]:
            raise forbidden("只能查看本人报告")
        if user["role"] == "counselor":
            _ensure_student_access(connection, user, student)
        records = [dict(row) for row in _all_diagnoses(connection, student_id)]
        ledgers = [dict(row) for row in connection.execute(
            """SELECT l.*, u.name AS student_name, u.student_no, c.name AS class_name,
                      d.course, d.intent, d.mastery, d.difficulty
               FROM ledgers l JOIN users u ON u.id = l.student_id
               JOIN classes c ON c.id = l.class_id
               JOIN diagnoses d ON d.id = l.diagnosis_id
               WHERE l.student_id = ? ORDER BY l.help_time DESC""",
            (student_id,),
        )]
        learned = [dict(row) for row in connection.execute(
            """SELECT r.title, r.type, r.course, lr.created_at
               FROM learning_records lr JOIN resources r ON r.id = lr.resource_id
               WHERE lr.student_id = ? AND lr.status = 'completed' ORDER BY lr.created_at DESC""",
            (student_id,),
        )]
        counselor = connection.execute(
            "SELECT u.name FROM users u JOIN classes c ON c.counselor_id = u.id WHERE c.id = ?",
            (student["class_id"],),
        ).fetchone() if student["class_id"] else None

    public = user_public(student)
    risk = _student_risk_summary(records, ledgers)
    common = _report_common(public, records, ledgers, learned, risk)
    weak = common["weak"]
    period = (
        f"{_dt_text(records[-1]['created_at'], False)} 至 {_dt_text(records[0]['created_at'], False)}"
        if records else "暂无问诊记录"
    )
    info = [
        {"label": "学院", "value": COLLEGE},
        {"label": "专业", "value": public["major"] or "—"},
        {"label": "班级", "value": public["class_name"] or "—"},
        {"label": "学号", "value": public["student_no"] or "—"},
        {"label": "辅导员", "value": counselor["name"] if counselor else "—"},
        {"label": "统计周期", "value": period},
        {"label": "数据来源", "value": "AI 问诊 + 学习行为"},
        {"label": "生成方式", "value": "AI 帮扶报告 Agent"},
    ]
    metrics = [
        {"label": "累计问诊", "value": len(records), "unit": "次"},
        {"label": "覆盖课程", "value": len({row["course"] for row in records}), "unit": "门"},
        {"label": "平均掌握度", "value": common["avg_mastery"], "unit": "/100"},
        {"label": "台账闭环率", "value": _pct(common["closed"], len(ledgers)), "unit": "%"},
    ]

    problem_rows = []
    for row in records[:6]:
        problem_rows.append([
            _dt_text(row["created_at"], False), row["course"], row["intent"],
            "、".join(item.get("name") for item in json_load(row["weak_points"], [])[:2]),
            f"{row['mastery']}/100",
        ])
    weak_rows = [
        [item["name"], item["course"], f"{item['count']} 次", f"{item['mastery']}/100"]
        for item in weak[:8]
    ]
    ledger_rows = [
        [row["code"], _dt_text(row["help_time"], False), row["status"], (row["follow_up"] or "待补充")[:34]]
        for row in ledgers[:8]
    ]
    sections = [
        {
            "title": "一、学情概览",
            "paragraphs": [
                f"{public['name']}同学在统计周期内共发起 {len(records)} 次 AI 学情问诊，覆盖 "
                f"{len({row['course'] for row in records})} 门课程，平均掌握度 {common['avg_mastery']}/100，"
                f"整体处于{'需要重点帮扶' if common['avg_mastery'] < 50 else ('稳步提升' if common['avg_mastery'] < 70 else '相对稳定')}区间。",
                f"{common['trend_note']}。问题类型以「{max(common['intents'], key=lambda item: item['count'])['label'] if records else '待积累'}」为主，"
                f"当前风险等级为「{risk['level']}」，主要依据：{risk['reason']}。",
            ],
            "bullets": [f"最近一次问诊：{_dt_text(records[0]['created_at']) if records else '暂无'}"],
        },
        {
            "title": "二、主要学业问题",
            "paragraphs": ["下表汇总了最近 6 次问诊的结构化结论，原始提问与诊断结果均不可修改。"],
            "table": {"headers": ["时间", "课程", "问题类型", "主要薄弱点", "掌握度"], "rows": problem_rows},
        },
        {
            "title": "三、薄弱知识点",
            "paragraphs": ["按被问诊提及次数与掌握度综合排序，建议优先处理前 3 项。"],
            "table": {"headers": ["知识点", "课程", "被提及", "当前掌握度"], "rows": weak_rows},
        },
        {
            "title": "四、AI 帮扶建议",
            "bullets": _student_suggestions(records, weak, risk),
        },
        {
            "title": "五、已推送学习资源",
            "bullets": [
                f"{row['title']}（{row['type']}，{row['course']}）" for row in learned[:6]
            ] or ["暂未完成资源学习，建议从本次诊断推荐的资源开始。"],
        },
        {
            "title": "六、学工台账记录",
            "paragraphs": [f"系统已自动生成 {len(ledgers)} 条台账，其中 {common['closed']} 条已闭环。"],
            "table": {"headers": ["台账编号", "帮扶时间", "状态", "跟进记录"], "rows": ledger_rows},
        },
        {
            "title": "七、阶段目标",
            "bullets": [
                f"两周内将平均掌握度从 {risk['avg_mastery']} 提升至 {min(92, risk['avg_mastery'] + 10)}；",
                "完成至少 4 份推荐资源并标记“已学习”；",
                "主动向辅导员反馈 1 次学习进展，形成帮扶闭环；",
                "若出现持续情绪困扰，及时使用心理支持资源。",
            ],
        },
    ]
    return {
        "type": "student",
        "target_id": student_id,
        "title": f"{public['name']}同学学情帮扶报告",
        "subtitle": f"{public['class_name']} · AI 自动生成 · {period}",
        "generated_at": _iso(_now()),
        "student": public,
        "info": info,
        "metrics": metrics,
        "sections": sections,
        "hash": "",
        "code": "",
        "risk": risk,
        "weak_points": weak,
    }


def generate_student_report(user: dict, student_id: int) -> dict[str, Any]:
    report = build_student_report(user, student_id)
    with database.db() as connection:
        return _save_report(connection, report, user)


def build_class_report(user: dict, class_id: int | None, days: int = 30) -> dict[str, Any]:
    require_role(user, "counselor")
    days = 30 if int(days or 30) == 30 else _clean_period(days)
    overview = counselor_overview(user, days, class_id)
    class_ids = overview["scope"]["class_ids"]
    with database.db() as connection:
        class_row = connection.execute("SELECT * FROM classes WHERE id = ?", (class_ids[0],)).fetchone() if len(class_ids) == 1 else None
        counselor = connection.execute("SELECT name FROM users WHERE id = ?", (user["id"],)).fetchone()
    class_name = class_row["name"] if class_row else "全部班级"
    stats = overview["stats"]
    weak = overview["weak_points"]
    intents = overview["intents"]
    risk_students = overview["risk_students"]
    top_intent = max(intents, key=lambda item: item["count"]) if intents else {"label": "知识点不会", "pct": 0}
    high = [item for item in risk_students if item["level"] == "高"]
    mid = [item for item in risk_students if item["level"] == "中"]
    info = [
        {"label": "学院", "value": COLLEGE},
        {"label": "班级", "value": class_name},
        {"label": "辅导员", "value": counselor["name"] if counselor else user["name"]},
        {"label": "统计周期", "value": f"近 {days} 天"},
        {"label": "学生总数", "value": f"{stats['students']} 人"},
        {"label": "问诊覆盖", "value": f"{stats['active']} 人 / {stats['coverage']}%"},
        {"label": "数据来源", "value": "AI 问诊 + 学工台账"},
        {"label": "生成方式", "value": "AI 班级学情 Agent"},
    ]
    metrics = [
        {"label": "问诊总量", "value": stats["diagnoses"], "unit": "次"},
        {"label": "台账总数", "value": stats["ledgers"], "unit": "条"},
        {"label": "台账闭环率", "value": stats["closure_rate"], "unit": "%"},
        {"label": "平均掌握度", "value": stats["avg_mastery"], "unit": "/100"},
    ]
    sections = [
        {
            "title": "一、班级学情概况",
            "paragraphs": [
                f"近 {days} 天，{class_name}共有 {stats['active']}/{stats['students']} 名学生使用 AI 问诊，"
                f"覆盖率 {stats['coverage']}%，累计 {stats['diagnoses']} 次，日均 "
                f"{round(stats['diagnoses'] / max(days, 1), 1)} 次。系统自动生成台账 {stats['ledgers']} 条，"
                f"其中已闭环 {stats['closed']} 条，闭环率 {stats['closure_rate']}%。",
                overview["ai_summary"],
            ],
            "callout": "本报告由 AI 班级学情 Agent 自动汇总，所有数字均来自学生真实问诊记录与台账，可在“数据留痕”中校验。",
        },
        {
            "title": "二、问题类型结构",
            "paragraphs": [f"问题类型以「{top_intent['label']}」为主，占 {top_intent['pct']}%。"],
            "table": {
                "headers": ["问题类型", "人次", "占比", "帮扶侧重"],
                "rows": [
                    [item["label"], item["count"], f"{item['pct']}%",
                     {"知识点不会": "概念补强", "方法不当": "变式训练",
                      "心态困惑": "谈心谈话", "复习迷茫": "计划管理"}[item["label"]]]
                    for item in intents
                ],
            },
        },
        {
            "title": "三、高频薄弱知识点",
            "paragraphs": ["按被提及次数排序，前 3 项建议纳入本周专题串讲。"],
            "table": {
                "headers": ["知识点", "课程", "被提及", "平均掌握度"],
                "rows": [[item["name"], item["course"], f"{item['count']} 次", f"{item['mastery']}/100"] for item in weak[:8]],
            },
        },
        {
            "title": "四、重点关注学生",
            "paragraphs": [f"当前识别高风险 {len(high)} 人、中风险 {len(mid)} 人，建议按以下顺序开展一对一谈话。"],
            "table": {
                "headers": ["学生", "学号", "问诊", "平均掌握度", "待跟进", "风险依据"],
                "rows": [
                    [item["name"], item["student_no"], f"{item['diagnoses']} 次", f"{item['avg_mastery']}/100",
                     f"{item['pending']} 条", item["reason"]]
                    for item in risk_students[:6]
                ],
            },
        },
        {
            "title": "五、AI 分层帮扶策略",
            "bullets": [
                f"高风险（{len(high)} 人）：48 小时内一对一谈话，优先处理待跟进台账，必要时联系任课教师与心理中心。",
                f"中风险（{len(mid)} 人）：一周内完成学习计划复盘，安排学习委员结对，重点训练「{weak[0]['name'] if weak else '高频薄弱点'}」。",
                "低风险学生：保持每周一次平台问诊，推送拓展资源，防止问题积累。",
                f"班级层面：针对「{weak[0]['name'] if weak else '高频薄弱点'}」组织 1 次 30 分钟专题串讲，并在课后布置分层练习。",
            ],
        },
        {
            "title": "六、下周工作建议",
            "bullets": overview["suggestions"],
        },
    ]
    return {
        "type": "class",
        "target_id": class_ids[0] if len(class_ids) == 1 else 0,
        "title": f"{class_name}学情分析报告",
        "subtitle": f"{COLLEGE} · 近 {days} 天 · AI 自动生成",
        "generated_at": _iso(_now()),
        "info": info,
        "metrics": metrics,
        "sections": sections,
        "hash": "",
        "code": "",
        "risk": {"level": "高" if high else ("中" if mid else "低"), "avg_mastery": stats["avg_mastery"]},
        "weak_points": weak,
    }


def generate_class_report(user: dict, class_id: int | None, days: int = 30) -> dict[str, Any]:
    report = build_class_report(user, class_id, days)
    with database.db() as connection:
        return _save_report(connection, report, user)


# ---------------------------------------------------------------------------
# 留痕与审计
# ---------------------------------------------------------------------------
def _verify_ledger_chain(connection: sqlite3.Connection) -> dict[str, Any]:
    rows = connection.execute("SELECT * FROM ledgers ORDER BY seq").fetchall()
    prev = GENESIS_HASH
    for row in rows:
        payload = {
            "code": row["code"], "seq": row["seq"], "diagnosis_id": row["diagnosis_id"],
            "student_id": row["student_id"], "class_id": row["class_id"],
            "problem": row["problem"], "diagnosis_summary": row["diagnosis_summary"],
            "weak_points": row["weak_points"], "resource_summary": row["resource_summary"],
            "help_time": row["help_time"], "created_at": row["created_at"],
        }
        if row["prev_hash"] != prev or chain_hash(prev, payload) != row["hash"]:
            return {
                "valid": False, "checked": rows.index(row), "total": len(rows),
                "broken_at": row["code"], "message": f"台账 {row['code']} 的哈希与内容不一致",
            }
        prev = row["hash"]
    return {"valid": True, "checked": len(rows), "total": len(rows), "broken_at": None,
            "message": f"{len(rows)} 条台账哈希链完整"}


def _verify_audit_chain(connection: sqlite3.Connection) -> dict[str, Any]:
    rows = connection.execute("SELECT * FROM audit_logs ORDER BY id").fetchall()
    prev = GENESIS_HASH
    for row in rows:
        payload = {
            "at": row["at"], "actor": row["actor"], "actor_id": row["actor_id"],
            "action": row["action"], "target": row["target"], "detail": row["detail"],
        }
        if row["prev_hash"] != prev or chain_hash(prev, payload) != row["hash"]:
            return {
                "valid": False, "checked": rows.index(row), "total": len(rows),
                "broken_at": row["id"], "message": f"审计记录 #{row['id']} 校验失败",
            }
        prev = row["hash"]
    return {"valid": True, "checked": len(rows), "total": len(rows), "broken_at": None,
            "message": f"{len(rows)} 条审计记录哈希链完整"}


def audit_overview(user: dict) -> dict[str, Any]:
    require_role(user, "counselor")
    with database.db() as connection:
        ledger_stats = connection.execute(
            "SELECT COUNT(*) AS n, MIN(help_time) AS first, MAX(help_time) AS last FROM ledgers"
        ).fetchone()
        audit_count = connection.execute("SELECT COUNT(*) AS n FROM audit_logs").fetchone()["n"]
        report_count = connection.execute("SELECT COUNT(*) AS n FROM reports").fetchone()["n"]
        logs = connection.execute(
            "SELECT * FROM audit_logs ORDER BY id DESC LIMIT 30"
        ).fetchall()
        ledger_check = _verify_ledger_chain(connection)
        audit_check = _verify_audit_chain(connection)
        last_ledger = connection.execute(
            "SELECT code, hash FROM ledgers ORDER BY seq DESC LIMIT 1"
        ).fetchone()
        last_audit = connection.execute(
            "SELECT hash FROM audit_logs ORDER BY id DESC LIMIT 1"
        ).fetchone()
        recent_reports = connection.execute(
            "SELECT code, type, title, generated_at FROM reports ORDER BY id DESC LIMIT 5"
        ).fetchall()
    ledger_check["last_hash"] = last_ledger["hash"] if last_ledger else ""
    ledger_check["last_code"] = last_ledger["code"] if last_ledger else ""
    audit_check["last_hash"] = last_audit["hash"] if last_audit else ""
    return {
        "stats": {
            "ledgers": ledger_stats["n"],
            "audit_events": audit_count,
            "reports": report_count,
            "first_ledger": ledger_stats["first"] or "",
            "last_ledger": ledger_stats["last"] or "",
        },
        "ledger_chain": ledger_check,
        "audit_chain": audit_check,
        "logs": [
            {
                "id": row["id"],
                "at": row["at"],
                "at_text": _dt_text(row["at"]),
                "actor": row["actor"],
                "action": row["action"],
                "target": row["target"],
                "detail": row["detail"],
                "hash_short": row["hash"][:12],
            }
            for row in logs
        ],
        "recent_reports": [
            {"code": row["code"], "type": row["type"], "title": row["title"],
             "generated_at": _dt_text(row["generated_at"])}
            for row in recent_reports
        ],
        "policies": [
            {"title": "正文不可篡改", "desc": "诊断结论与台账正文由数据库触发器锁定，任何 UPDATE / DELETE 都会被拒绝。"},
            {"title": "哈希链留痕", "desc": "每条台账与审计记录都携带前序哈希，任意一条被改动都会导致链校验失败。"},
            {"title": "全量可追溯", "desc": "问诊、资源学习、台账跟进、报告生成与导出操作全部落审计日志。"},
            {"title": "归档合规", "desc": "台账与报告可导出 XLSX / PDF，满足学院学工报备与年度归档要求。"},
        ],
    }


def verify_chains(user: dict) -> dict[str, Any]:
    require_role(user, "counselor")
    with database.db() as connection:
        ledger = _verify_ledger_chain(connection)
        audit = _verify_audit_chain(connection)
        database.append_audit(
            connection,
            actor=user["name"],
            actor_id=user["id"],
            action="校验数据完整性",
            target="台账链 + 审计链",
            detail=f"台账 {'通过' if ledger['valid'] else '失败'}；审计 {'通过' if audit['valid'] else '失败'}",
        )
    return {
        "ok": ledger["valid"] and audit["valid"],
        "ledger": ledger,
        "audit": audit,
        "checked_at": _dt_text(_iso(_now())),
    }


# ---------------------------------------------------------------------------
# 导出
# ---------------------------------------------------------------------------
def export_ledgers(user: dict, filters: dict) -> tuple[list[dict], dict]:
    require_role(user, "counselor")
    class_ids, scope_name = _class_scope(user, int(filters["class_id"]) if filters.get("class_id") else None)
    rows = _filtered_ledgers(user, filters)
    summary = {
        "total": len(rows),
        "pending": sum(1 for row in rows if row["status"] == "待跟进"),
        "following": sum(1 for row in rows if row["status"] == "跟进中"),
        "closed": sum(1 for row in rows if row["status"] == "已闭环"),
        "students": len({row["student_id"] for row in rows}),
        "courses": len({row["course"] for row in rows if row.get("course")}),
        "class_name": scope_name,
        "range_text": _range_text(filters),
        "engine": ai_engine.agent_status()["label"],
    }
    with database.db() as connection:
        database.append_audit(
            connection,
            actor=user["name"],
            actor_id=user["id"],
            action="导出台账",
            target="XLSX",
            detail=f"{len(rows)} 条 · {scope_name} · {_range_text(filters)}",
        )
    return rows, summary


def _range_text(filters: dict) -> str:
    start = filters.get("from") or ""
    end = filters.get("to") or ""
    if start and end:
        return f"{start} 至 {end}"
    if start:
        return f"{start} 起"
    if end:
        return f"截至 {end}"
    return "全部时间"


def export_report(user: dict, report_type: str, target_id: int, class_id: int | None = None) -> dict:
    if report_type == "student":
        report = generate_student_report(user, target_id)
    elif report_type == "class":
        report = generate_class_report(user, class_id or (target_id or None))
    else:
        raise bad_request("报告类型不合法")
    with database.db() as connection:
        database.append_audit(
            connection,
            actor=user["name"],
            actor_id=user["id"],
            action="导出报告",
            target=report["code"],
            detail=report["title"],
        )
    return report


# ---------------------------------------------------------------------------
# 初始化演示数据
# ---------------------------------------------------------------------------
def seed_demo_data() -> None:
    now = _now()
    counselor_hash = hash_password(seed_data.COUNSELOR["password"])
    student_hash = hash_password(seed_data.STUDENT_PASSWORD)
    with database.db() as connection:
        class_ids: dict[str, int] = {}
        for item in seed_data.CLASSES:
            cursor = connection.execute(
                "INSERT INTO classes(name, grade, major, counselor_id, created_at) VALUES (?, ?, ?, NULL, ?)",
                (item["name"], item["grade"], item["major"], _iso(now)),
            )
            class_ids[item["key"]] = cursor.lastrowid
        counselor_id = connection.execute(
            "INSERT INTO users(username, password_hash, role, name, student_no, class_id, major, email, phone, tags, created_at) "
            "VALUES (?, ?, 'counselor', ?, '', NULL, '', ?, ?, ?, ?)",
            (
                seed_data.COUNSELOR["username"], counselor_hash, seed_data.COUNSELOR["name"],
                "wang.jy@univ.edu.cn", "13800001234",
                json.dumps(["学工办", "2024级"], ensure_ascii=False), _iso(now),
            ),
        ).lastrowid
        connection.execute(
            "UPDATE classes SET counselor_id = ? WHERE id IN (?, ?)",
            (counselor_id, class_ids["cs2401"], class_ids["se2402"]),
        )
        class_major = {item["key"]: item["major"] for item in seed_data.CLASSES}
        for index, (student_no, name, class_key) in enumerate(seed_data.STUDENTS):
            connection.execute(
                "INSERT INTO users(username, password_hash, role, name, student_no, class_id, major, email, phone, tags, created_at) "
                "VALUES (?, ?, 'student', ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    student_no, student_hash, name, student_no, class_ids[class_key],
                    class_major[class_key], f"{student_no}@stu.univ.edu.cn",
                    f"138{10000000 + index:08d}",
                    json.dumps(["2024级"], ensure_ascii=False), _iso(now - timedelta(days=60)),
                ),
            )
        for course, name, chapter, difficulty, keywords, description, pitfall in seed_data.KPS:
            connection.execute(
                "INSERT INTO knowledge_points(course, name, chapter, difficulty, keywords, description, pitfall) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (course, name, chapter, difficulty, keywords, description, pitfall),
            )
        for index, item in enumerate(seed_data.build_resources()):
            connection.execute(
                """INSERT INTO resources(title, type, course, kp_ids, level, minutes, summary, content, source, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, '校本知识库', ?)""",
                (
                    item["title"], item["type"], item["course"],
                    json.dumps(item["kp_names"], ensure_ascii=False), item["level"],
                    item["minutes"], item["summary"], item["content"],
                    _iso(now - timedelta(days=30 - index % 20)),
                ),
            )
        database.append_audit(
            connection,
            actor="系统",
            actor_id=None,
            action="初始化演示数据",
            target="知识库 + 班级",
            detail=f"{len(seed_data.STUDENTS)} 名学生 · {len(seed_data.KPS)} 个知识点 · {len(seed_data.build_resources())} 份资源",
        )

    # 逐条生成真实问诊闭环（AI 诊断 + 资源 + 台账 + 留痕）
    seeded: list[tuple[dict, dict]] = []
    sorted_questions = sorted(seed_data.SEED_QUESTIONS, key=lambda item: item[1], reverse=True)
    for student_no, days_ago, hour, minute, question in sorted_questions:
        with database.db() as connection:
            row = connection.execute(
                """SELECT u.*, c.name AS class_name, c.major AS class_major, c.grade AS class_grade
                   FROM users u LEFT JOIN classes c ON c.id = u.class_id WHERE u.username = ?""",
                (student_no,),
            ).fetchone()
        if not row:
            continue
        when = now - timedelta(days=days_ago)
        when = when.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if when > now:
            when -= timedelta(days=1)
        detail = create_diagnosis(user_public(row), question, when=when)
        seeded.append((detail, user_public(row)))

    # 按时间推进台账状态，形成真实的跟进分布
    with database.db() as connection:
        ledgers = connection.execute(
            """SELECT l.*, u.name AS student_name, d.weak_points
               FROM ledgers l JOIN users u ON u.id = l.student_id
               JOIN diagnoses d ON d.id = l.diagnosis_id ORDER BY l.seq"""
        ).fetchall()
        for index, row in enumerate(ledgers):
            age_days = (now - (database.parse_iso(row["help_time"]) or now)).days
            if age_days >= 7:
                status = "已闭环"
            elif age_days >= 4:
                status = "跟进中" if index % 3 else "已闭环"
            else:
                status = "待跟进"
            if status == "待跟进":
                continue
            weak = json_load(row["weak_points"], [])
            kp_name = weak[0]["name"] if weak else "核心知识"
            template = seed_data.FOLLOW_UP_TEMPLATES[index % len(seed_data.FOLLOW_UP_TEMPLATES)]
            follow_up = template.format(kp=kp_name)
            if status == "已闭环":
                follow_up = follow_up.rstrip("。") + "。经复测，掌握度提升，台账闭环。"
            connection.execute(
                "UPDATE ledgers SET status = ?, follow_up = ?, updated_at = ? WHERE id = ?",
                (status, follow_up, _iso(now - timedelta(days=max(age_days - 1, 0))), row["id"]),
            )
        database.append_audit(
            connection,
            actor="系统",
            actor_id=None,
            action="初始化台账跟进状态",
            target="学工台账",
            detail=f"{len(ledgers)} 条台账已按时间生成跟进记录",
        )
        # 学习行为：为有问诊的学生完成 1—2 份本课程资源
        for detail, student in seeded:
            course = detail["diagnosis"]["course"]
            resources = connection.execute(
                "SELECT id, title FROM resources WHERE course = ? ORDER BY id LIMIT 2", (course,)
            ).fetchall()
            for offset, resource in enumerate(resources[: 2 if len(resources) > 1 else 1]):
                connection.execute(
                    """INSERT INTO learning_records(student_id, resource_id, diagnosis_id, status, created_at, completed_at)
                       VALUES (?, ?, ?, 'completed', ?, ?)""",
                    (
                        student["id"], resource["id"], detail["diagnosis"]["id"],
                        _iso(now - timedelta(days=offset + 1)), _iso(now - timedelta(days=offset + 1)),
                    ),
                )
