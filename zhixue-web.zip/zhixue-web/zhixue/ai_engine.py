"""学情诊断 Agent：意图识别、结构化诊断、掌握度评估与资源匹配。

默认使用完全离线的本地推理引擎（规则 + 权重 + 确定性扰动），
配置 ``CLASSROOM_LLM_API_KEY`` 后可叠加 DeepSeek 大模型对结论做增强，
任何网络失败都会自动降级，不影响问诊闭环。
"""
from __future__ import annotations

import hashlib
import json
import re
import time
import urllib.error
import urllib.request
from typing import Any

from . import config, database

INTENTS = ["知识点不会", "方法不当", "心态困惑", "复习迷茫"]

INTENT_RULES: dict[str, dict[str, Any]] = {
    "知识点不会": {
        "weight": 1.0,
        "keywords": [
            "不懂", "不会", "没听懂", "听不懂", "搞不清", "理解不了", "绕晕",
            "概念", "定义", "原理", "是什么", "为什么", "区别", "关系", "记不住",
            "记混", "混淆", "完全懵", "一头雾水",
        ],
    },
    "方法不当": {
        "weight": 1.25,
        "keywords": [
            "做题", "总错", "老是错", "总是错", "算错", "列错", "写不出", "写不出来",
            "不会写", "不会算", "没有思路", "没思路", "无从下手", "不知道从哪",
            "方法", "技巧", "步骤", "套路", "套公式", "一复杂就错", "步骤都会",
            "建模", "大题", "综合题", "不会迁移",
        ],
    },
    "心态困惑": {
        "weight": 1.2,
        "keywords": [
            "焦虑", "压力", "崩溃", "没信心", "缺乏信心", "害怕", "失眠", "迷茫",
            "放弃", "跟不上", "烦躁", "紧张", "担心", "自卑", "情绪", "越练越",
            "不想学", "学不动", "内耗",
        ],
    },
    "复习迷茫": {
        "weight": 1.2,
        "keywords": [
            "复习", "备考", "期末", "计划", "重点", "时间不够", "刷题", "从哪开始",
            "效率", "冲刺", "安排", "优先级", "来不及", "好几门", "一起压过来",
        ],
    },
}

COURSE_ALIASES: dict[str, list[str]] = {
    "高等数学": ["高数", "微积分", "极限", "导数", "微分", "积分", "中值定理", "级数", "偏导", "多元函数", "洛必达", "旋转体", "拐点"],
    "线性代数": ["线代", "矩阵", "行列式", "特征值", "特征向量", "向量组", "秩", "二次型", "线性相关"],
    "数据结构": ["数据结构", "链表", "栈", "队列", "二叉树", "最短路径", "排序", "哈希", "复杂度", "算法", "dijkstra"],
    "计算机网络": ["计算机网络", "网络", "tcp", "udp", "子网", "掩码", "http", "https", "路由", "拥塞", "握手", "协议", "osi", "ip"],
    "数据库原理": ["数据库", "sql", "范式", "事务", "索引", "查询", "关系代数", "bcnf", "隔离级别", "group by", "join", "主键", "外键"],
    "操作系统": ["操作系统", "进程", "线程", "调度", "死锁", "虚拟内存", "页面置换", "文件系统", "信号量", "缺页"],
    "大学英语": ["英语", "四级", "六级", "听力", "阅读", "写作", "单词", "词汇", "长难句", "作文", "翻译"],
    "概率论与数理统计": ["概率", "期望", "方差", "分布", "条件概率", "全概率", "贝叶斯", "估计", "随机变量", "协方差"],
    "C语言程序设计": ["c语言", "指针", "数组", "字符串", "结构体", "递归", "文件操作", "函数传参", "内存泄漏"],
}

INTENT_ACTION = {
    "知识点不会": ("补齐概念与适用条件", "用 3 道基础题完成第一次输出验证"),
    "方法不当": ("按题型归纳条件识别与工具选择", "用变式题训练迁移，而不是重复看解析"),
    "心态困惑": ("把大目标拆成今天能完成的最小行动", "先恢复掌控感，再安排学科任务"),
    "复习迷茫": ("按学分权重与掌握度缺口排序", "用 14 天节奏表把任务切成每日块"),
}

INTENT_TYPE_AFFINITY = {
    "知识点不会": {"知识点讲解": 5.0, "课件": 3.5, "微课视频": 3.2, "例题精讲": 2.0},
    "方法不当": {"例题精讲": 5.0, "分层习题": 4.2, "学习方法": 3.2, "微课视频": 2.0},
    "心态困惑": {"成长课堂": 5.2, "学习方法": 3.4, "知识点讲解": 1.6, "备考资料": 1.2},
    "复习迷茫": {"备考资料": 5.0, "学习工具": 4.4, "学习方法": 3.0, "分层习题": 2.0},
}

GENERIC_WEAK = {
    "知识点不会": "概念理解与知识迁移",
    "方法不当": "解题方法与迁移训练",
    "心态困惑": "学习信心与压力调适",
    "复习迷茫": "复习规划与时间管理",
}


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _stable_int(seed_text: str, modulo: int) -> int:
    digest = hashlib.sha256(seed_text.encode("utf-8")).hexdigest()
    return int(digest[:8], 16) % modulo


def _normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


# ---------------------------------------------------------------------------
# 意图识别
# ---------------------------------------------------------------------------
def classify_intent(question: str) -> dict[str, Any]:
    text = question.lower()
    scores: dict[str, float] = {}
    hits: dict[str, list[str]] = {}
    for intent, rule in INTENT_RULES.items():
        score = 0.0
        matched: list[str] = []
        for keyword in rule["keywords"]:
            count = text.count(keyword)
            if count:
                score += rule["weight"] * (1 + min(count - 1, 2) * 0.35)
                matched.append(keyword)
        scores[intent] = round(score, 2)
        hits[intent] = matched

    # 学科求助默认属于“知识点不会”，但语气词可以改变主导类型。
    if not any(scores.values()):
        scores["知识点不会"] = 0.8
        hits["知识点不会"] = []

    ranked = sorted(scores.items(), key=lambda item: (-item[1], INTENTS.index(item[0])))
    primary, top_score = ranked[0]
    total = sum(value for _, value in ranked) or 1
    ratio = top_score / total
    confidence = round(_clamp(0.58 + ratio * 0.4, 0.58, 0.97), 2)
    secondary = ranked[1][0] if len(ranked) > 1 and ranked[1][1] >= top_score * 0.62 > 0 else None
    return {
        "intent": primary,
        "confidence": confidence,
        "scores": scores,
        "hits": hits,
        "secondary": secondary,
    }


# ---------------------------------------------------------------------------
# 课程与知识点定位
# ---------------------------------------------------------------------------
def detect_course(question: str, kps: list[dict]) -> tuple[str, list[dict]]:
    """先看显式课程线索；显式命中时只在该课程内匹配知识点，避免泛词串课。"""
    text = question.lower()
    scores: dict[str, float] = {}
    for course, aliases in COURSE_ALIASES.items():
        score = 0.0
        for alias in aliases:
            if alias and alias in text:
                score += 2.4 if len(alias) >= 2 else 1.2
        if course in question:
            score += 5
        if score:
            scores[course] = score

    explicit = max(scores.items(), key=lambda item: item[1])[0] if scores else ""
    if explicit and scores.get(explicit, 0) >= 2.4:
        matched = match_knowledge_points(question, kps, course=explicit)
        return explicit, matched

    matched = match_knowledge_points(question, kps)
    if matched:
        return matched[0]["course"], matched
    return "", matched


def match_knowledge_points(question: str, kps: list[dict], course: str | None = None) -> list[dict]:
    text = question.lower()
    scored: list[tuple[float, dict]] = []
    for kp in kps:
        if course and kp["course"] != course:
            continue
        score = 0.0
        name = kp["name"].lower()
        if name and name in text:
            score += 7
        for keyword in [item for item in kp["keywords"].split(",") if item.strip()]:
            key = keyword.strip().lower()
            if key and key in text:
                if len(key) >= 3:
                    score += 2.6
                elif len(key) == 2:
                    score += 1.2
                else:
                    score += 0.3
        if score > 0:
            scored.append((score, kp))
    scored.sort(key=lambda item: (-item[0], item[1]["difficulty"]))
    return [{"score": score, **kp} for score, kp in scored[:4]]


def _fallback_kps(course: str, kps: list[dict]) -> list[dict]:
    pool = [kp for kp in kps if kp["course"] == course]
    pool.sort(key=lambda kp: (-kp["difficulty"], kp["id"]))
    selected = pool[:2] if pool else []
    return [{"score": 0, **kp} for kp in selected]


# ---------------------------------------------------------------------------
# 诊断组装
# ---------------------------------------------------------------------------
def _difficulty_label(question: str, weak: list[dict]) -> str:
    text = question
    if any(word in text for word in ("证明", "综合", "考研", "压轴", "建模")):
        return "较难"
    avg = sum(item.get("difficulty", 3) for item in weak) / max(len(weak), 1)
    if any(word in text for word in ("零基础", "入门")) and avg <= 3:
        return "基础"
    if avg >= 4.2:
        return "挑战"
    if avg >= 3.4:
        return "较难"
    if avg <= 2.3:
        return "基础"
    return "中等"


def _mastery_for(text: str, kp: dict, intent: str) -> int:
    penalty = {"知识点不会": 8, "方法不当": 5, "心态困惑": 7, "复习迷茫": 4}[intent]
    base = 76 - int(kp.get("difficulty", 3)) * 8 - penalty
    if any(word in text for word in ("完全", "总是", "老是", "一直", "每次")):
        base -= 6
    if any(word in text for word in ("有点", "稍微", "刚开始", "基础")):
        base += 5
    jitter = _stable_int(text + kp.get("name", ""), 13) - 6
    return int(_clamp(base + jitter, 28, 88))


def _misconceptions(intent: str, weak: list[dict]) -> list[str]:
    items: list[str] = []
    for kp in weak[:2]:
        pitfall = (kp.get("pitfall") or "").strip()
        if pitfall:
            items.append(pitfall)
    template = {
        "知识点不会": "把「{kp}」当作孤立结论记忆，缺少与前序知识的连接，导致换个问法就认不出。",
        "方法不当": "看到题目直接套模板，没有先判断适用条件与题型特征，步骤会但方向错。",
        "心态困惑": "把阶段性困难归因为能力不足，回避练习形成“越怕越不练”的负循环。",
        "复习迷茫": "复习以翻书、看视频为主，缺少限时输出与自测，容易产生“学过”的错觉。",
    }[intent]
    kp_name = weak[0]["name"] if weak else "核心知识"
    items.append(template.format(kp=kp_name))
    return list(dict.fromkeys(items))[:3]


def _ability_gaps(intent: str, weak: list[dict], mastery: int) -> list[dict]:
    kp_name = weak[0]["name"] if weak else "核心知识"
    base = [
        ("概念理解", _clamp(100 - mastery + 6, 32, 82), "能否复述定义与适用条件"),
        ("方法迁移", _clamp(100 - mastery - 2, 26, 78), "换条件、换问法后能否独立完成"),
        ("计算与表达", _clamp(100 - mastery + 12, 38, 88), "步骤是否规范、结果是否可复核"),
        ("知识连接", _clamp(100 - mastery + 2, 30, 80), f"「{kp_name}」与前后章节的联系"),
        ("复习规划", _clamp(100 - mastery + 16, 40, 90), "是否有可执行、可检查的计划"),
        ("心理韧性", _clamp(100 - mastery + 10, 36, 86), "遇到卡点时的坚持与求助方式"),
    ]
    order = {
        "知识点不会": ["概念理解", "知识连接", "方法迁移", "计算与表达"],
        "方法不当": ["方法迁移", "计算与表达", "概念理解", "知识连接"],
        "心态困惑": ["心理韧性", "复习规划", "方法迁移", "概念理解"],
        "复习迷茫": ["复习规划", "方法迁移", "心理韧性", "概念理解"],
    }[intent]
    lookup = {name: (score, note) for name, score, note in base}
    return [
        {"name": name, "score": int(round(lookup[name][0])), "note": lookup[name][1]}
        for name in order
    ]


def _summary(intent: str, course: str, weak: list[dict], mastery: int, difficulty: str) -> str:
    kp_names = "」「".join(item["name"] for item in weak[:2]) or "核心知识"
    action1, action2 = INTENT_ACTION[intent]
    return (
        f"AI 将本次问题判定为「{intent}」，知识定位在{course or '综合学业'}的「{kp_names}」。"
        f"预估综合掌握度 {mastery}/100，难度等级「{difficulty}」。"
        f"建议先{action1}，再{action2}。"
    )


def _tags(question: str, intent: str, course: str, weak: list[dict]) -> list[str]:
    tags = [intent]
    if course:
        tags.append(course)
    tags.extend(item["name"] for item in weak[:3])
    for label, words in (
        ("期末冲刺", ("期末", "考试", "备考")),
        ("考研备考", ("考研", "上岸")),
        ("四六级", ("四级", "六级")),
        ("证明题", ("证明", "存在")),
        ("代码实现", ("代码", "写不出", "编程")),
    ):
        if any(word in question for word in words):
            tags.append(label)
    return list(dict.fromkeys(tags))[:8]


def _resource_reason(resource: dict, intent: str, matched_kps: list[str], mastery: int) -> str:
    if matched_kps:
        kp_text = "」「".join(matched_kps[:2])
        return f"匹配薄弱点「{kp_text}」，{resource['type']}设计，预计 {resource['minutes']} 分钟完成。"
    if resource["course"] == "通用能力":
        return f"针对「{intent}」的通用策略，短时高效，可作为本次帮扶的第一步。"
    return f"围绕本次诊断结论推荐的{resource['type']}，帮助建立完整的解题链条。"


def recommend_resources(
    intent: str, course: str, weak_names: list[str], mastery: int, resources: list[dict]
) -> list[dict]:
    affinity = INTENT_TYPE_AFFINITY[intent]
    scored: list[tuple[float, dict, list[str]]] = []
    for resource in resources:
        resource_kps = database.json_load(resource.get("kp_ids"), []) or []
        overlap = [name for name in resource_kps if name in weak_names]
        score = 0.0
        score += len(overlap) * 6.0
        if weak_names:
            if weak_names[0] in resource["title"]:
                score += 5.0
            if resource_kps and resource_kps[0] == weak_names[0]:
                score += 3.0
        if resource["course"] == course:
            score += 4.0
        elif resource["course"] == "通用能力":
            score += 1.6 if intent in {"心态困惑", "复习迷茫"} else 0.4
        score += affinity.get(resource["type"], 0.6)
        level = resource.get("level")
        if mastery < 45 and level == "基础":
            score += 2.2
        elif 45 <= mastery <= 68 and level == "进阶":
            score += 2.0
        elif mastery > 68 and level == "进阶":
            score += 0.8
        score += (_stable_int(resource["title"] + intent, 9) - 4) * 0.2
        if score > 0:
            scored.append((score, resource, overlap))

    scored.sort(key=lambda item: (-item[0], item[1]["id"]))
    picked = scored[:5]
    return [
        {
            **resource,
            "kp_ids": database.json_load(resource.get("kp_ids"), []),
            "reason": _resource_reason(resource, intent, overlap, mastery),
            "relevance": round(_clamp(score / 22, 0.35, 0.99), 2),
        }
        for score, resource, overlap in picked
    ]


# ---------------------------------------------------------------------------
# 可选的大模型增强
# ---------------------------------------------------------------------------
def llm_available() -> bool:
    return bool(config.LLM_API_KEY)


def _llm_analyze(question: str, base: dict) -> dict | None:
    if not llm_available():
        return None
    schema_hint = {
        "intent": "知识点不会|方法不当|心态困惑|复习迷茫",
        "summary": "120 字以内的诊断结论",
        "misconceptions": ["最多 3 条学习误区"],
        "tags": ["最多 6 个标签"],
        "mastery": "1-100 的整数",
        "difficulty": "基础|中等|较难|挑战",
    }
    prompt = (
        "你是高校学情诊断专家。请基于学生的原始提问输出严格的 JSON，不要 Markdown。"
        f"字段规范：{json.dumps(schema_hint, ensure_ascii=False)}。"
        f"\n本地引擎初判：{base['intent']}；课程：{base['course']}；"
        f"薄弱点：{', '.join(item['name'] for item in base['weak_points'])}。"
        f"\n学生提问：{question}"
    )
    payload = {
        "model": config.LLM_MODEL,
        "messages": [
            {"role": "system", "content": "你是严谨、克制、可解释的学情诊断助手。"},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.2,
        "response_format": {"type": "json_object"},
    }
    request = urllib.request.Request(
        config.LLM_BASE_URL + "/chat/completions",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + config.LLM_API_KEY,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=config.LLM_TIMEOUT) as response:
            body = json.loads(response.read().decode("utf-8"))
        content = body["choices"][0]["message"]["content"]
        parsed = json.loads(content)
        if parsed.get("intent") not in INTENTS:
            return None
        return parsed if isinstance(parsed, dict) else None
    except (urllib.error.URLError, TimeoutError, KeyError, ValueError, IndexError, TypeError):
        return None


# ---------------------------------------------------------------------------
# 主入口
# ---------------------------------------------------------------------------
def analyze(question: str) -> dict[str, Any]:
    started = time.perf_counter()
    question = _normalize(question)
    with database.db() as connection:
        kps = [dict(row) for row in connection.execute(
            "SELECT id, course, name, chapter, difficulty, keywords, description, pitfall "
            "FROM knowledge_points ORDER BY id"
        )]
        resources = [dict(row) for row in connection.execute(
            "SELECT id, title, type, course, kp_ids, level, minutes, summary, content, source "
            "FROM resources ORDER BY id"
        )]

    intent_result = classify_intent(question)
    intent = intent_result["intent"]
    course, matched = detect_course(question, kps)
    if not matched and course and intent in {"知识点不会", "方法不当"}:
        matched = _fallback_kps(course, kps)
    weak_raw = matched[:3]
    if not weak_raw:
        weak_raw = []

    weak_points: list[dict] = []
    for kp in weak_raw:
        weak_points.append(
            {
                "name": kp["name"],
                "course": kp["course"],
                "chapter": kp.get("chapter", ""),
                "difficulty": int(kp.get("difficulty", 3)),
                "mastery": _mastery_for(question, kp, intent),
            }
        )
    if not weak_points:
        weak_points = [
            {
                "name": GENERIC_WEAK[intent],
                "course": "综合能力",
                "chapter": "学习支持",
                "difficulty": 2,
                "mastery": int(_clamp(58 - 8 + (_stable_int(question, 11) - 5), 30, 82)),
            }
        ]
    if not course:
        course = weak_points[0]["course"] if weak_points[0]["course"] != "综合能力" else "综合学业"

    weights = [1.0, 0.7, 0.5][: len(weak_points)]
    mastery = int(round(
        sum(item["mastery"] * weight for item, weight in zip(weak_points, weights))
        / sum(weights)
    ))
    difficulty = _difficulty_label(question, [
        {"difficulty": item["difficulty"]} for item in weak_points
    ])
    misconceptions = _misconceptions(intent, weak_points)
    ability_gaps = _ability_gaps(intent, weak_points, mastery)
    tags = _tags(question, intent, course, weak_points)
    summary = _summary(intent, course, weak_points, mastery, difficulty)
    weak_names = [item["name"] for item in weak_points]
    recommendations = recommend_resources(intent, course, weak_names, mastery, resources)

    ai_mode = "local"
    engine_label = "本地学情推理引擎"
    if llm_available():
        refined = _llm_analyze(question, {
            "intent": intent,
            "course": course,
            "weak_points": weak_points,
        })
        if refined:
            ai_mode = "llm"
            engine_label = f"大模型增强 · {config.LLM_MODEL}"
            intent = refined.get("intent", intent)
            summary = str(refined.get("summary") or summary)[:300]
            extra_mis = [
                str(item)[:120] for item in (refined.get("misconceptions") or []) if str(item).strip()
            ]
            misconceptions = list(dict.fromkeys(extra_mis + misconceptions))[:3]
            tags = list(dict.fromkeys(
                [str(item)[:16] for item in (refined.get("tags") or [])] + tags
            ))[:8]
            try:
                mastery = int(_clamp(int(refined.get("mastery", mastery)), 25, 92))
            except (TypeError, ValueError):
                pass
            if refined.get("difficulty") in {"基础", "中等", "较难", "挑战"}:
                difficulty = refined["difficulty"]

    trace = [
        {"step": "语义解析", "detail": f"提取 {len(tags)} 个语义标签，识别 {len(weak_points)} 个知识锚点"},
        {"step": "意图识别", "detail": f"判定为「{intent}」，置信度 {round(intent_result['confidence'] * 100)}%"},
        {"step": "知识定位", "detail": "、".join(weak_names)},
        {"step": "掌握度评估", "detail": f"综合掌握度 {mastery}/100，难度「{difficulty}」"},
        {"step": "资源匹配", "detail": f"从校本知识库匹配 {len(recommendations)} 份资源"},
    ]
    took_ms = int((time.perf_counter() - started) * 1000)
    structured = {
        "schema": "zhixue.diagnosis/v1",
        "intent": {"label": intent, "confidence": intent_result["confidence"], "secondary": intent_result["secondary"]},
        "course": course,
        "problem_tags": tags,
        "weak_points": weak_points,
        "misconceptions": misconceptions,
        "ability_gaps": ability_gaps,
        "difficulty": difficulty,
        "mastery": mastery,
        "summary": summary,
        "trace": trace,
        "engine": {"mode": ai_mode, "label": engine_label, "latency_ms": took_ms},
    }
    return {
        "course": course,
        "intent": intent,
        "intent_confidence": intent_result["confidence"],
        "intent_secondary": intent_result["secondary"],
        "difficulty": difficulty,
        "mastery": mastery,
        "weak_points": weak_points,
        "misconceptions": misconceptions,
        "ability_gaps": ability_gaps,
        "tags": tags,
        "summary": summary,
        "structured": structured,
        "trace": trace,
        "recommendations": recommendations,
        "ai_mode": ai_mode,
        "engine_label": engine_label,
        "duration_ms": took_ms,
    }


def agent_status() -> dict[str, Any]:
    return {
        "mode": "llm" if llm_available() else "local",
        "label": f"大模型增强 · {config.LLM_MODEL}" if llm_available() else "本地学情推理引擎",
        "llm_ready": llm_available(),
        "model": config.LLM_MODEL if llm_available() else "zhixue-local-v3",
        "intents": INTENTS,
    }
