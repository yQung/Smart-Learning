"""智学平台运行配置。

零第三方依赖，所有路径默认相对本包，可用环境变量覆盖。
启动入口仍为项目根目录的 ``app.py`` / ``启动平台.bat``。
"""
from __future__ import annotations

import os
from pathlib import Path


def _env_bool(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() not in {"0", "false", "no", "off", ""}


PACKAGE_DIR = Path(__file__).resolve().parent
BASE_DIR = PACKAGE_DIR

DATA_DIR = Path(os.environ.get("CLASSROOM_DATA_DIR", str(PACKAGE_DIR / "data"))).expanduser().resolve()
DB_PATH = DATA_DIR / "zhixue.db"
TMP_DIR = DATA_DIR / "tmp"
STATIC_DIR = PACKAGE_DIR / "webui"
# 兼容旧启动脚本中的模型服务探测（本产品不依赖 3D 模型服务）。
MODELS_DIR = DATA_DIR / "models"

HOST = os.environ.get("CLASSROOM_HOST", "127.0.0.1")
# Render/Railway/Fly 等云平台通常注入 PORT；本地启动仍可使用 CLASSROOM_PORT。
PORT = int(os.environ.get("CLASSROOM_PORT") or os.environ.get("PORT") or "8765")
REMOTE_PORT = int(os.environ.get("CLASSROOM_REMOTE_PORT", "8766"))

# 旧版“跨站演示资源库”已不使用，保持关闭。
ENABLE_DEMO_REMOTE = _env_bool("CLASSROOM_DEMO_REMOTE", False)
ALLOW_PRIVATE_CATALOGS = False
REMOTE_TIMEOUT_SECONDS = 4
MAX_REMOTE_SOURCES = 0

SESSION_COOKIE = "zhixue_session"
SESSION_DAYS = 7
PASSWORD_ITERATIONS = 120_000
MAX_JSON_BYTES = 2_000_000
MAX_QUESTION_CHARS = 2000
MAX_FOLLOWUP_CHARS = 600

APP_NAME = "智学 · AI学情与学工平台"
APP_SHORT_NAME = "智学"
APP_VERSION = "3.0.0"

# --- 大模型接入（可选） -----------------------------------------------------
# 未配置 API Key 时，平台使用内置的本地学情推理引擎，全部功能仍可离线闭环。
LLM_API_KEY = os.environ.get("CLASSROOM_LLM_API_KEY", "").strip()
LLM_BASE_URL = os.environ.get("CLASSROOM_LLM_BASE", "https://api.deepseek.com").rstrip("/")
LLM_MODEL = os.environ.get("CLASSROOM_LLM_MODEL", "deepseek-chat")
LLM_TIMEOUT = float(os.environ.get("CLASSROOM_LLM_TIMEOUT", "20"))

# --- 导出 ------------------------------------------------------------------
EDGE_CANDIDATES = [
    os.path.join(os.environ.get("ProgramFiles(x86)", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
    os.path.join(os.environ.get("ProgramFiles", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
    os.path.join(os.environ.get("ProgramFiles", ""), "Google", "Chrome", "Application", "chrome.exe"),
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/google-chrome",
    "/usr/bin/google-chrome-stable",
]
PDF_TIMEOUT_SECONDS = 30

# 旧启动脚本读取的品牌字段（保持兼容）。
MODEL_SERVICE_URL = "http://127.0.0.1:5178"
MODEL_SERVICE_TIMEOUT = 1.0
MODEL_SERVICE_TOKEN = ""
