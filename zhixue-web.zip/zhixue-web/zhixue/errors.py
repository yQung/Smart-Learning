"""业务异常：统一转换为前端可读的 JSON 错误。"""
from __future__ import annotations


class AppError(Exception):
    def __init__(self, status: int, code: str, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message


def bad_request(message: str, code: str = "BAD_REQUEST") -> AppError:
    return AppError(400, code, message)


def unauthorized(message: str = "请先登录") -> AppError:
    return AppError(401, "UNAUTHORIZED", message)


def forbidden(message: str = "没有访问该功能的权限") -> AppError:
    return AppError(403, "FORBIDDEN", message)


def not_found(message: str = "资源不存在") -> AppError:
    return AppError(404, "NOT_FOUND", message)
