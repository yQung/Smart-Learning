"""导出能力：原生 XLSX、打印版 HTML 与 Edge/Chrome 无头 PDF。

不依赖任何第三方库：XLSX 由 zipfile + OOXML 直接生成；
PDF 通过系统自带浏览器（Edge/Chrome）的 ``--print-to-pdf`` 渲染，
保证中文字体与排版效果。
"""
from __future__ import annotations

import html
import io
import os
import shutil
import subprocess
import uuid
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

from . import config


# ---------------------------------------------------------------------------
# 通用
# ---------------------------------------------------------------------------
def _xml_escape(value: Any) -> str:
    text = "" if value is None else str(value)
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _text(value: Any) -> str:
    if value is None:
        return ""
    return str(value)


def _col_letter(index: int) -> str:
    letters = ""
    index += 1
    while index:
        index, remainder = divmod(index - 1, 26)
        letters = chr(65 + remainder) + letters
    return letters


# ---------------------------------------------------------------------------
# XLSX
# ---------------------------------------------------------------------------
_CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
{sheet_overrides}
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>"""

_ROOT_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""

_STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="4">
<font><sz val="10.5"/><name val="Microsoft YaHei"/></font>
<font><b/><sz val="10.5"/><color rgb="FFFFFFFF"/><name val="Microsoft YaHei"/></font>
<font><b/><sz val="15"/><color rgb="FF1F2A44"/><name val="Microsoft YaHei"/></font>
<font><b/><sz val="12"/><color rgb="FF4F46E5"/><name val="Microsoft YaHei"/></font>
</fonts>
<fills count="4">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF4F46E5"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFF3F4FF"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2">
<border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FFE2E8F0"/></left><right style="thin"><color rgb="FFE2E8F0"/></right><top style="thin"><color rgb="FFE2E8F0"/></top><bottom style="thin"><color rgb="FFE2E8F0"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
<cellXfs count="6">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="3" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
</cellXfs>
</styleSheet>"""


def _sheet_xml(sheet: dict) -> str:
    rows: list[list[Any]] = sheet.get("rows") or []
    widths: list[int] = sheet.get("widths") or []
    frozen = bool(sheet.get("frozen", True))
    cols = ""
    if widths:
        cols = "<cols>" + "".join(
            f'<col min="{index + 1}" max="{index + 1}" width="{width}" customWidth="1"/>'
            for index, width in enumerate(widths)
        ) + "</cols>"
    body: list[str] = []
    last_col = _col_letter(max((len(row) for row in rows), default=1) - 1)
    for row_index, row in enumerate(rows, start=1):
        cells: list[str] = []
        for col_index, value in enumerate(row):
            ref = f"{_col_letter(col_index)}{row_index}"
            style = 1 if row_index == 1 else (2 if sheet.get("wrap", True) else 3)
            if isinstance(value, dict):
                style = int(value.get("style", style))
                value = value.get("value", "")
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                cells.append(f'<c r="{ref}" s="{style}" t="n"><v>{value}</v></c>')
            else:
                text = _xml_escape(_text(value))
                cells.append(
                    f'<c r="{ref}" s="{style}" t="inlineStr"><is><t xml:space="preserve">{text}</t></is></c>'
                )
        body.append(f'<row r="{row_index}">{"".join(cells)}</row>')
    pane = (
        f'<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
        if frozen and len(rows) > 1
        else ""
    )
    auto_filter = (
        f'<autoFilter ref="A1:{last_col}{len(rows)}"/>' if len(rows) > 1 else ""
    )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f'<sheetViews><sheetView workbookViewId="0">{pane}</sheetView></sheetViews>'
        f'{cols}<sheetData>{"".join(body)}</sheetData>{auto_filter}'
        '<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>'
        '<pageSetup orientation="landscape" fitToWidth="1"/>'
        '</worksheet>'
    )


def build_xlsx(sheets: list[dict], *, title: str = "学工台账") -> bytes:
    """生成标准 .xlsx 文件（多工作表、表头样式、冻结首行、自动筛选）。"""
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        overrides = "".join(
            f'<Override PartName="/xl/worksheets/sheet{index + 1}.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            for index in range(len(sheets))
        )
        archive.writestr("[Content_Types].xml", _CONTENT_TYPES.format(sheet_overrides=overrides))
        archive.writestr("_rels/.rels", _ROOT_RELS)
        workbook_sheets = "".join(
            f'<sheet name="{_xml_escape(sheet.get("name") or f"Sheet{index + 1}")}" '
            f'sheetId="{index + 1}" r:id="rId{index + 1}"/>'
            for index, sheet in enumerate(sheets)
        )
        archive.writestr(
            "xl/workbook.xml",
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            f'<sheets>{workbook_sheets}</sheets></workbook>',
        )
        rels = "".join(
            f'<Relationship Id="rId{index + 1}" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
            f'Target="worksheets/sheet{index + 1}.xml"/>'
            for index in range(len(sheets))
        )
        rels += (
            f'<Relationship Id="rId{len(sheets) + 1}" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        )
        archive.writestr(
            "xl/_rels/workbook.xml.rels",
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            f"{rels}</Relationships>",
        )
        archive.writestr("xl/styles.xml", _STYLES)
        for index, sheet in enumerate(sheets):
            archive.writestr(f"xl/worksheets/sheet{index + 1}.xml", _sheet_xml(sheet))
        now = datetime.now().astimezone().isoformat(timespec="seconds")
        archive.writestr(
            "docProps/core.xml",
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            f"<dc:title>{_xml_escape(title)}</dc:title><dc:creator>智学平台</dc:creator>"
            f'<dcterms:created xsi:type="dcterms:W3CDTF">{now}</dcterms:created>'
            "</cp:coreProperties>",
        )
        archive.writestr(
            "docProps/app.xml",
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">'
            "<Application>ZHIXUE</Application></Properties>",
        )
    return buffer.getvalue()


def ledger_workbook(rows: list[dict], summary: dict) -> bytes:
    headers = [
        "台账编号", "学生姓名", "学号", "班级", "课程", "问题类型",
        "学生原始问题", "AI 诊断结论", "薄弱知识点", "掌握度", "难度",
        "帮扶资源", "帮扶时间", "跟进状态", "跟进记录", "数据指纹",
    ]
    data = [headers]
    for row in rows:
        data.append([
            row.get("code", ""),
            row.get("student_name", ""),
            row.get("student_no", ""),
            row.get("class_name", ""),
            row.get("course", ""),
            row.get("intent", ""),
            row.get("problem", ""),
            row.get("diagnosis_summary", ""),
            "、".join(row.get("weak_point_names") or []),
            row.get("mastery", ""),
            row.get("difficulty", ""),
            row.get("resource_summary", ""),
            (row.get("help_time") or "").replace("T", " ")[:19],
            row.get("status", ""),
            row.get("follow_up", ""),
            (row.get("hash") or "")[:16],
        ])
    summary_rows = [
        ["统计项", "数值"],
        ["导出时间", datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S")],
        ["台账总数", summary.get("total", len(rows))],
        ["待跟进", summary.get("pending", 0)],
        ["跟进中", summary.get("following", 0)],
        ["已闭环", summary.get("closed", 0)],
        ["涉及学生", summary.get("students", 0)],
        ["覆盖课程", summary.get("courses", 0)],
        ["AI 引擎", summary.get("engine", "本地学情推理引擎")],
        ["数据说明", "台账正文由 AI 自动生成并写入哈希链，导出文件仅供归档与报备。"],
    ]
    return build_xlsx(
        [
            {"name": "台账明细", "rows": data, "widths": [16, 11, 12, 26, 14, 10, 46, 46, 24, 8, 8, 30, 18, 10, 36, 18]},
            {"name": "统计摘要", "rows": summary_rows, "widths": [18, 72], "wrap": True},
        ],
        title="AI 学工台账",
    )


# ---------------------------------------------------------------------------
# HTML / PDF
# ---------------------------------------------------------------------------
def _esc(value: Any) -> str:
    return html.escape(_text(value))


def _section_html(section: dict) -> str:
    parts = [f'<section class="sec"><h2>{_esc(section.get("title"))}</h2>']
    for paragraph in section.get("paragraphs") or []:
        parts.append(f"<p>{_esc(paragraph)}</p>")
    bullets = section.get("bullets") or []
    if bullets:
        parts.append("<ul>" + "".join(f"<li>{_esc(item)}</li>" for item in bullets) + "</ul>")
    table = section.get("table")
    if table:
        head = "".join(f"<th>{_esc(cell)}</th>" for cell in table.get("headers") or [])
        body = "".join(
            "<tr>" + "".join(f"<td>{_esc(cell)}</td>" for cell in row) + "</tr>"
            for row in table.get("rows") or []
        )
        parts.append(f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>")
    callout = section.get("callout")
    if callout:
        parts.append(f'<div class="callout">{_esc(callout)}</div>')
    parts.append("</section>")
    return "".join(parts)


def _base_css() -> str:
    return """
    * { box-sizing: border-box; }
    body { font-family: "Microsoft YaHei", "PingFang SC", "SimSun", sans-serif;
           color: #1f2a44; margin: 0; background: #fff; font-size: 12.5px; line-height: 1.75; }
    .page { padding: 10mm 8mm; }
    .brandbar { display: flex; justify-content: space-between; align-items: flex-end;
                border-bottom: 2.5px solid #4f46e5; padding-bottom: 8px; margin-bottom: 18px; }
    .brand { font-size: 15px; font-weight: 700; letter-spacing: .5px; color: #4f46e5; }
    .brand small { display: block; font-weight: 400; color: #64748b; font-size: 10.5px; letter-spacing: 0; margin-top: 2px; }
    .meta { text-align: right; font-size: 10.5px; color: #64748b; line-height: 1.6; }
    h1 { font-size: 24px; text-align: center; margin: 10px 0 4px; letter-spacing: 2px; }
    .subtitle { text-align: center; color: #64748b; font-size: 11.5px; margin-bottom: 18px; }
    .info-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 0;
                 border: 1px solid #dbe2f0; border-radius: 8px; overflow: hidden; margin-bottom: 16px; }
    .info-item { padding: 8px 12px; border-right: 1px solid #e6ebf5; border-bottom: 1px solid #eef2f9; }
    .info-item:nth-child(4n) { border-right: none; }
    .info-item label { display: block; color: #8894ab; font-size: 10px; letter-spacing: .5px; }
    .info-item b { font-size: 12.5px; font-weight: 600; }
    .metrics { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 18px; }
    .metric { border: 1px solid #e2e8f5; border-radius: 8px; padding: 10px 14px; background: #f8faff; }
    .metric span { color: #7c89a3; font-size: 10.5px; display: block; }
    .metric b { font-size: 20px; color: #312e81; }
    .metric b em { font-size: 11px; font-style: normal; color: #7c89a3; margin-left: 2px; }
    .sec { margin-top: 16px; page-break-inside: auto; }
    .sec h2 { font-size: 14px; color: #312e81; border-left: 4px solid #4f46e5; padding-left: 9px; margin: 0 0 8px; }
    .sec p { margin: 4px 0 8px; text-align: justify; }
    .sec ul { margin: 4px 0 8px; padding-left: 20px; }
    .sec li { margin: 2px 0; }
    table { width: 100%; border-collapse: collapse; margin: 6px 0 10px; font-size: 11px; }
    th { background: #eef2ff; color: #3730a3; font-weight: 600; }
    th, td { border: 1px solid #dbe2f0; padding: 6px 8px; text-align: left; vertical-align: top; }
    tr { page-break-inside: avoid; }
    .callout { background: #f5f3ff; border: 1px solid #ddd6fe; border-left: 4px solid #7c3aed;
               border-radius: 6px; padding: 9px 12px; color: #4c1d95; margin: 8px 0 10px; }
    .foot { margin-top: 22px; border-top: 1px solid #dbe2f0; padding-top: 8px;
            display: flex; justify-content: space-between; color: #94a3b8; font-size: 9.5px; }
    .fingerprint { font-family: Consolas, monospace; }
    .sign { margin-top: 26px; display: flex; justify-content: flex-end; gap: 60px; font-size: 11.5px; color: #475569; }
    .sign span { border-bottom: 1px solid #94a3b8; padding: 0 40px 2px 0; }
    @page { size: A4; margin: 14mm 12mm; }
    .print-tip { position: fixed; right: 18px; bottom: 18px; z-index: 9;
                 background: #312e81; color: #fff; border-radius: 10px;
                 padding: 10px 14px; font-size: 11px; box-shadow: 0 10px 26px rgba(49,46,129,.3); }
    @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } .page { padding: 0; } .print-tip { display: none; } }
    """


def report_html(report: dict) -> str:
    student = report.get("student") or {}
    metrics = report.get("metrics") or []
    info = report.get("info") or []
    sections = report.get("sections") or []
    metric_html = "".join(
        f'<div class="metric"><span>{_esc(item.get("label"))}</span>'
        f'<b>{_esc(item.get("value"))}<em>{_esc(item.get("unit"))}</em></b></div>'
        for item in metrics
    )
    info_html = "".join(
        f'<div class="info-item"><label>{_esc(item.get("label"))}</label><b>{_esc(item.get("value"))}</b></div>'
        for item in info
    )
    body = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>{_esc(report.get("title"))}</title>
<style>{_base_css()}</style></head>
<body><div class="page">
<div class="brandbar">
  <div class="brand">智学 · AI 学情与学工平台<small>ZHIXUE ACADEMIC INTELLIGENCE</small></div>
  <div class="meta">报告编号：{_esc(report.get("code"))}<br>生成时间：{_esc((report.get("generated_at") or "").replace("T", " ")[:19])}<br>生成方式：AI 自动生成</div>
</div>
<h1>{_esc(report.get("title"))}</h1>
<div class="subtitle">{_esc(report.get("subtitle"))}</div>
<div class="info-grid">{info_html}</div>
<div class="metrics">{metric_html}</div>
{"".join(_section_html(section) for section in sections)}
<div class="sign"><div>辅导员签字：<span></span></div><div>日期：<span></span></div></div>
<div class="foot">
  <span>本报告由智学平台 AI 学情 Agent 依据真实问诊记录自动生成，数据可在“数据留痕”中校验。</span>
  <span class="fingerprint">SHA-256 {_esc((report.get("hash") or "")[:32])}…</span>
</div>
</div>
<div class="print-tip">打印提示：按 Ctrl+P，选择“另存为 PDF”即可归档</div>
</body></html>"""
    return body


def ledgers_html(rows: list[dict], summary: dict) -> str:
    head = "".join(
        f"<th>{_esc(item)}</th>" for item in
        ["台账编号", "学生", "问题类型", "课程", "掌握度", "帮扶时间", "状态"]
    )
    body = "".join(
        "<tr>"
        f"<td>{_esc(row.get('code'))}</td>"
        f"<td>{_esc(row.get('student_name'))}<br><span style='color:#94a3b8'>{_esc(row.get('student_no'))}</span></td>"
        f"<td>{_esc(row.get('intent'))}</td>"
        f"<td>{_esc(row.get('course'))}</td>"
        f"<td>{_esc(row.get('mastery'))}</td>"
        f"<td>{_esc((row.get('help_time') or '').replace('T', ' ')[:16])}</td>"
        f"<td>{_esc(row.get('status'))}</td>"
        "</tr>"
        for row in rows
    )
    detail = "".join(
        f'<div class="callout" style="margin:10px 0"><b>{_esc(row.get("student_name"))} · {_esc(row.get("code"))}</b><br>'
        f'{_esc(row.get("problem"))}<br>'
        f'<span style="color:#6d28d9">AI 诊断：</span>{_esc(row.get("diagnosis_summary"))}<br>'
        f'<span style="color:#6d28d9">帮扶资源：</span>{_esc(row.get("resource_summary"))}</div>'
        for row in rows[:20]
    )
    return f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>学工台账汇总</title>
<style>{_base_css()}
.detail-title {{ font-size: 15px; color: #312e81; margin: 22px 0 8px; border-left: 4px solid #7c3aed; padding-left: 9px; }}
</style></head><body><div class="page">
<div class="brandbar">
  <div class="brand">智学 · AI 学情与学工平台<small>AI 自动化学工台账</small></div>
  <div class="meta">导出时间：{_esc(datetime.now().astimezone().strftime("%Y-%m-%d %H:%M"))}<br>台账数量：{len(rows)} 条<br>数据指纹链：已校验</div>
</div>
<h1>学生学情帮扶台账汇总</h1>
<div class="subtitle">{_esc(summary.get("class_name") or "全部班级")} · {_esc(summary.get("range_text") or "全部时间")}</div>
<div class="metrics">
  <div class="metric"><span>台账总数</span><b>{summary.get("total", len(rows))}<em>条</em></b></div>
  <div class="metric"><span>待跟进</span><b>{summary.get("pending", 0)}<em>条</em></b></div>
  <div class="metric"><span>已闭环</span><b>{summary.get("closed", 0)}<em>条</em></b></div>
  <div class="metric"><span>涉及学生</span><b>{summary.get("students", 0)}<em>人</em></b></div>
</div>
<section class="sec"><h2>一、台账明细</h2>
<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></section>
<div class="detail-title">二、记录摘要（前 20 条）</div>
{detail}
<div class="foot"><span>本文件由智学平台自动生成，正文与哈希指纹已写入不可篡改留痕。</span>
<span class="fingerprint">ZHIXUE · {_esc(summary.get("engine", "本地学情推理引擎"))}</span></div>
</div>
<div class="print-tip">打印提示：按 Ctrl+P，选择“另存为 PDF”即可归档</div>
</body></html>"""


def _find_browser() -> str | None:
    for candidate in config.EDGE_CANDIDATES:
        if candidate and os.path.isfile(candidate):
            return candidate
    for name in ("msedge", "chrome", "chromium", "chromium-browser", "google-chrome", "google-chrome-stable"):
        found = shutil.which(name)
        if found:
            return found
    return None


def html_to_pdf(html_text: str) -> bytes | None:
    """调用系统浏览器无头模式打印 PDF；失败返回 None（由前端降级为打印页）。"""
    browser = _find_browser()
    if not browser:
        return None
    token = uuid.uuid4().hex
    workdir = config.TMP_DIR / f"pdf-{token}"
    workdir.mkdir(parents=True, exist_ok=True)
    html_path = workdir / "document.html"
    pdf_path = workdir / "document.pdf"
    profile = workdir / "profile"
    html_path.write_text(html_text, encoding="utf-8")
    command = [
        browser,
        "--headless=new",
        "--disable-gpu",
        "--no-sandbox",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-extensions",
        "--disable-background-networking",
        f"--user-data-dir={profile}",
        "--virtual-time-budget=2500",
        "--print-to-pdf-no-header",
        f"--print-to-pdf={pdf_path}",
        html_path.as_uri(),
    ]
    try:
        subprocess.run(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=config.PDF_TIMEOUT_SECONDS,
            check=False,
        )
        if pdf_path.exists() and pdf_path.stat().st_size > 800:
            data = pdf_path.read_bytes()
            if data[:4] == b"%PDF":
                return data
        return None
    except (OSError, subprocess.SubprocessError):
        return None
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def safe_filename(name: str) -> str:
    cleaned = "".join(ch for ch in (name or "export") if ch not in '\\/:*?"<>|\r\n')
    return cleaned.strip()[:80] or "export"
