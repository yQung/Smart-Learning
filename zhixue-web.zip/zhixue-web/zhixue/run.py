"""智学平台独立启动入口。

可直接在任意目录运行：

    python run.py --open
    python run.py --port 8767
    python run.py --reset-data --open

该文件位于 classroom 包内，会把上一级目录加入 sys.path 后导入本包，
因此不再依赖项目根目录的 app.py。
"""
from __future__ import annotations

import argparse
import importlib
import shutil
import sys
import threading
import webbrowser
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
PARENT_DIR = PACKAGE_DIR.parent
PACKAGE_NAME = PACKAGE_DIR.name

if str(PARENT_DIR) not in sys.path:
    sys.path.insert(0, str(PARENT_DIR))

if not PACKAGE_NAME.isidentifier():
    print(f"[错误] 目录名 {PACKAGE_NAME!r} 不是合法的 Python 包名，请保持 classroom 目录名。")
    raise SystemExit(1)

config = importlib.import_module(f"{PACKAGE_NAME}.config")
database = importlib.import_module(f"{PACKAGE_NAME}.database")
ai_engine = importlib.import_module(f"{PACKAGE_NAME}.ai_engine")
web = importlib.import_module(f"{PACKAGE_NAME}.web")


def _print_banner(host: str, port: int, seeded: bool) -> None:
    display_host = "127.0.0.1" if host in {"0.0.0.0", "::"} else host
    engine = ai_engine.agent_status()
    print("")
    print("=" * 64)
    print(f"  {config.APP_NAME}   v{config.APP_VERSION}")
    print("  学生学情自助诊断 · 学习资源推送 · 学工台账自动化")
    print("=" * 64)
    print(f"  访问网址   http://{display_host}:{port}")
    print("  学生账号   20240101 / Student123!")
    print("  辅导员账号 counselor / Counselor123!")
    print(f"  项目目录   {PACKAGE_DIR}")
    print(f"  数据文件   {config.DB_PATH}")
    print(f"  AI 引擎    {engine['label']}")
    print("-" * 64)
    print("  启动后保持本窗口运行；按 Ctrl+C 停止服务。")
    if seeded:
        print("  已初始化演示数据。")
    print("=" * 64)
    print("")


def _reset_data() -> None:
    for suffix in ("", "-wal", "-shm"):
        path = Path(str(config.DB_PATH) + suffix)
        if path.exists():
            path.unlink()
    if config.TMP_DIR.exists():
        shutil.rmtree(config.TMP_DIR, ignore_errors=True)
    print("[提示] 已清除旧演示数据库，将重新初始化。")


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass

    parser = argparse.ArgumentParser(description="智学 · AI 学情诊断与学工辅助平台")
    parser.add_argument("--host", default=config.HOST, help="监听地址，默认 127.0.0.1")
    parser.add_argument("--port", type=int, default=config.PORT, help="监听端口，默认 8765")
    parser.add_argument("--open", action="store_true", help="启动后自动打开浏览器")
    parser.add_argument("--reset-data", action="store_true", help="清除并重建演示数据")
    args = parser.parse_args()

    if args.reset_data:
        _reset_data()

    seeded = database.seed_demo()

    try:
        server = web.create_server(args.host, args.port)
    except OSError as exc:
        print(f"[错误] 无法监听 {args.host}:{args.port}：{exc}")
        print("请确认 8765 端口未被占用，或使用 --port 8767 换一个端口。")
        return 1

    _print_banner(args.host, args.port, seeded)

    if args.open:
        display_host = "127.0.0.1" if args.host in {"0.0.0.0", "::"} else args.host
        threading.Timer(
            1.0, lambda: webbrowser.open(f"http://{display_host}:{args.port}")
        ).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n正在停止服务……")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
