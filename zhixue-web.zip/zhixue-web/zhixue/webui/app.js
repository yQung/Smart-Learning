/* =========================================================================
   智学 · AI 学情诊断与学工辅助平台
   ========================================================================= */
(() => {
  "use strict";

  const app = document.getElementById("app");
  const modalRoot = document.getElementById("modal-root");
  const toastRoot = document.getElementById("toast-root");

  const state = {
    user: null,
    csrf: null,
    meta: null,
    overview: null,
    dash: { days: 14, classId: "" },
    studentFilters: { q: "", risk: "all", status: "all" },
    ledgerFilters: { q: "", intent: "", status: "", course: "", from: "", to: "", page: 1, page_size: 10 },
    resourceFilters: { q: "", type: "", course: "" },
    studentId: null,
  };

  const ICONS = {
    sparkle: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M18.5 16.5l.6 1.9 1.9.6-1.9.6-.6 1.9-.6-1.9-1.9-.6 1.9-.6z"/>',
    chat: '<path d="M21 11.5a8.4 8.4 0 0 1-8.5 8.5 9 9 0 0 1-3.9-.9L3 21l1.9-5.6A8.4 8.4 0 0 1 12.5 3 8.4 8.4 0 0 1 21 11.5z"/>',
    book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
    chart: '<path d="M3 3v18h18"/><rect x="7" y="12" width="3" height="6" rx="1"/><rect x="12" y="8" width="3" height="10" rx="1"/><rect x="17" y="5" width="3" height="13" rx="1"/>',
    users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M16 13H8M16 17H8M10 9H8"/>',
    archive: '<rect x="2" y="4" width="20" height="5" rx="1"/><path d="M4 9v11a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1V9"/><path d="M10 13h4"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/>',
    printer: '<path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
    arrowLeft: '<path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/>',
    arrowRight: '<path d="M5 12h14"/><path d="M12 5l7 7-7 7"/>',
    check: '<path d="M20 6L9 17l-5-5"/>',
    checkCircle: '<circle cx="12" cy="12" r="9"/><path d="M8 12l2.5 2.5L16 9"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    alert: '<path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    cpu: '<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v3M15 1v3M9 20v3M15 20v3M1 9h3M1 15h3M20 9h3M20 15h3"/>',
    x: '<path d="M18 6L6 18M6 6l12 12"/>',
    refresh: '<path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.5 9a9 9 0 0 1 14.8-3.4L23 10"/><path d="M20.5 15a9 9 0 0 1-14.8 3.4L1 14"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    filter: '<path d="M22 3H2l8 9.5V19l4 2v-8.5z"/>',
    menu: '<path d="M3 12h18M3 6h18M3 18h18"/>',
    chevronDown: '<path d="M6 9l6 6 6-6"/>',
    chevronRight: '<path d="M9 18l6-6-6-6"/>',
    lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    zap: '<path d="M13 2L3 14h8l-1 8 10-12h-8l1-8z"/>',
    database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5"/><path d="M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',
    edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4z"/>',
    play: '<circle cx="12" cy="12" r="9"/><path d="M10 8l6 4-6 4V8z"/>',
    award: '<circle cx="12" cy="8" r="6"/><path d="M15.5 13.5L17 22l-5-3-5 3 1.5-8.5"/>',
    layers: '<path d="M12 2l9 5-9 5-9-5 9-5z"/><path d="M3 12l9 5 9-5"/><path d="M3 17l9 5 9-5"/>',
    activity: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
    eye: '<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
    external: '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6"/><path d="M10 14L21 3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><path d="M12 8h.01"/>',
    home: '<path d="M3 10.5L12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/>',
    send: '<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4 20-7z"/>',
    trendUp: '<path d="M23 6l-9.5 9.5-5-5L1 18"/><path d="M17 6h6v6"/>',
  };

  const INTENT_STYLE = {
    "知识点不会": { color: "#6366f1", badge: "indigo", bg: "#eef2ff" },
    "方法不当": { color: "#06b6d4", badge: "cyan", bg: "#ecfeff" },
    "心态困惑": { color: "#f59e0b", badge: "amber", bg: "#fffbeb" },
    "复习迷茫": { color: "#ec4899", badge: "violet", bg: "#fdf2f8" },
  };

  const TYPE_STYLE = {
    "知识点讲解": { icon: "sparkle", bg: "#eef2ff", ink: "#4f46e5" },
    "课件": { icon: "layers", bg: "#eff6ff", ink: "#2563eb" },
    "例题精讲": { icon: "target", bg: "#f5f3ff", ink: "#7c3aed" },
    "分层习题": { icon: "edit", bg: "#fffbeb", ink: "#b45309" },
    "微课视频": { icon: "play", bg: "#ecfeff", ink: "#0891b2" },
    "备考资料": { icon: "file", bg: "#fef2f2", ink: "#dc2626" },
    "学习方法": { icon: "brain", bg: "#ecfdf5", ink: "#047857" },
    "成长课堂": { icon: "award", bg: "#fdf2f8", ink: "#db2777" },
    "学习工具": { icon: "zap", bg: "#f0fdfa", ink: "#0f766e" },
  };

  const NAV = {
    student: [
      { key: "diagnose", label: "智能问诊", icon: "sparkle" },
      { key: "resources", label: "学习资源", icon: "book" },
      { key: "learning", label: "我的学情", icon: "chart" },
      { key: "profile", label: "个人档案", icon: "user" },
    ],
    counselor: [
      { key: "overview", label: "学情总览", icon: "activity" },
      { key: "students", label: "学生学情", icon: "users" },
      { key: "reports", label: "AI 帮扶报告", icon: "file" },
      { key: "ledgers", label: "学工台账", icon: "archive" },
      { key: "audit", label: "数据留痕", icon: "shield" },
    ],
  };

  const PAGE_TITLES = {
    diagnose: ["学生工作台", "智能问诊"],
    resources: ["学生工作台", "学习资源"],
    learning: ["学生工作台", "我的学情"],
    profile: ["学生工作台", "个人档案"],
    diagnosis: ["学生工作台", "诊断报告"],
    overview: ["辅导员工作台", "学情总览"],
    students: ["辅导员工作台", "学生学情"],
    reports: ["辅导员工作台", "AI 帮扶报告"],
    ledgers: ["辅导员工作台", "学工台账"],
    audit: ["辅导员工作台", "数据留痕"],
  };

  /* =======================================================================
     Utilities
     ======================================================================= */
  const esc = (value) =>
    String(value ?? "").replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[ch]));

  const icon = (name, size = 18, cls = "") =>
    `<svg class="${cls}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ICONS.sparkle}</svg>`;

  const avatar = (name, cls = "") =>
    `<span class="avatar ${cls}">${esc((name || "?").slice(0, 1))}</span>`;

  function fmtDate(iso, withTime = true) {
    if (!iso) return "—";
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return "—";
    const p = (n) => String(n).padStart(2, "0");
    const date = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
    return withTime ? `${date} ${p(d.getHours())}:${p(d.getMinutes())}` : date;
  }

  function fmtShort(iso) {
    if (!iso) return "—";
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return "—";
    return `${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }

  function relTime(iso) {
    if (!iso) return "";
    const then = new Date(iso).getTime();
    if (Number.isNaN(then)) return "";
    const diff = Math.max(0, Date.now() - then);
    const minute = 60000, hour = 3600000, day = 86400000;
    if (diff < minute) return "刚刚";
    if (diff < hour) return `${Math.floor(diff / minute)} 分钟前`;
    if (diff < day) return `${Math.floor(diff / hour)} 小时前`;
    if (diff < day * 30) return `${Math.floor(diff / day)} 天前`;
    return fmtDate(iso, false);
  }

  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

  function masteryClass(value) {
    if (value < 45) return "low";
    if (value < 65) return "mid";
    return "high";
  }

  function intentBadge(intent) {
    const style = INTENT_STYLE[intent] || { badge: "gray" };
    return `<span class="badge ${style.badge}">${esc(intent)}</span>`;
  }

  function statusBadge(status) {
    const cls = status === "已闭环" ? "green" : status === "跟进中" ? "cyan" : "amber";
    return `<span class="badge ${cls} dot">${esc(status)}</span>`;
  }

  function riskBadge(level) {
    const cls = level === "高" ? "high" : level === "中" ? "mid" : "low";
    return `<span class="risk-badge ${cls}">${esc(level)}风险</span>`;
  }

  function toast(message, type = "ok", timeout = 3600) {
    const el = document.createElement("div");
    el.className = `toast ${type}`;
    const iconName = type === "error" ? "alert" : type === "warn" ? "alert" : "checkCircle";
    el.innerHTML = `${icon(iconName, 17)}<div>${esc(message)}</div>`;
    toastRoot.appendChild(el);
    setTimeout(() => {
      el.classList.add("out");
      setTimeout(() => el.remove(), 240);
    }, timeout);
  }

  function openModal(html) {
    modalRoot.innerHTML = html;
    modalRoot.classList.add("open");
    modalRoot.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }

  function closeModal() {
    modalRoot.classList.remove("open");
    modalRoot.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
    setTimeout(() => {
      if (!modalRoot.classList.contains("open")) modalRoot.innerHTML = "";
    }, 200);
  }

  function emptyHTML(text, tip = "") {
    return `<div class="empty">${icon("info", 28)}<b>${esc(text)}</b>${tip ? `<span class="small">${esc(tip)}</span>` : ""}</div>`;
  }

  function skeletonHTML() {
    return `<div class="sk-page">
      <div class="sk-row"><div class="skeleton sk-card"></div><div class="skeleton sk-card"></div><div class="skeleton sk-card"></div><div class="skeleton sk-card"></div></div>
      <div class="skeleton sk-block"></div>
      <div class="sk-row"><div class="skeleton sk-card"></div><div class="skeleton sk-card"></div></div>
    </div>`;
  }

  function errorHTML(message) {
    return `<div class="card card-pad" style="text-align:center;padding:46px">
      <div style="color:#ef4444;margin-bottom:10px">${icon("alert", 30)}</div>
      <b style="font-size:15px">页面加载失败</b>
      <p class="muted small" style="margin:6px 0 16px">${esc(message)}</p>
      <button class="btn primary" data-retry>${icon("refresh", 15)}重新加载</button>
    </div>`;
  }

  async function api(path, options = {}) {
    const method = options.method || "GET";
    const headers = {};
    if (options.body !== undefined) headers["Content-Type"] = "application/json";
    if (method !== "GET" && state.csrf) headers["X-CSRF-Token"] = state.csrf;
    let response;
    try {
      response = await fetch(path, {
        method,
        headers,
        credentials: "same-origin",
        body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
      });
    } catch (networkError) {
      throw new Error("无法连接服务，请确认启动窗口仍在运行");
    }
    const type = response.headers.get("content-type") || "";
    const payload = type.includes("application/json") ? await response.json() : await response.text();
    if (!response.ok) {
      const message = payload && payload.error ? payload.error.message : "请求失败，请稍后重试";
      if (response.status === 401 && state.user) {
        state.user = null;
        state.csrf = null;
        renderLogin("登录已过期，请重新登录");
      }
      throw new Error(message);
    }
    return payload;
  }

  function buildQuery(params) {
    const search = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "") search.set(key, value);
    });
    const text = search.toString();
    return text ? `?${text}` : "";
  }

  async function downloadFile(url, filename, printUrl) {
    try {
      const response = await fetch(url, { credentials: "same-origin" });
      const type = response.headers.get("content-type") || "";
      if (!response.ok) {
        let message = "导出失败";
        if (type.includes("json")) {
          const data = await response.json();
          message = data && data.error ? data.error.message : message;
        }
        toast(message, "warn", 7000);
        if (printUrl) setTimeout(() => window.open(printUrl, "_blank"), 800);
        return;
      }
      const blob = await response.blob();
      const href = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = href;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(href), 5000);
      toast("文件已开始下载", "ok");
    } catch (error) {
      toast(`导出失败：${error.message}`, "error");
    }
  }

  function mdToHtml(markdown) {
    const lines = String(markdown || "").split("\n");
    let html = "";
    let inList = false;
    const inline = (text) => esc(text).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
    const closeList = () => {
      if (inList) {
        html += "</ul>";
        inList = false;
      }
    };
    for (const raw of lines) {
      const line = raw.trim();
      if (!line) {
        closeList();
        continue;
      }
      if (line.startsWith("## ")) {
        closeList();
        html += `<h2>${inline(line.slice(3))}</h2>`;
      } else if (line.startsWith("- ")) {
        if (!inList) {
          html += "<ul>";
          inList = true;
        }
        html += `<li>${inline(line.slice(2))}</li>`;
      } else if (/^\d+\.\s/.test(line)) {
        if (!inList) {
          html += "<ul>";
          inList = true;
        }
        html += `<li>${inline(line.replace(/^\d+\.\s/, ""))}</li>`;
      } else {
        closeList();
        html += `<p>${inline(line)}</p>`;
      }
    }
    closeList();
    return html;
  }

  /* =======================================================================
     Charts
     ======================================================================= */
  let gradientSeed = 0;

  function chartDonut(items, centerValue, centerLabel) {
    const total = items.reduce((sum, item) => sum + (item.count || 0), 0);
    const radius = 52;
    const circumference = 2 * Math.PI * radius;
    let offset = 0;
    const circles = items.map((item) => {
      const length = total ? ((item.count || 0) / total) * circumference : 0;
      const style = INTENT_STYLE[item.label] || { color: "#94a3b8" };
      const circle = `<circle cx="70" cy="70" r="${radius}" fill="none" stroke="${style.color}" stroke-width="15" stroke-dasharray="${length} ${circumference - length}" stroke-dashoffset="${-offset}" transform="rotate(-90 70 70)"><title>${esc(item.label)}：${item.count} 次</title></circle>`;
      offset += length;
      return circle;
    }).join("");
    return `<svg viewBox="0 0 140 140" width="150" height="150" role="img">
      <circle cx="70" cy="70" r="${radius}" fill="none" stroke="#eef2f9" stroke-width="15"/>
      ${circles}
      <text x="70" y="67" text-anchor="middle" font-size="23" font-weight="800" fill="#111a2e">${esc(centerValue)}</text>
      <text x="70" y="85" text-anchor="middle" font-size="9.5" fill="#94a3b8">${esc(centerLabel)}</text>
    </svg>`;
  }

  function chartLine(rows, series, options = {}) {
    const width = 660;
    const height = 236;
    const pad = { l: 34, r: 14, t: 16, b: 28 };
    const n = Math.max(rows.length, 2);
    const maxValue = Math.max(
      4,
      ...rows.flatMap((row) => series.map((item) => row[item.key] || 0))
    ) * 1.18;
    const x = (index) => pad.l + (index * (width - pad.l - pad.r)) / (n - 1);
    const y = (value) => height - pad.b - ((value || 0) / maxValue) * (height - pad.t - pad.b);
    const id = `grad-${++gradientSeed}`;
    const grids = [0, 0.25, 0.5, 0.75, 1].map((ratio) => {
      const gy = pad.t + ratio * (height - pad.t - pad.b);
      const label = Math.round(maxValue * (1 - ratio));
      return `<line x1="${pad.l}" y1="${gy}" x2="${width - pad.r}" y2="${gy}" stroke="#eef2f9" stroke-width="1"/>
        <text x="${pad.l - 8}" y="${gy + 3.5}" text-anchor="end" font-size="9" fill="#a1aec4">${label}</text>`;
    }).join("");
    const labelStep = Math.max(1, Math.ceil(rows.length / (options.labels || 7)));
    const labels = rows.map((row, index) => {
      if (index % labelStep !== 0 && index !== rows.length - 1) return "";
      return `<text x="${x(index)}" y="${height - 8}" text-anchor="middle" font-size="9" fill="#a1aec4">${esc(row.label || "")}</text>`;
    }).join("");
    const paths = series.map((item, seriesIndex) => {
      const points = rows.map((row, index) => `${x(index)},${y(row[item.key])}`);
      const line = `M${points.join("L")}`;
      const area = `${line}L${x(rows.length - 1)},${height - pad.b}L${x(0)},${height - pad.b}Z`;
      const dots = rows.map((row, index) => {
        if (rows.length > 20 && index % 2 !== 0) return "";
        return `<circle cx="${x(index)}" cy="${y(row[item.key])}" r="2.6" fill="#fff" stroke="${item.color}" stroke-width="2"><title>${esc(row.label)}：${row[item.key]}</title></circle>`;
      }).join("");
      return `${seriesIndex === 0 ? `<path d="${area}" fill="url(#${id})"/>` : ""}
        <path d="${line}" fill="none" stroke="${item.color}" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"/>
        ${dots}`;
    }).join("");
    const legend = series.map((item) =>
      `<span><i style="background:${item.color}"></i>${esc(item.label)}</span>`
    ).join("");
    return `<div class="chart-legend" style="margin-bottom:6px">${legend}</div>
      <svg class="chart-svg" viewBox="0 0 ${width} ${height}" preserveAspectRatio="xMidYMid meet" role="img">
        <defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="${series[0].color}" stop-opacity="0.22"/>
          <stop offset="1" stop-color="${series[0].color}" stop-opacity="0"/>
        </linearGradient></defs>
        ${grids}${labels}${paths}
      </svg>`;
  }

  function masteryRing(value, size = 116) {
    const radius = 46;
    const circumference = 2 * Math.PI * radius;
    const dash = (clamp(value, 0, 100) / 100) * circumference;
    const color = value < 45 ? "#ef4444" : value < 65 ? "#f59e0b" : "#10b981";
    return `<div class="ring-wrap"><svg width="${size}" height="${size}" viewBox="0 0 116 116" role="img" aria-label="掌握度 ${value}">
      <circle cx="58" cy="58" r="${radius}" fill="none" stroke="#eef2f9" stroke-width="9"/>
      <circle cx="58" cy="58" r="${radius}" fill="none" stroke="${color}" stroke-width="9"
        stroke-linecap="round" stroke-dasharray="${dash} ${circumference - dash}" transform="rotate(-90 58 58)"/>
      <text x="58" y="55" text-anchor="middle" font-size="25" font-weight="800" fill="#111a2e">${value}</text>
      <text x="58" y="72" text-anchor="middle" font-size="9" fill="#94a3b8">掌握度 /100</text>
    </svg><div class="ring-label">AI 综合评估</div></div>`;
  }

  function radarChart(items, size = 236) {
    if (!items.length) return emptyHTML("暂无能力数据");
    const list = items.slice(0, 6);
    const cx = size / 2;
    const cy = size / 2;
    const radius = size * 0.32;
    const n = list.length;
    const point = (index, ratio) => {
      const angle = (Math.PI * 2 * index) / n - Math.PI / 2;
      return [cx + Math.cos(angle) * radius * ratio, cy + Math.sin(angle) * radius * ratio];
    };
    const grids = [0.25, 0.5, 0.75, 1].map((ratio) => {
      const points = Array.from({ length: n }, (_, index) => point(index, ratio).join(",")).join(" ");
      return `<polygon points="${points}" fill="none" stroke="#e8edf7" stroke-width="1"/>`;
    }).join("");
    const axes = Array.from({ length: n }, (_, index) => {
      const [px, py] = point(index, 1);
      return `<line x1="${cx}" y1="${cy}" x2="${px}" y2="${py}" stroke="#eef2f9"/>`;
    }).join("");
    const valuePoints = list.map((item, index) =>
      point(index, clamp(item.score, 0, 100) / 100).join(",")
    ).join(" ");
    const labels = list.map((item, index) => {
      const [px, py] = point(index, 1.22);
      let anchor = "middle";
      if (px > cx + 8) anchor = "start";
      else if (px < cx - 8) anchor = "end";
      return `<text x="${px}" y="${py + 3}" text-anchor="${anchor}" font-size="9" fill="#64748b">${esc(item.name)}</text>`;
    }).join("");
    return `<svg viewBox="0 0 ${size} ${size}" width="100%" style="max-width:${size}px;margin:0 auto" role="img">
      ${grids}${axes}
      <polygon points="${valuePoints}" fill="rgba(99,102,241,0.18)" stroke="#6366f1" stroke-width="2"/>
      ${list.map((item, index) => {
        const [px, py] = point(index, clamp(item.score, 0, 100) / 100);
        return `<circle cx="${px}" cy="${py}" r="3" fill="#fff" stroke="#6366f1" stroke-width="2"><title>${esc(item.name)} ${item.score}</title></circle>`;
      }).join("")}
      ${labels}
    </svg>`;
  }

  function weakBarsHTML(items) {
    if (!items.length) return emptyHTML("暂无薄弱点数据");
    const max = Math.max(...items.map((item) => item.count), 1);
    return `<div class="weak-bars">${items.map((item) => {
      const width = clamp((item.count / max) * 100, 6, 100);
      return `<div class="bar-row">
        <div class="br-top"><span>${esc(item.name)}</span><b>${item.count} 次 · ${item.mastery}/100</b></div>
        <div class="bar-track"><div class="bar-fill ${masteryClass(item.mastery)}" style="width:${width}%"></div></div>
      </div>`;
    }).join("")}</div>`;
  }

  function abilityBarsHTML(items) {
    if (!items.length) return emptyHTML("暂无能力数据");
    return `<div class="ability-list">${items.map((item) => `
      <div class="ability-row">
        <div class="ar-top"><span>${esc(item.name)}</span><b>${item.score}</b></div>
        <div class="bar-track"><div class="bar-fill ${masteryClass(item.score)}" style="width:${item.score}%"></div></div>
      </div>`).join("")}</div>`;
  }

  function heatmapHTML(cells) {
    const max = Math.max(1, ...cells.map((cell) => cell.count));
    const levels = cells.map((cell) => {
      const level = cell.count === 0 ? 0 : Math.min(4, Math.ceil((cell.count / max) * 4));
      return `<span class="heat-cell" data-level="${level}" title="${esc(cell.date)}：${cell.count} 次学习行为"></span>`;
    }).join("");
    return `<div class="heat-grid">${levels}</div>
      <div class="heat-legend">少 <i style="background:#eef2f9"></i><i style="background:#c7d2fe"></i><i style="background:#818cf8"></i><i style="background:#6366f1"></i><i style="background:#4338ca"></i> 多</div>`;
  }

  /* =======================================================================
     Login
     ======================================================================= */
  function renderLogin(message = "") {
    state.user = null;
    state.csrf = null;
    document.body.className = "";
    document.body.style.overflow = "";
    app.innerHTML = `
      <div class="login fade-up">
        <section class="login-visual">
          <div class="login-brand">
            <span class="brand-mark">${icon("sparkle", 21)}</span>
            <span class="brand-text"><b>智学</b><small>ZHIXUE · AI LEARNING CARE</small></span>
          </div>
          <div class="login-copy">
            <span class="eyebrow light">AI Agent · 学情诊断 · 学工台账</span>
            <h1>让每一次<br><em>学业困惑</em><br>都成为可归档的帮扶。</h1>
            <p>面向高校的 AI Agent 智能学情服务与学工台账自动化系统。学生自由提问，AI 完成结构化诊断、资源推送与台账生成，辅导员专注真正需要的谈话与决策。</p>
            <div class="login-features">
              <div class="login-feature"><span class="ico">${icon("cpu", 17)}</span><div><b>学情智能诊断</b><span>意图识别 · 薄弱点定位 · 掌握度评估</span></div></div>
              <div class="login-feature"><span class="ico">${icon("book", 17)}</span><div><b>资源精准推送</b><span>按薄弱点匹配讲解、例题与分层习题</span></div></div>
              <div class="login-feature"><span class="ico">${icon("file", 17)}</span><div><b>台账自动生成</b><span>一次问诊，自动沉淀一条学工记录</span></div></div>
              <div class="login-feature"><span class="ico">${icon("shield", 17)}</span><div><b>数据不可篡改</b><span>哈希链留痕 · 可追溯 · 可导出归档</span></div></div>
            </div>
            <div class="login-mock">
              <div class="mock-card">
                <div class="mock-top"><span class="pulse"></span>AI 学情 Agent 正在会诊</div>
                <div class="mock-q">“高数中值定理证明题总是没有思路，看到存在 ξ 就懵，期末快到了很焦虑。”</div>
                <div class="mock-tags"><span>方法不当</span><span>微分中值定理</span><span>掌握度 35</span></div>
                <div class="mock-steps">
                  <div class="mock-step"><i>${icon("check", 9)}</i>意图识别与知识定位完成</div>
                  <div class="mock-step"><i>${icon("check", 9)}</i>能力短板评估：证明题构造偏弱</div>
                  <div class="mock-step"><i>${icon("check", 9)}</i>匹配 5 份针对性学习资源</div>
                </div>
                <div class="mock-ledger"><span>已自动生成学工台账</span><span>XG-2026-00032</span></div>
              </div>
            </div>
          </div>
        </section>
        <section class="login-panel">
          <div class="login-card">
            <div class="login-mobile-brand"><span class="brand-mark">${icon("sparkle", 18)}</span><b>智学</b><span>AI 学情与学工平台</span></div>
            <div class="role-switch">
              <button type="button" data-role="student" class="active">学生端</button>
              <button type="button" data-role="counselor">辅导员端</button>
            </div>
            <h2>登录智学平台</h2>
            <p class="login-sub">AI 学情自助诊断 + 学工台账自动化，一次问诊形成完整帮扶闭环。</p>
            <div class="login-error ${message ? "show" : ""}" id="login-error">${esc(message)}</div>
            <form id="login-form" autocomplete="on">
              <div class="field">
                <label for="username">账号</label>
                <div class="control">${icon("user", 17)}<input id="username" name="username" placeholder="学号 / 辅导员账号" autocomplete="username" required /></div>
              </div>
              <div class="field">
                <label for="password">密码</label>
                <div class="control">${icon("lock", 17)}<input id="password" name="password" type="password" placeholder="请输入登录密码" autocomplete="current-password" required /></div>
              </div>
              <button type="submit" class="login-submit" id="login-btn">进入平台</button>
            </form>
            <div class="demo-box">
              <div class="demo-title"><span>演示账号</span><span style="color:#94a3b8;font-weight:500">点击自动填入</span></div>
              <div class="demo-accounts">
                <button type="button" class="demo-account" data-demo="student"><span><b>林晓</b> · 学生</span><span><code>20240101</code><code>Student123!</code></span></button>
                <button type="button" class="demo-account" data-demo="counselor"><span><b>王静怡</b> · 辅导员</span><span><code>counselor</code><code>Counselor123!</code></span></button>
              </div>
            </div>
            <p class="login-foot">演示数据 · 会话与操作写入 SQLite 安全留痕<br>智学平台 v3.0 · 本产品基于 AI Agent 的学情诊断与学工辅助系统</p>
          </div>
        </section>
      </div>`;

    const form = document.getElementById("login-form");
    const errorBox = document.getElementById("login-error");
    const button = document.getElementById("login-btn");
    let role = "student";

    document.querySelectorAll("[data-role]").forEach((tab) => {
      tab.addEventListener("click", () => {
        role = tab.dataset.role;
        document.querySelectorAll("[data-role]").forEach((item) => item.classList.toggle("active", item === tab));
      });
    });

    document.querySelectorAll("[data-demo]").forEach((chip) => {
      chip.addEventListener("click", () => {
        const student = chip.dataset.demo === "student";
        document.getElementById("username").value = student ? "20240101" : "counselor";
        document.getElementById("password").value = student ? "Student123!" : "Counselor123!";
        role = student ? "student" : "counselor";
        document.querySelectorAll("[data-role]").forEach((item) => item.classList.toggle("active", item.dataset.role === role));
        toast("演示账号已填入，点击“进入平台”即可", "ok", 2600);
      });
    });

    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const username = document.getElementById("username").value.trim();
      const password = document.getElementById("password").value;
      if (!username || !password) {
        errorBox.textContent = "请输入账号与密码";
        errorBox.classList.add("show");
        return;
      }
      button.disabled = true;
      button.innerHTML = `<span class="spinner"></span> 正在验证身份…`;
      errorBox.classList.remove("show");
      try {
        const result = await api("/api/login", { method: "POST", body: { username, password } });
        state.user = result.user;
        state.csrf = result.csrf;
        await startApp();
      } catch (error) {
        errorBox.textContent = error.message;
        errorBox.classList.add("show");
        button.disabled = false;
        button.textContent = "进入平台";
      }
    });
  }

  /* =======================================================================
     Shell
     ======================================================================= */
  async function startApp() {
    try {
      state.meta = await api("/api/meta");
    } catch (error) {
      toast(`加载基础数据失败：${error.message}`, "error");
      return;
    }
    renderShell();
    const defaultHash = state.user.role === "counselor" ? "#/overview" : "#/diagnose";
    if (!location.hash || location.hash === "#" || location.hash === "#/") {
      location.hash = defaultHash;
    } else {
      renderRoute();
    }
  }

  function renderShell() {
    document.body.className = "app-body";
    const isCounselor = state.user.role === "counselor";
    const navItems = NAV[state.user.role] || [];
    const classes = state.meta.classes || [];
    const classText = isCounselor
      ? `所辖 ${classes.length} 个班级 · ${classes.reduce((sum, item) => sum + (item.student_count || 0), 0)} 名学生`
      : `${classes[0] ? classes[0].name : state.user.class_name || "未绑定班级"}`;
    const now = new Date();
    const weekdays = ["日", "一", "二", "三", "四", "五", "六"];

    app.innerHTML = `
      <div class="app">
        <aside class="sidebar">
          <a class="brand" href="#/${isCounselor ? "overview" : "diagnose"}">
            <span class="brand-mark">${icon("sparkle", 20)}</span>
            <span class="brand-text"><b>智学</b><small>AI LEARNING CARE</small></span>
          </a>
          <div class="side-label">${isCounselor ? "学工工作台" : "学习空间"}</div>
          <nav class="nav">
            ${navItems.map((item) => `
              <a class="nav-item" data-nav="${item.key}" href="#/${item.key}">
                ${icon(item.icon, 18)}<span>${esc(item.label)}</span>
              </a>`).join("")}
          </nav>
          <div class="side-spacer"></div>
          <div class="side-card">
            <b>${isCounselor ? "学情数据已同步" : "班级学情档案"}</b>
            <span>${esc(classText)}</span>
            <div class="side-meta"><span>${isCounselor ? "自动留痕" : "AI 全程陪伴"}</span><span>${isCounselor ? "实时" : "本学期"}</span></div>
          </div>
          <div class="side-ai"><span class="pulse"></span>${esc(state.meta.ai.label)}</div>
          <div class="side-user">
            ${avatar(state.user.name)}
            <div class="su-info"><b>${esc(state.user.name)}</b><span>${isCounselor ? "辅导员" : "学生"} · ${esc(state.user.student_no || state.user.username)}</span></div>
            <button class="side-logout" id="logout-btn" title="退出登录">${icon("logout", 17)}</button>
          </div>
        </aside>
        <div class="shell">
          <header class="topbar">
            <button class="menu-btn" id="menu-btn" aria-label="打开导航">${icon("menu", 19)}</button>
            <div class="topbar-title">
              <div class="crumb" id="page-crumb">${isCounselor ? "辅导员工作台" : "学生工作台"}</div>
              <h2 id="page-title">${isCounselor ? "学情总览" : "智能问诊"}</h2>
            </div>
            <div class="topbar-actions">
              <span class="date-pill">${icon("calendar", 14)}${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日 · 周${weekdays[now.getDay()]}</span>
              <span class="live-pill"><i></i>数据实时留痕</span>
              ${avatar(state.user.name, isCounselor ? "" : "cyan")}
            </div>
          </header>
          <main class="view" id="view"></main>
        </div>
      </div>`;

    document.getElementById("menu-btn").addEventListener("click", () => {
      document.body.classList.toggle("nav-open");
    });
    document.getElementById("logout-btn").addEventListener("click", async () => {
      try {
        await api("/api/logout", { method: "POST", body: {} });
      } catch (error) {
        /* 忽略退出错误 */
      }
      state.user = null;
      state.csrf = null;
      state.meta = null;
      history.replaceState(null, "", location.pathname);
      renderLogin();
      toast("已安全退出", "ok");
    });
    document.querySelector(".sidebar").addEventListener("click", (event) => {
      if (event.target.closest("a.nav-item")) document.body.classList.remove("nav-open");
    });
  }

  /* =======================================================================
     Router
     ======================================================================= */
  function parseHash() {
    const raw = location.hash.replace(/^#\/?/, "");
    const [pathPart, queryPart] = raw.split("?");
    return {
      parts: pathPart.split("/").filter(Boolean),
      query: new URLSearchParams(queryPart || ""),
    };
  }

  function isKnownPage(role, key) {
    return (NAV[role] || []).some((item) => item.key === key) || key === "diagnosis";
  }

  function setNav(key) {
    const navKey = key === "diagnosis" ? "" : key;
    document.querySelectorAll("[data-nav]").forEach((item) => {
      item.classList.toggle("active", item.dataset.nav === navKey);
    });
    const meta = PAGE_TITLES[key] || ["智学", ""];
    const crumb = document.getElementById("page-crumb");
    const title = document.getElementById("page-title");
    if (crumb) crumb.textContent = meta[0];
    if (title) title.textContent = meta[1] || "智学";
  }

  function renderRoute() {
    if (!state.user) return;
    const { parts } = parseHash();
    let key = parts[0] || (state.user.role === "counselor" ? "overview" : "diagnose");
    if (!isKnownPage(state.user.role, key)) {
      key = state.user.role === "counselor" ? "overview" : "diagnose";
    }
    setNav(key);
    document.body.classList.remove("nav-open");
    const view = document.getElementById("view");
    if (!view) return;
    view.innerHTML = skeletonHTML();
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
    const id = Number(parts[1]);
    if (key === "students" && parts[1]) {
      pageStudentDetail(id).catch((error) => showPageError(error));
      return;
    }
    const handlers = {
      diagnose: () => pageDiagnose(),
      resources: () => pageResources(),
      learning: () => pageLearning(),
      profile: () => pageProfile(),
      diagnosis: () => pageDiagnosis(id),
      overview: () => pageOverview(),
      students: () => pageStudents(),
      reports: () => pageReports(),
      ledgers: () => pageLedgers(),
      audit: () => pageAudit(),
    };
    Promise.resolve(handlers[key]()).catch((error) => {
      view.innerHTML = errorHTML(error.message);
      const retry = view.querySelector("[data-retry]");
      if (retry) retry.addEventListener("click", () => renderRoute());
    });
  }

  /* =======================================================================
     Shared components
     ======================================================================= */
  function kpiCard({ label, value, unit = "", sub = "", iconName, tint = "#eef2ff", tintInk = "#4f46e5" }) {
    return `<div class="kpi" style="--tint:${tint};--tint-bg:${tint};--tint-ink:${tintInk}">
      <div class="kpi-icon">${icon(iconName, 20)}</div>
      <div class="kpi-body">
        <div class="kpi-label">${esc(label)}</div>
        <div class="kpi-value">${esc(value)}${unit ? `<em>${esc(unit)}</em>` : ""}</div>
        <div class="kpi-sub">${sub}</div>
      </div>
    </div>`;
  }

  function resourceCard(item, options = {}) {
    const style = TYPE_STYLE[item.type] || TYPE_STYLE["知识点讲解"];
    return `<article class="res-card" data-resource="${item.id}" tabindex="0" role="button" aria-label="${esc(item.title)}">
      <div class="res-top">
        <span class="res-icon" style="--tint-bg:${style.bg};--tint-ink:${style.ink}">${icon(style.icon, 17)}</span>
        <span class="res-type" style="color:${style.ink}">${esc(item.type)}</span>
        ${item.learned ? `<span class="res-flag">已学习</span>` : ""}
      </div>
      <h4>${esc(item.title)}</h4>
      <p>${esc(item.summary)}</p>
      ${options.reason && item.reason ? `<div class="res-reason">${icon("sparkle", 11)} ${esc(item.reason)}</div>` : ""}
      <div class="res-foot"><span>${item.minutes} 分钟 · ${esc(item.level)} · ${esc(item.course)}</span><span class="go">查看 ${icon("chevronRight", 12)}</span></div>
    </article>`;
  }

  function intentLegend(items) {
    const total = items.reduce((sum, item) => sum + item.count, 0);
    return `<div class="donut-legend">${items.map((item) => {
      const style = INTENT_STYLE[item.label] || { color: "#94a3b8" };
      return `<div class="donut-legend-item"><i style="background:${style.color}"></i><span>${esc(item.label)}</span><b>${item.count} · ${total ? Math.round((item.count / total) * 100) : 0}%</b></div>`;
    }).join("")}</div>`;
  }

  function ledgerRowHTML(item) {
    return `<tr class="clickable" data-ledger="${item.id}">
      <td><span class="mono strong">${esc(item.code)}</span><div class="small faint">${esc(item.help_date)}</div></td>
      <td><div class="student-cell">${avatar(item.student_name)}<div><b>${esc(item.student_name)}</b><span>${esc(item.student_no)}</span></div></div></td>
      <td>${intentBadge(item.intent)}<div class="small faint" style="margin-top:3px">${esc(item.course)}</div></td>
      <td><div class="mastery-cell"><div class="bar-track"><div class="bar-fill ${masteryClass(item.mastery)}" style="width:${item.mastery}%"></div></div><b>${item.mastery}</b></div></td>
      <td>${statusBadge(item.status)}</td>
      <td><span class="small">${esc((item.problem || "").slice(0, 26))}${(item.problem || "").length > 26 ? "…" : ""}</span></td>
      <td><span class="small faint">${esc(item.help_text)}</span></td>
    </tr>`;
  }

  /* =======================================================================
     Student · Diagnose
     ======================================================================= */
  async function pageDiagnose() {
    const data = await api("/api/student/overview");
    state.overview = data;
    const view = document.getElementById("view");
    const stats = data.stats;
    const recent = data.recent[0];
    const weak = data.weak_points.slice(0, 3);
    view.innerHTML = `
      <div class="page fade-up">
        <div class="page-head">
          <div>
            <div class="eyebrow">AI 学情问诊</div>
            <h1>你好，${esc(data.profile.name)}</h1>
            <p class="lead">把课堂、作业、备考中的卡点直接说出来。AI 会完成意图识别、结构化诊断、资源匹配，并自动生成一条辅导员可用的学工台账。</p>
          </div>
          <div class="flex gap-12" style="flex-wrap:wrap">
            <div class="card" style="padding:12px 16px;min-width:104px"><div class="small faint">连续学习</div><b style="font-size:19px">${stats.streak}<span class="small muted"> 天</span></b></div>
            <div class="card" style="padding:12px 16px;min-width:104px"><div class="small faint">累计问诊</div><b style="font-size:19px">${stats.diagnoses}<span class="small muted"> 次</span></b></div>
            <div class="card" style="padding:12px 16px;min-width:104px"><div class="small faint">平均掌握度</div><b style="font-size:19px">${stats.avg_mastery}<span class="small muted"> /100</span></b></div>
          </div>
        </div>

        <div class="consult-layout">
          <section class="card consult-card">
            <div class="consult-head">
              <div class="ai-orb">${icon("sparkle", 22)}</div>
              <div><h3>AI 学情问诊台</h3><p>支持开放式提问 · 不限题型 · 不限场景</p></div>
              <span class="engine-badge"><i></i>${esc(state.meta.ai.label)}</span>
            </div>
            <textarea class="question-input" id="question" maxlength="2000" placeholder="例如：老师，我高数的中值定理证明题总是没有思路，看到“存在 ξ”就不知道从哪下手，期末又快到了，有点焦虑……"></textarea>
            <div class="quick-chips" id="quick-chips">
              ${["高数中值定理证明题没有思路", "四级听力跟不上，越练越没信心", "期末复习没有计划，不知道从哪开始", "SQL 多表连接查询写不出来"].map((text) => `<button type="button" class="chip-ghost" data-prompt="${esc(text)}">${esc(text)}</button>`).join("")}
            </div>
            <div class="consult-actions">
              <span class="consult-hint">${icon("shield", 13)} 问诊记录永久留痕，正文不可修改</span>
              <span class="count" id="char-count">0 / 2000</span>
              <button class="btn primary" id="diagnose-btn">${icon("sparkle", 15)} 开始 AI 诊断</button>
            </div>
            <div class="agent-mini-flow">
              <span class="mini-step"><b>01</b> 意图识别</span><span class="arrow">→</span>
              <span class="mini-step"><b>02</b> 结构化诊断</span><span class="arrow">→</span>
              <span class="mini-step"><b>03</b> 资源匹配</span><span class="arrow">→</span>
              <span class="mini-step"><b>04</b> 台账归档</span>
            </div>
          </section>

          <aside class="side-stack">
            <div class="card side-panel">
              <h4>${icon("clock", 15)} 最近一次诊断</h4>
              ${recent ? `<div class="recent-diagnosis">
                <div class="rd-top"><span>${esc(recent.course)}</span><span>${fmtShort(recent.created_at)}</span></div>
                <p>${esc(recent.weak_names.slice(0, 2).join("、")) || "已生成诊断结论"}</p>
                <div class="rd-tags">${intentBadge(recent.intent)}<span class="badge gray">掌握度 ${recent.mastery}</span></div>
              </div>` : emptyHTML("还没有诊断记录", "从上方输入第一个问题开始")}
            </div>
            <div class="card side-panel">
              <h4>${icon("target", 15)} 当前薄弱点</h4>
              <div class="weak-mini">
                ${weak.length ? weak.map((item) => `<div class="weak-mini-item"><span class="name">${esc(item.name)}</span><span class="val">${item.mastery}/100</span></div>`).join("") : `<p class="small muted">完成一次问诊后显示</p>`}
              </div>
            </div>
            <div class="tip-card">
              <div class="eyebrow">TODAY'S ADVICE</div>
              <h4>先描述“卡在哪”，再描述“想要什么”</h4>
              <p>例如“中值定理证明题不会构造辅助函数”比“高数不会”更容易被 AI 精准定位。描述越具体，资源匹配越准确。</p>
              <div class="tip-foot">AI 已服务本班 ${stats.diagnoses} 次问诊 · 台账闭环率 ${stats.closure_rate}%</div>
            </div>
          </aside>
        </div>

        <div class="feature-strip">
          <div class="feature-item"><div class="fi-icon">${icon("cpu", 17)}</div><b>学情智能诊断</b><span>意图识别 + 薄弱知识点定位 + 掌握度评估</span></div>
          <div class="feature-item"><div class="fi-icon" style="background:#ecfeff;color:#0891b2">${icon("book", 17)}</div><b>资源精准推送</b><span>按薄弱点匹配讲解、例题与分层习题</span></div>
          <div class="feature-item"><div class="fi-icon" style="background:#ecfdf5;color:#059669">${icon("file", 17)}</div><b>台账自动化</b><span>问诊结束即生成辅导员台账，无需手动录入</span></div>
          <div class="feature-item"><div class="fi-icon" style="background:#f5f3ff;color:#7c3aed">${icon("shield", 17)}</div><b>全程留痕</b><span>哈希链校验，支持 XLSX / PDF 归档导出</span></div>
        </div>
      </div>`;

    const textarea = document.getElementById("question");
    const count = document.getElementById("char-count");
    textarea.addEventListener("input", () => {
      count.textContent = `${textarea.value.length} / 2000`;
    });
    view.querySelectorAll("[data-prompt]").forEach((chip) => {
      chip.addEventListener("click", () => {
        textarea.value = chip.dataset.prompt;
        textarea.focus();
        count.textContent = `${textarea.value.length} / 2000`;
      });
    });
    const submit = async () => {
      const question = textarea.value.trim();
      if (question.length < 6) {
        toast("再多描述一点你的学习困惑，至少 6 个字", "warn");
        textarea.focus();
        return;
      }
      const started = Date.now();
      const timer = showPipeline(question);
      try {
        const result = await api("/api/student/diagnose", { method: "POST", body: { question } });
        const wait = Math.max(0, 2500 - (Date.now() - started));
        await new Promise((resolve) => setTimeout(resolve, wait));
        clearInterval(timer);
        toast("AI 诊断完成，学工台账已自动生成", "ok");
        location.hash = `#/diagnosis/${result.diagnosis.id}`;
      } catch (error) {
        clearInterval(timer);
        toast(error.message, "error");
        pageDiagnose();
      }
    };
    document.getElementById("diagnose-btn").addEventListener("click", submit);
    textarea.addEventListener("keydown", (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key === "Enter") submit();
    });
  }

  function showPipeline(question) {
    const view = document.getElementById("view");
    const steps = [
      ["chat", "语义解析", "拆分问题中的课程、知识点与情绪信号"],
      ["cpu", "意图识别", "区分知识点不会 / 方法不当 / 心态困惑 / 复习迷茫"],
      ["target", "知识定位", "匹配校本知识库中的薄弱知识点"],
      ["chart", "掌握度评估", "生成难度等级与 0—100 掌握度"],
      ["book", "资源匹配", "从知识库检索讲解、例题与分层习题"],
      ["file", "台账生成", "自动整理问诊全过程并写入哈希链"],
    ];
    view.innerHTML = `<div class="pipeline-wrap card fade-up">
      <div class="pipeline-core">${icon("sparkle", 30)}</div>
      <h2>AI Agent 正在会诊</h2>
      <p class="pipeline-q">“${esc(question)}”</p>
      <div class="pipeline" id="pipeline-steps">
        ${steps.map((step, index) => `<div class="p-step" data-step="${index}">
          <span class="p-icon">${icon(step[0], 15)}</span>
          <div class="p-body"><b>${step[1]}</b><span>${step[2]}</span></div>
        </div>`).join("")}
      </div>
      <div class="progress-bar"><span id="pipeline-progress"></span></div>
      <p class="pipeline-note">诊断完成后将自动生成辅导员学工台账，全程无需手动录入</p>
    </div>`;
    const nodes = Array.from(document.querySelectorAll(".p-step"));
    const bar = document.getElementById("pipeline-progress");
    let index = 0;
    const timer = setInterval(() => {
      if (index > 0 && nodes[index - 1]) {
        nodes[index - 1].classList.remove("active");
        nodes[index - 1].classList.add("done");
        const iconSlot = nodes[index - 1].querySelector(".p-icon");
        if (iconSlot) iconSlot.innerHTML = icon("check", 15);
      }
      if (index < nodes.length) {
        nodes[index].classList.add("active");
        bar.style.width = `${((index + 1) / nodes.length) * 100}%`;
        index += 1;
      } else {
        clearInterval(timer);
      }
    }, 420);
    return timer;
  }

  /* =======================================================================
     Student · Diagnosis detail (also counselor)
     ======================================================================= */
  async function pageDiagnosis(id) {
    if (!id) throw new Error("缺少诊断编号");
    const data = await api(`/api/diagnosis/${id}`);
    const d = data.diagnosis;
    const isCounselor = state.user.role === "counselor";
    const view = document.getElementById("view");
    const backHref = isCounselor ? (state.studentId ? `#/students/${state.studentId}` : "#/students") : "#/learning";
    const ledger = data.ledger;
    view.innerHTML = `
      <div class="page fade-up">
        <div class="detail-bar">
          <a class="back-link" href="${backHref}">${icon("arrowLeft", 15)} ${isCounselor ? "返回学生学情" : "返回我的学情"}</a>
          <div class="detail-meta">
            <span class="mono">${esc(d.public_id)}</span><span>·</span><span>${esc(d.created_text)}</span>
            <span class="badge ${d.ai_mode === "llm" ? "violet" : "gray"}">${d.ai_mode === "llm" ? "大模型增强" : "本地 AI 引擎"}</span>
            <span class="badge green">${icon("shield", 11)} 已留痕</span>
          </div>
        </div>

        <div class="card result-hero">
          <div>
            ${isCounselor ? `<div class="flex gap-8" style="align-items:center;margin-bottom:6px">${avatar(d.student_name)}<b>${esc(d.student_name)}</b><span class="small muted">${esc(d.student_no)} · ${esc(d.class_name)}</span></div>` : ""}
            <div class="eyebrow">${esc(d.course)} · ${esc(d.intent)}</div>
            <h1>学情诊断报告</h1>
            <blockquote class="result-question">${esc(d.question)}</blockquote>
            <div class="tag-row">${(d.tags || []).map((tag) => `<span class="tag primary">${esc(tag)}</span>`).join("")}</div>
          </div>
          <div class="result-hero-stats">
            ${masteryRing(d.mastery)}
            <div class="difficulty-box">
              <div class="d-label">难度等级</div>
              <div class="d-value">${esc(d.difficulty)}</div>
              <div class="d-sub">意图置信度 ${Math.round((d.intent_confidence || 0) * 100)}%</div>
            </div>
          </div>
        </div>

        <div class="result-grid">
          <div class="col-main">
            <section class="card insight-card">
              <h3>${icon("sparkle", 17)} AI 诊断结论</h3>
              <p>${esc(d.summary)}</p>
            </section>
            <section class="card insight-card">
              <h3>${icon("target", 17)} 薄弱知识点</h3>
              <div class="weak-grid">
                ${(d.weak_points || []).map((item) => `<div class="weak-card">
                  <div class="wc-top"><b>${esc(item.name)}</b><span class="wc-course">${esc(item.course)}</span></div>
                  <div class="wc-bar"><i style="width:${item.mastery}%"></i></div>
                  <div class="wc-foot"><span>预估掌握度</span><span>${item.mastery}/100 · 难度 ${item.difficulty}/5</span></div>
                </div>`).join("")}
              </div>
            </section>
            <section class="card insight-card">
              <h3>${icon("alert", 17)} 识别到的学习误区</h3>
              <ol class="misconception-list">${(d.misconceptions || []).map((item) => `<li>${esc(item)}</li>`).join("")}</ol>
            </section>
            <section class="card insight-card">
              <h3>${icon("chart", 17)} 能力短板评估</h3>
              ${abilityBarsHTML(d.ability_gaps || [])}
            </section>
          </div>
          <aside class="col-side">
            ${ledger ? `<div class="ledger-card">
              <div class="lc-head">${icon("file", 14)} AI 已自动生成学工台账</div>
              <div class="lc-code">${esc(ledger.code)}</div>
              <p>本次问诊全过程已整理为辅导员台账，包含学生问题、诊断结论、帮扶资源与建议，无需老师手动录入。</p>
              <div class="lc-foot"><span>状态：${esc(ledger.status)}</span><span><b>${esc(ledger.hash_short)}</b></span></div>
            </div>` : ""}
            <section class="card insight-card">
              <h3>${icon("cpu", 17)} Agent 工作流</h3>
              <div class="trace-list">
                ${(d.structured && d.structured.trace ? d.structured.trace : []).map((item, index) => `<div class="trace-item">
                  <span class="trace-dot">${index + 1}</span>
                  <div class="trace-body"><b>${esc(item.step)}</b><span>${esc(item.detail)}</span></div>
                </div>`).join("")}
              </div>
            </section>
            <section class="card insight-card">
              <h3>${icon("info", 17)} 档案信息</h3>
              <div class="info-list">
                <div class="info-row"><span>诊断编号</span><b class="mono">${esc(d.public_id)}</b></div>
                <div class="info-row"><span>所属课程</span><b>${esc(d.course)}</b></div>
                <div class="info-row"><span>问题类型</span><b>${esc(d.intent)}</b></div>
                <div class="info-row"><span>AI 引擎</span><b>${esc(d.ai_mode === "llm" ? "大模型增强" : "本地学情推理")}</b></div>
                <div class="info-row"><span>耗时</span><b>${d.duration_ms || 0} ms</b></div>
              </div>
            </section>
          </aside>
        </div>

        <section class="resources-block">
          <div class="rb-head">
            <div><div class="eyebrow">PERSONALIZED RESOURCES</div><h2>为你精准匹配的学习资源</h2></div>
            <span class="small muted">共 ${data.recommendations.length} 份 · 按薄弱点与问题类型排序</span>
          </div>
          <div class="res-grid">
            ${data.recommendations.map((item) => resourceCard(item, { reason: true })).join("")}
          </div>
        </section>

        <div class="flex gap-8 mt-24">
          ${isCounselor
            ? `<a class="btn" href="${backHref}">${icon("arrowLeft", 15)} 返回学生详情</a><button class="btn primary" data-report-student="${d.student_id}">${icon("file", 15)} 生成 AI 帮扶报告</button>`
            : `<a class="btn primary" href="#/diagnose">${icon("plus", 15)} 继续问诊</a><a class="btn" href="#/learning">${icon("chart", 15)} 查看学情轨迹</a>`}
        </div>
      </div>`;

    view.querySelectorAll("[data-resource]").forEach((card) => {
      card.addEventListener("click", () => openResource(Number(card.dataset.resource), d.id));
      card.addEventListener("keydown", (event) => {
        if (event.key === "Enter") openResource(Number(card.dataset.resource), d.id);
      });
    });
    const reportBtn = view.querySelector("[data-report-student]");
    if (reportBtn) {
      reportBtn.addEventListener("click", () => generateStudentReport(Number(reportBtn.dataset.reportStudent)));
    }
  }

  async function openResource(id, diagnosisId) {
    try {
      const item = await api(`/api/resource/${id}`);
      const style = TYPE_STYLE[item.type] || TYPE_STYLE["知识点讲解"];
      openModal(`<div class="modal-card resource-modal">
        <div class="modal-head">
          <span class="res-icon" style="--tint-bg:${style.bg};--tint-ink:${style.ink};width:42px;height:42px;flex:0 0 42px;border-radius:12px">${icon(style.icon, 19)}</span>
          <div style="min-width:0"><h2>${esc(item.title)}</h2><div class="modal-sub">${esc(item.type)} · ${esc(item.course)} · ${esc(item.level)} · ${item.minutes} 分钟</div></div>
          <button class="modal-close" data-close>${icon("x", 16)}</button>
        </div>
        <div class="modal-body resource-body">
          <div class="md-body">${mdToHtml(item.content)}</div>
        </div>
        <div class="modal-foot">
          <span class="small faint" style="margin-right:auto">来源：${esc(item.source)} · 校本知识库</span>
          ${item.learned
            ? `<span class="learned-note">${icon("checkCircle", 15)} 已完成学习</span>`
            : `<button class="btn primary" id="learn-btn">${icon("check", 15)} 标记为已学习</button>`}
        </div>
      </div>`);

      const learnBtn = document.getElementById("learn-btn");
      if (learnBtn) {
        learnBtn.addEventListener("click", async () => {
          learnBtn.disabled = true;
          learnBtn.innerHTML = `<span class="spinner"></span> 保存中…`;
          try {
            await api(`/api/student/resources/${id}/learn`, {
              method: "POST",
              body: diagnosisId ? { diagnosis_id: diagnosisId } : {},
            });
            learnBtn.outerHTML = `<span class="learned-note">${icon("checkCircle", 15)} 已完成学习，记录已留痕</span>`;
            toast("已标记为已学习，学习轨迹已更新", "ok");
          } catch (error) {
            toast(error.message, "error");
            learnBtn.disabled = false;
            learnBtn.textContent = "标记为已学习";
          }
        });
      }
    } catch (error) {
      toast(error.message, "error");
    }
  }

  /* =======================================================================
     Student · Resources
     ======================================================================= */
  async function pageResources() {
    const data = await api("/api/student/resources");
    state.resourceFilters = { q: "", type: "", course: "" };
    const view = document.getElementById("view");
    const types = state.meta.resource_types || [];
    const courses = Array.from(new Set(data.items.map((item) => item.course)));
    view.innerHTML = `
      <div class="page fade-up">
        <div class="page-head">
          <div><div class="eyebrow">RESOURCE LIBRARY</div><h1>学习资源库</h1><p class="lead">校本知识库共 ${data.total} 份资源，覆盖 ${courses.length} 门课程。按薄弱点、课程与资源类型筛选，学完可标记“已学习”形成轨迹。</p></div>
          <div class="flex gap-8"><span class="badge indigo">${icon("database", 12)} 校本知识库</span><span class="badge green">${icon("shield", 12)} 学习行为留痕</span></div>
        </div>
        <div class="toolbar">
          <div class="search-box">${icon("search", 16)}<input id="res-search" placeholder="搜索资源标题、课程或关键词" /></div>
          <select class="select" id="res-course" style="width:auto"><option value="">全部课程</option>${courses.map((course) => `<option value="${esc(course)}">${esc(course)}</option>`).join("")}</select>
          <span class="res-count" id="res-count">共 ${data.total} 份</span>
        </div>
        <div class="filter-chips" id="res-types" style="margin-bottom:16px">
          <button class="chip active" data-type="">全部类型</button>
          ${types.map((type) => `<button class="chip" data-type="${esc(type)}">${esc(type)}</button>`).join("")}
        </div>
        <div class="res-page-grid" id="res-grid"></div>
      </div>`;

    const grid = document.getElementById("res-grid");
    const count = document.getElementById("res-count");
    const render = () => {
      const filters = state.resourceFilters;
      const keyword = filters.q.toLowerCase();
      const items = data.items.filter((item) => {
        if (filters.type && item.type !== filters.type) return false;
        if (filters.course && item.course !== filters.course) return false;
        if (keyword && !`${item.title} ${item.summary} ${item.course}`.toLowerCase().includes(keyword)) return false;
        return true;
      });
      count.textContent = `共 ${items.length} 份`;
      grid.innerHTML = items.length ? items.map((item) => resourceCard(item)).join("") : emptyHTML("没有匹配的资源", "试试更换关键词或筛选条件");
      grid.querySelectorAll("[data-resource]").forEach((card) => {
        card.addEventListener("click", () => openResource(Number(card.dataset.resource)));
      });
    };
    render();
    document.getElementById("res-search").addEventListener("input", (event) => {
      state.resourceFilters.q = event.target.value.trim();
      render();
    });
    document.getElementById("res-course").addEventListener("change", (event) => {
      state.resourceFilters.course = event.target.value;
      render();
    });
    document.getElementById("res-types").addEventListener("click", (event) => {
      const button = event.target.closest("[data-type]");
      if (!button) return;
      state.resourceFilters.type = button.dataset.type;
      document.querySelectorAll("#res-types .chip").forEach((chip) => chip.classList.toggle("active", chip === button));
      render();
    });
  }

  /* =======================================================================
     Student · Learning
     ======================================================================= */
  async function pageLearning() {
    const [profile, history] = await Promise.all([
      api("/api/student/profile"),
      api("/api/student/diagnoses?page=1"),
    ]);
    const stats = profile.stats;
    const view = document.getElementById("view");
    view.innerHTML = `
      <div class="page fade-up">
        <div class="page-head">
          <div><div class="eyebrow">MY LEARNING PULSE</div><h1>我的学情</h1><p class="lead">${esc(profile.profile.name)} · ${esc(profile.profile.class_name)}。这里聚合了每一次问诊、资源学习与台账跟进，形成可回看的学习轨迹。</p></div>
          <div class="page-head-actions">
            <button class="btn" id="export-my-report">${icon("download", 15)} 导出个人学情报告</button>
            <a class="btn primary" href="#/diagnose">${icon("sparkle", 15)} 发起新问诊</a>
          </div>
        </div>

        <div class="kpi-grid">
          ${kpiCard({ label: "累计问诊", value: stats.diagnoses, unit: "次", sub: `覆盖 ${stats.courses} 门课程`, iconName: "chat", tint: "#eef2ff", tintInk: "#4f46e5" })}
          ${kpiCard({ label: "平均掌握度", value: stats.avg_mastery, unit: "/100", sub: `连续学习 ${stats.streak} 天`, iconName: "target", tint: "#ecfeff", tintInk: "#0891b2" })}
          ${kpiCard({ label: "已完成资源", value: stats.learned, unit: "份", sub: "标记已学习后计入档案", iconName: "book", tint: "#ecfdf5", tintInk: "#059669" })}
          ${kpiCard({ label: "台账闭环", value: stats.closure_rate, unit: "%", sub: `${stats.closed} 条已闭环 / ${stats.pending} 条跟进中`, iconName: "file", tint: "#fffbeb", tintInk: "#b45309" })}
        </div>

        <div class="chart-grid mt-16">
          <section class="card chart-card">
            <div class="chart-head"><div><h3>掌握度变化趋势</h3><p>最近 10 次 AI 诊断的综合掌握度评估</p></div><span class="badge indigo">AI 评估</span></div>
            ${profile.trend.length ? chartLine(profile.trend.map((row) => ({ label: row.date, value: row.mastery })), [{ key: "value", color: "#6366f1", label: "掌握度" }], { labels: 6 }) : emptyHTML("还没有足够的数据", "完成问诊后生成趋势")}
          </section>
          <section class="card chart-card">
            <div class="chart-head"><div><h3>问题类型分布</h3><p>AI 对历次提问的意图归类</p></div></div>
            <div class="donut-wrap">${chartDonut(profile.intent_dist, stats.diagnoses, "次问诊")}${intentLegend(profile.intent_dist)}</div>
          </section>
        </div>

        <div class="chart-grid mt-16">
          <section class="card chart-card">
            <div class="chart-head"><div><h3>能力短板画像</h3><p>分数越低，越需要优先干预</p></div><span class="badge gray">6 维能力</span></div>
            <div class="donut-wrap" style="justify-content:center">${radarChart(profile.abilities)}</div>
          </section>
          <section class="card chart-card">
            <div class="chart-head"><div><h3>高频薄弱知识点</h3><p>按被问诊提及次数排序</p></div></div>
            ${weakBarsHTML(profile.weak_points)}
          </section>
        </div>

        <div class="mt-24" style="display:grid;grid-template-columns:minmax(0,1.4fr) minmax(300px,1fr);gap:18px" id="learning-columns">
          <section class="card chart-card">
            <div class="chart-head"><div><h3>问诊记录</h3><p>共 ${history.total} 次，点击查看完整诊断</p></div><span class="badge gray">${icon("lock", 11)} 不可修改</span></div>
            <div class="diag-list" id="diag-history">
              ${history.items.length ? history.items.map((item) => `<div class="diag-item" data-diagnosis="${item.id}">
                <div class="di-date"><b>${fmtShort(item.created_at).slice(3)}</b><span>${fmtShort(item.created_at).slice(0, 2)} 月</span></div>
                <div class="di-body"><b>${esc(item.course)} · ${esc(item.intent)}</b><p>${esc(item.weak_names.join("、") || item.public_id)}</p></div>
                <div class="di-side"><span class="badge ${INTENT_STYLE[item.intent] ? INTENT_STYLE[item.intent].badge : "gray"}">掌握度 ${item.mastery}</span><span class="small faint">${esc(item.public_id)}</span></div>
              </div>`).join("") : emptyHTML("还没有问诊记录", "从智能问诊开始你的第一次 AI 诊断")}
            </div>
            ${history.pages > 1 ? `<div class="pagination"><span class="count">第 1 / ${history.pages} 页</span><div class="pages"><button class="page-btn" disabled>${icon("chevronRight", 13)}</button></div></div>` : ""}
          </section>
          <aside class="side-stack">
            <section class="card chart-card">
              <div class="chart-head"><div><h3>学习轨迹</h3><p>问诊、资源与台账的时间线</p></div></div>
              <div class="timeline">
                ${profile.timeline.slice(0, 8).map((item) => `<div class="timeline-item">
                  <span class="timeline-icon ${item.type === "resource" ? "green" : item.type === "ledger" ? "amber" : ""}">${icon(item.type === "resource" ? "book" : item.type === "ledger" ? "file" : "sparkle", 14)}</span>
                  <div class="timeline-body"><div class="tl-top"><b>${esc(item.title)}</b><span class="tl-date">${fmtShort(item.date)}</span></div><p>${esc(item.desc)}</p></div>
                </div>`).join("") || emptyHTML("暂无轨迹")}
              </div>
            </section>
            <section class="card chart-card">
              <div class="chart-head"><div><h3>学习热力</h3><p>最近 8 周的问诊与资源学习</p></div></div>
              ${heatmapHTML(profile.heatmap)}
            </section>
          </aside>
        </div>
      </div>`;

    view.querySelectorAll("[data-diagnosis]").forEach((item) => {
      item.addEventListener("click", () => {
        state.studentId = null;
        location.hash = `#/diagnosis/${item.dataset.diagnosis}`;
      });
    });
    document.getElementById("export-my-report").addEventListener("click", () => {
      downloadFile(
        "/api/student/export/report.pdf",
        "智学_个人学情报告.pdf",
        "/print/report?type=student"
      );
    });
  }

  /* =======================================================================
     Student · Profile
     ======================================================================= */
  async function pageProfile() {
    const profile = await api("/api/student/profile");
    const p = profile.profile;
    const view = document.getElementById("view");
    view.innerHTML = `
      <div class="page fade-up">
        <div class="card profile-hero">
          ${avatar(p.name, "cyan")}
          <div class="profile-identity">
            <h1>${esc(p.name)} <span class="badge indigo">学生</span></h1>
            <div class="pi-meta">
              <span>${icon("user", 13)} ${esc(p.student_no)}</span>
              <span>${icon("home", 13)} ${esc(p.class_name)}</span>
              <span>${icon("book", 13)} ${esc(p.major)}</span>
              <span>${icon("users", 13)} 辅导员 ${esc(p.counselor_name || "待分配")}</span>
            </div>
            <div class="profile-tags">${(p.tags || []).map((tag) => `<span class="tag">${esc(tag)}</span>`).join("")}<span class="tag primary">AI 学情档案</span></div>
          </div>
          <div class="profile-actions">
            <button class="btn" id="view-report">${icon("eye", 15)} 查看学情报告</button>
            <button class="btn primary" id="export-report">${icon("download", 15)} 导出 PDF</button>
          </div>
        </div>

        <div class="kpi-grid">
          ${kpiCard({ label: "问诊次数", value: profile.stats.diagnoses, unit: "次", sub: `覆盖 ${profile.stats.courses} 门课程`, iconName: "chat", tint: "#eef2ff", tintInk: "#4f46e5" })}
          ${kpiCard({ label: "平均掌握度", value: profile.stats.avg_mastery, unit: "/100", sub: "AI 综合评估", iconName: "target", tint: "#ecfeff", tintInk: "#0891b2" })}
          ${kpiCard({ label: "台账记录", value: profile.ledger_count, unit: "条", sub: `${profile.stats.closed} 条已闭环`, iconName: "file", tint: "#ecfdf5", tintInk: "#059669" })}
          ${kpiCard({ label: "已完成资源", value: profile.stats.learned, unit: "份", sub: "计入个人学习档案", iconName: "book", tint: "#fffbeb", tintInk: "#b45309" })}
        </div>

        <div class="profile-grid mt-16">
          <div class="col-main">
            <section class="card chart-card">
              <div class="chart-head"><div><h3>学习轨迹</h3><p>问诊 · 资源 · 台账，全部永久留痕</p></div><span class="badge green">${icon("shield", 11)} 哈希链</span></div>
              <div class="timeline">
                ${profile.timeline.map((item) => `<div class="timeline-item">
                  <span class="timeline-icon ${item.type === "resource" ? "green" : item.type === "ledger" ? "amber" : ""}">${icon(item.type === "resource" ? "book" : item.type === "ledger" ? "file" : "sparkle", 14)}</span>
                  <div class="timeline-body"><div class="tl-top"><b>${esc(item.title)}</b><span class="tl-date">${fmtDate(item.date)}</span></div><p>${esc(item.desc)}</p></div>
                </div>`).join("") || emptyHTML("暂无学习轨迹")}
              </div>
            </section>
            <section class="card chart-card mt-16">
              <div class="chart-head"><div><h3>学习热力</h3><p>最近 8 周的问诊与资源学习次数</p></div></div>
              ${heatmapHTML(profile.heatmap)}
            </section>
          </div>
          <aside class="side-stack">
            <section class="card chart-card">
              <div class="chart-head"><div><h3>学籍信息</h3></div></div>
              <div class="info-list">
                <div class="info-row"><span>姓名</span><b>${esc(p.name)}</b></div>
                <div class="info-row"><span>学号</span><b class="mono">${esc(p.student_no)}</b></div>
                <div class="info-row"><span>班级</span><b>${esc(p.class_name)}</b></div>
                <div class="info-row"><span>专业</span><b>${esc(p.major)}</b></div>
                <div class="info-row"><span>年级</span><b>${esc(p.grade || "2024")}</b></div>
                <div class="info-row"><span>辅导员</span><b>${esc(p.counselor_name || "待分配")}</b></div>
                <div class="info-row"><span>邮箱</span><b>${esc(p.email)}</b></div>
              </div>
            </section>
            <section class="card chart-card">
              <div class="chart-head"><div><h3>台账记录</h3><p>AI 自动生成</p></div></div>
              <div class="ledger-mini-list">
                ${profile.timeline.filter((item) => item.type === "ledger").slice(0, 5).map((item) => `<div class="ledger-mini"><span class="lm-code">${esc(item.title.split("·")[1] || "")}</span><span class="small">${esc(item.desc.replace("状态：", ""))}</span><span class="lm-date">${fmtShort(item.date)}</span></div>`).join("") || `<p class="small muted">暂无台账记录</p>`}
              </div>
            </section>
          </aside>
        </div>
      </div>`;

    document.getElementById("export-report").addEventListener("click", () => {
      downloadFile("/api/student/export/report.pdf", "智学_个人学情报告.pdf", "/print/report?type=student");
    });
    document.getElementById("view-report").addEventListener("click", async () => {
      try {
        const report = await api("/api/student/report");
        openReportModal(report, {
          download: "/api/student/export/report.pdf",
          print: "/print/report?type=student",
          filename: "智学_个人学情报告.pdf",
        });
      } catch (error) {
        toast(error.message, "error");
      }
    });
  }

  /* =======================================================================
     Counselor · Overview
     ======================================================================= */
  async function pageOverview() {
    const query = buildQuery({ days: state.dash.days, class_id: state.dash.classId });
    const data = await api(`/api/counselor/overview${query}`);
    state.overview = data;
    const stats = data.stats;
    const view = document.getElementById("view");
    const classOptions = `<option value="">全部班级</option>` + (state.meta.classes || []).map((item) =>
      `<option value="${item.id}" ${String(item.id) === String(state.dash.classId) ? "selected" : ""}>${esc(item.name)}</option>`
    ).join("");
    const days = state.dash.days;
    view.innerHTML = `
      <div class="page fade-up">
        <div class="overview-head">
          <div>
            <div class="eyebrow">ACADEMIC CARE DASHBOARD</div>
            <h1>学情总览</h1>
            <p class="lead">${esc(data.scope.class_name)} · 近 ${days} 天 · AI 自动汇总学生问诊与台账跟进情况</p>
          </div>
          <div class="overview-controls">
            ${(state.meta.classes || []).length > 1 ? `<select class="select" id="dash-class" style="width:auto">${classOptions}</select>` : ""}
            <div class="seg" id="dash-days">
              ${[7, 14, 30].map((value) => `<button data-days="${value}" class="${value === days ? "active" : ""}">近 ${value} 天</button>`).join("")}
            </div>
            <button class="btn" id="export-ledgers-top">${icon("download", 15)} 导出台账</button>
            <button class="btn primary" id="generate-class-report">${icon("file", 15)} 生成班级报告</button>
          </div>
        </div>

        <div class="kpi-grid">
          ${kpiCard({ label: "学生覆盖", value: stats.active, unit: `/ ${stats.students} 人`, sub: `覆盖率 ${stats.coverage}%`, iconName: "users", tint: "#eef2ff", tintInk: "#4f46e5" })}
          ${kpiCard({ label: "问诊总量", value: stats.diagnoses, unit: "次", sub: `今日新增 ${stats.today} 次 · ${stats.ledgers} 条台账`, iconName: "chat", tint: "#ecfeff", tintInk: "#0891b2" })}
          ${kpiCard({ label: "台账闭环率", value: stats.closure_rate, unit: "%", sub: `${stats.closed} 条已闭环 · ${stats.pending_total} 条未闭环`, iconName: "file", tint: "#ecfdf5", tintInk: "#059669" })}
          ${kpiCard({ label: "平均掌握度", value: stats.avg_mastery, unit: "/100", sub: `高风险 ${data.risk_students.filter((item) => item.level === "高").length} 人需重点关注`, iconName: "target", tint: "#fffbeb", tintInk: "#b45309" })}
        </div>

        <section class="ai-summary">
          <span class="summary-icon">${icon("sparkle", 24)}</span>
          <div class="summary-body">
            <div class="eyebrow">AI 今日学情摘要</div>
            <h3>本周学情画像已自动生成</h3>
            <p>${esc(data.ai_summary)}</p>
            <ul>${data.suggestions.slice(0, 3).map((item) => `<li>${esc(item)}</li>`).join("")}</ul>
          </div>
          <div class="summary-actions">
            <button class="btn" id="summary-report">${icon("file", 14)} 生成分析报告</button>
            <button class="btn" id="summary-students">${icon("users", 14)} 查看重点关注</button>
          </div>
        </section>

        <div class="dash-grid">
          <section class="card chart-card">
            <div class="chart-head"><div><h3>问题类型分布</h3><p>AI 意图识别结果 · 近 ${days} 天</p></div><span class="badge indigo">${stats.diagnoses} 次</span></div>
            <div class="donut-wrap">${chartDonut(data.intents, stats.diagnoses, "次问诊")}${intentLegend(data.intents)}</div>
          </section>
          <section class="card chart-card">
            <div class="chart-head"><div><h3>问诊与台账趋势</h3><p>每日问诊量与自动生成台账量</p></div></div>
            ${chartLine(data.trend, [
              { key: "diagnoses", color: "#6366f1", label: "问诊量" },
              { key: "ledgers", color: "#06b6d4", label: "台账量" },
            ], { labels: 7 })}
          </section>
          <section class="card chart-card">
            <div class="chart-head"><div><h3>高频薄弱知识点</h3><p>按被问诊提及次数排序</p></div></div>
            ${weakBarsHTML(data.weak_points)}
          </section>
          <section class="card chart-card">
            <div class="chart-head"><div><h3>重点关注学生</h3><p>AI 依据掌握度与台账状态综合排序</p></div><a class="small" href="#/students" style="color:#4f46e5">全部学生</a></div>
            <div class="risk-list">
              ${data.risk_students.length ? data.risk_students.map((item) => `<div class="risk-item" data-student="${item.id}">
                ${avatar(item.name, item.level === "高" ? "rose" : item.level === "中" ? "amber" : "green")}
                <div class="ri-body"><b>${esc(item.name)}</b><p>${esc(item.reason)}</p></div>
                <div class="ri-side">${riskBadge(item.level)}<span class="score">${item.avg_mastery}/100</span></div>
              </div>`).join("") : emptyHTML("暂无需要重点关注的学生")}
            </div>
          </section>
        </div>

        <section class="card chart-card mt-16">
          <div class="chart-head"><div><h3>最近自动生成的台账</h3><p>问诊结束即生成，无需辅导员手动录入</p></div><a class="btn sm" href="#/ledgers">进入台账管理 ${icon("arrowRight", 13)}</a></div>
          <div class="table-wrap">
            <table class="data">
              <thead><tr><th>台账编号</th><th>学生</th><th>问题类型</th><th>掌握度</th><th>状态</th><th>学生问题</th><th>生成时间</th></tr></thead>
              <tbody>${data.recent_ledgers.map(ledgerRowHTML).join("")}</tbody>
            </table>
          </div>
        </section>
      </div>`;

    view.querySelectorAll("[data-student]").forEach((item) => {
      item.addEventListener("click", () => { location.hash = `#/students/${item.dataset.student}`; });
    });
    view.querySelectorAll("[data-ledger]").forEach((row) => {
      row.addEventListener("click", () => openLedger(Number(row.dataset.ledger)));
    });
    const daysBox = document.getElementById("dash-days");
    if (daysBox) {
      daysBox.addEventListener("click", (event) => {
        const button = event.target.closest("[data-days]");
        if (!button) return;
        state.dash.days = Number(button.dataset.days);
        pageOverview().catch(showPageError);
      });
    }
    const classBox = document.getElementById("dash-class");
    if (classBox) {
      classBox.addEventListener("change", () => {
        state.dash.classId = classBox.value;
        pageOverview().catch(showPageError);
      });
    }
    document.getElementById("generate-class-report").addEventListener("click", () => generateClassReport());
    document.getElementById("summary-report").addEventListener("click", () => generateClassReport());
    document.getElementById("summary-students").addEventListener("click", () => { location.hash = "#/students"; });
    document.getElementById("export-ledgers-top").addEventListener("click", () => {
      const qs = buildQuery({ class_id: state.dash.classId });
      downloadFile(`/api/counselor/export/ledgers.xlsx${qs}`, "智学_学工台账.xlsx", `/print/ledgers${qs}`);
    });
  }

  function showPageError(error) {
    const view = document.getElementById("view");
    if (view) {
      view.innerHTML = errorHTML(error.message);
      const retry = view.querySelector("[data-retry]");
      if (retry) retry.addEventListener("click", () => renderRoute());
    }
  }

  /* =======================================================================
     Counselor · Students
     ======================================================================= */
  async function pageStudents() {
    const focusId = document.activeElement && document.activeElement.id;
    const caret = focusId ? document.activeElement.selectionStart : null;
    const data = await api(`/api/counselor/students${buildQuery(state.studentFilters)}`);
    const view = document.getElementById("view");
    const summary = data.summary;
    view.innerHTML = `
      <div class="page fade-up">
        <div class="page-head">
          <div><div class="eyebrow">STUDENT CARE LIST</div><h1>学生学情</h1><p class="lead">${esc(data.scope_name)} · 共 ${summary.total} 名学生。AI 依据问诊频次、掌握度与台账状态自动标记风险等级。</p></div>
          <div class="flex gap-8"><span class="badge rose">高风险 ${summary.high}</span><span class="badge amber">待跟进 ${summary.pending} 条</span><span class="badge green">已问诊 ${summary.active}</span></div>
        </div>
        <div class="toolbar">
          <div class="search-box">${icon("search", 16)}<input id="student-search" value="${esc(state.studentFilters.q)}" placeholder="搜索姓名、学号或薄弱知识点" /></div>
          <div class="filter-chips" id="risk-chips">
            ${[["all", "全部学生"], ["高", "高风险"], ["中", "中风险"], ["低", "低风险"]].map(([value, label]) => `<button class="chip ${state.studentFilters.risk === value ? "active" : ""}" data-risk="${value}">${label}</button>`).join("")}
          </div>
          <select class="select" id="student-status" style="width:auto">
            <option value="all" ${state.studentFilters.status === "all" ? "selected" : ""}>全部状态</option>
            <option value="active" ${state.studentFilters.status === "active" ? "selected" : ""}>已问诊</option>
            <option value="silent" ${state.studentFilters.status === "silent" ? "selected" : ""}>未问诊</option>
          </select>
        </div>
        <div class="table-wrap">
          <table class="data">
            <thead><tr><th>学生</th><th>班级</th><th>问诊次数</th><th>平均掌握度</th><th>待跟进</th><th>最近活跃</th><th>风险等级</th><th>主要薄弱点</th><th></th></tr></thead>
            <tbody>
              ${data.items.length ? data.items.map((item) => `<tr class="clickable" data-student="${item.id}">
                <td><div class="student-cell">${avatar(item.name, item.risk === "高" ? "rose" : item.risk === "中" ? "amber" : "green")}<div><b>${esc(item.name)}</b><span>${esc(item.student_no)}</span></div></div></td>
                <td>${esc(item.class_name)}</td>
                <td><b class="strong">${item.diagnoses}</b> 次</td>
                <td><div class="mastery-cell"><div class="bar-track"><div class="bar-fill ${masteryClass(item.avg_mastery)}" style="width:${item.avg_mastery}%"></div></div><b>${item.avg_mastery}</b></div></td>
                <td>${item.pending ? `<span class="badge amber">${item.pending} 条</span>` : `<span class="small faint">—</span>`}</td>
                <td><span class="small">${esc(item.last_text)}</span></td>
                <td>${riskBadge(item.risk)}</td>
                <td>${item.top_weak ? `<span class="small">${esc(item.top_weak)}</span>` : `<span class="small faint">—</span>`}</td>
                <td><span class="small" style="color:#4f46e5;font-weight:600">查看 ${icon("chevronRight", 12)}</span></td>
              </tr>`).join("") : `<tr><td colspan="9">${emptyHTML("没有匹配的学生")}</td></tr>`}
            </tbody>
          </table>
        </div>
        <div class="pagination"><span class="count">共 ${data.total} 名学生</span><span class="small faint">点击行查看完整学情档案</span></div>
      </div>`;

    view.querySelectorAll("[data-student]").forEach((row) => {
      row.addEventListener("click", () => { location.hash = `#/students/${row.dataset.student}`; });
    });
    let timer = null;
    document.getElementById("student-search").addEventListener("input", (event) => {
      state.studentFilters.q = event.target.value.trim();
      clearTimeout(timer);
      timer = setTimeout(() => pageStudents().catch(showPageError), 260);
    });
    document.getElementById("risk-chips").addEventListener("click", (event) => {
      const chip = event.target.closest("[data-risk]");
      if (!chip) return;
      state.studentFilters.risk = chip.dataset.risk;
      pageStudents().catch(showPageError);
    });
    document.getElementById("student-status").addEventListener("change", (event) => {
      state.studentFilters.status = event.target.value;
      pageStudents().catch(showPageError);
    });
    if (focusId === "student-search") {
      const input = document.getElementById("student-search");
      if (input) {
        input.focus();
        if (caret !== null && input.setSelectionRange) input.setSelectionRange(caret, caret);
      }
    }
  }

  /* =======================================================================
     Counselor · Student detail
     ======================================================================= */
  async function pageStudentDetail(id) {
    if (!id) throw new Error("缺少学生编号");
    const data = await api(`/api/counselor/students/${id}`);
    state.studentId = id;
    const p = data.profile;
    const risk = data.risk;
    const stats = data.stats;
    const view = document.getElementById("view");
    view.innerHTML = `
      <div class="page fade-up">
        <div class="detail-bar">
          <a class="back-link" href="#/students">${icon("arrowLeft", 15)} 返回学生列表</a>
          <div class="detail-meta"><span>档案编号</span><span class="mono">STU-${String(p.id).padStart(4, "0")}</span><span class="badge gray">${icon("shield", 11)} 学情档案</span></div>
        </div>

        <div class="card profile-banner">
          ${avatar(p.name, risk.level === "高" ? "rose" : risk.level === "中" ? "amber" : "green")}
          <div class="pb-info">
            <h1>${esc(p.name)} ${riskBadge(risk.level)}</h1>
            <div class="pb-meta"><span>${esc(p.student_no)}</span><span>${esc(p.class_name)}</span><span>${esc(p.major)}</span><span>辅导员 ${esc(p.counselor_name || "—")}</span></div>
          </div>
          <div class="profile-actions">
            <button class="btn" id="export-student-report">${icon("download", 15)} 导出帮扶报告</button>
            <button class="btn primary" id="generate-student-report">${icon("sparkle", 15)} 生成 AI 帮扶报告</button>
          </div>
        </div>

        <div class="kpi-grid">
          ${kpiCard({ label: "问诊次数", value: stats.diagnoses, unit: "次", sub: `覆盖 ${stats.courses} 门课程`, iconName: "chat", tint: "#eef2ff", tintInk: "#4f46e5" })}
          ${kpiCard({ label: "平均掌握度", value: stats.avg_mastery, unit: "/100", sub: `风险等级：${risk.level}`, iconName: "target", tint: "#ecfeff", tintInk: "#0891b2" })}
          ${kpiCard({ label: "待跟进台账", value: stats.pending, unit: "条", sub: `${stats.closed} 条已闭环`, iconName: "file", tint: "#fffbeb", tintInk: "#b45309" })}
          ${kpiCard({ label: "完成资源", value: stats.learned, unit: "份", sub: `连续学习 ${stats.streak} 天`, iconName: "book", tint: "#ecfdf5", tintInk: "#059669" })}
        </div>

        <div class="chart-grid mt-16">
          <section class="card chart-card">
            <div class="chart-head"><div><h3>掌握度趋势</h3><p>${esc(risk.reason)}</p></div>${riskBadge(risk.level)}</div>
            ${data.trend.length ? chartLine(data.trend.map((row) => ({ label: row.date, value: row.mastery })), [{ key: "value", color: "#6366f1", label: "掌握度" }], { labels: 6 }) : emptyHTML("暂无趋势数据")}
          </section>
          <section class="card chart-card">
            <div class="chart-head"><div><h3>能力画像</h3><p>分数越低越需要干预</p></div></div>
            <div class="donut-wrap" style="justify-content:center">${radarChart(data.abilities)}</div>
          </section>
        </div>

        <div class="dash-grid mt-16">
          <section class="card chart-card">
            <div class="chart-head"><div><h3>高频薄弱知识点</h3><p>按被问诊提及次数排序</p></div></div>
            ${weakBarsHTML(data.weak_points)}
          </section>
          <section class="card chart-card">
            <div class="chart-head"><div><h3>问题类型分布</h3><p>AI 意图识别结果</p></div><span class="badge indigo">${stats.diagnoses} 次</span></div>
            <div class="donut-wrap">${chartDonut(data.intent_dist, stats.diagnoses, "次问诊")}${intentLegend(data.intent_dist)}</div>
          </section>
        </div>

        <div class="tabs mt-24" id="detail-tabs">
          <button class="tab active" data-tab="diagnoses">学情诊断 <span class="badge gray">${data.diagnoses.length}</span></button>
          <button class="tab" data-tab="ledgers">台账记录 <span class="badge gray">${data.ledgers.length}</span></button>
          <button class="tab" data-tab="resources">学习资源 <span class="badge gray">${data.learned.length}</span></button>
        </div>
        <div id="tab-diagnoses" class="tab-panel">
          <div class="diag-list">
            ${data.diagnoses.length ? data.diagnoses.map((item) => `<div class="diag-item" data-diagnosis="${item.id}">
              <div class="di-date"><b>${fmtShort(item.created_at).slice(3)}</b><span>${fmtShort(item.created_at).slice(0, 2)} 月</span></div>
              <div class="di-body"><b>${esc(item.course)} · ${esc(item.intent)}</b><p>${esc(item.weak_names.join("、") || item.public_id)}</p></div>
              <div class="di-side"><span class="badge ${INTENT_STYLE[item.intent] ? INTENT_STYLE[item.intent].badge : "gray"}">掌握度 ${item.mastery}</span><span class="small faint">${esc(item.public_id)}</span></div>
            </div>`).join("") : emptyHTML("该生暂无问诊记录")}
          </div>
        </div>
        <div id="tab-ledgers" class="tab-panel hidden">
          ${data.ledgers.length ? `<div class="table-wrap"><table class="data"><thead><tr><th>台账编号</th><th>问题类型</th><th>掌握度</th><th>状态</th><th>帮扶时间</th><th>跟进记录</th></tr></thead><tbody>
            ${data.ledgers.map((item) => `<tr class="clickable" data-ledger="${item.id}"><td class="mono strong">${esc(item.code)}</td><td>${intentBadge(item.intent)}</td><td>${item.mastery}</td><td>${statusBadge(item.status)}</td><td class="small">${esc(item.help_text)}</td><td class="small">${esc((item.follow_up || "待补充").slice(0, 30))}</td></tr>`).join("")}
          </tbody></table></div>` : emptyHTML("该生暂无台账记录")}
        </div>
        <div id="tab-resources" class="tab-panel hidden">
          ${data.learned.length ? `<div class="res-grid">${data.learned.map((item) => resourceCard(item)).join("")}</div>` : emptyHTML("还没有完成的学习资源")}
        </div>
      </div>`;

    document.getElementById("detail-tabs").addEventListener("click", (event) => {
      const tab = event.target.closest("[data-tab]");
      if (!tab) return;
      document.querySelectorAll("#detail-tabs .tab").forEach((item) => item.classList.toggle("active", item === tab));
      ["diagnoses", "ledgers", "resources"].forEach((key) => {
        const panel = document.getElementById(`tab-${key}`);
        if (panel) panel.classList.toggle("hidden", key !== tab.dataset.tab);
      });
    });
    view.querySelectorAll("[data-diagnosis]").forEach((item) => {
      item.addEventListener("click", () => { location.hash = `#/diagnosis/${item.dataset.diagnosis}`; });
    });
    view.querySelectorAll("[data-ledger]").forEach((row) => {
      row.addEventListener("click", () => openLedger(Number(row.dataset.ledger)));
    });
    view.querySelectorAll("[data-resource]").forEach((card) => {
      card.addEventListener("click", () => openResource(Number(card.dataset.resource)));
    });
    document.getElementById("generate-student-report").addEventListener("click", () => generateStudentReport(id));
    document.getElementById("export-student-report").addEventListener("click", () => {
      downloadFile(
        `/api/counselor/export/report.pdf?type=student&id=${id}`,
        `智学_${p.name}_学情帮扶报告.pdf`,
        `/print/report?type=student&id=${id}`
      );
    });
  }

  /* =======================================================================
     Counselor · Reports
     ======================================================================= */
  async function pageReports() {
    const [students, audit] = await Promise.all([
      api("/api/counselor/students"),
      api("/api/counselor/audit"),
    ]);
    const view = document.getElementById("view");
    const classOptions = `<option value="">全部班级</option>` + (state.meta.classes || []).map((item) => `<option value="${item.id}">${esc(item.name)}</option>`).join("");
    view.innerHTML = `
      <div class="page fade-up">
        <div class="page-head">
          <div><div class="eyebrow">AI REPORT AGENT</div><h1>AI 帮扶报告</h1><p class="lead">系统依据真实问诊与台账数据，自动生成个人帮扶报告或班级学情分析报告，可直接导出 PDF 归档。</p></div>
          <span class="badge violet">${icon("sparkle", 12)} 报告由 AI 自动撰写</span>
        </div>

        <div class="report-actions">
          <section class="action-card" style="--tint:rgba(99,102,241,.14);--tint-bg:#eef2ff;--tint-ink:#4f46e5">
            <div class="ac-icon">${icon("users", 21)}</div>
            <h3>班级学情分析报告</h3>
            <p>汇总班级覆盖、问题类型结构、高频薄弱点、重点关注学生与分层帮扶策略，适合学工例会与学院报备。</p>
            <div class="ac-form">
              <select class="select" id="class-report-class">${classOptions}</select>
              <select class="select" id="class-report-days" style="max-width:120px">
                <option value="7">近 7 天</option><option value="14">近 14 天</option><option value="30" selected>近 30 天</option>
              </select>
              <button class="btn primary" id="class-report-btn">${icon("sparkle", 15)} 生成报告</button>
            </div>
          </section>
          <section class="action-card" style="--tint:rgba(6,182,212,.14);--tint-bg:#ecfeff;--tint-ink:#0891b2">
            <div class="ac-icon">${icon("user", 21)}</div>
            <h3>学生个人帮扶报告</h3>
            <p>按学生聚合诊断结论、薄弱知识点、资源学习与台账跟进，生成可签字归档的一对一帮扶报告。</p>
            <div class="ac-form">
              <select class="select" id="student-report-select">
                <option value="">选择学生（共 ${students.items.length} 人）</option>
                ${students.items.map((item) => `<option value="${item.id}">${esc(item.name)} · ${esc(item.student_no)} · ${item.risk === "高" ? "高风险" : item.risk === "中" ? "中风险" : "低风险"}</option>`).join("")}
              </select>
              <button class="btn primary" id="student-report-btn">${icon("sparkle", 15)} 生成报告</button>
            </div>
          </section>
        </div>

        <div class="profile-grid">
          <section class="card chart-card">
            <div class="chart-head"><div><h3>报告包含什么</h3><p>所有内容均由 AI 依据真实数据生成，无模板空话</p></div></div>
            <div class="feature-strip" style="grid-template-columns:1fr 1fr;box-shadow:none">
              <div class="feature-item"><div class="fi-icon">${icon("chart", 16)}</div><b>学情概览</b><span>问诊次数、覆盖课程、掌握度与趋势</span></div>
              <div class="feature-item"><div class="fi-icon" style="background:#ecfeff;color:#0891b2">${icon("target", 16)}</div><b>薄弱点分析</b><span>高频知识点、掌握度与易错清单</span></div>
              <div class="feature-item"><div class="fi-icon" style="background:#ecfdf5;color:#059669">${icon("sparkle", 16)}</div><b>AI 帮扶建议</b><span>可执行的两周行动计划与复测目标</span></div>
              <div class="feature-item"><div class="fi-icon" style="background:#fffbeb;color:#b45309">${icon("file", 16)}</div><b>台账与归档</b><span>台账记录、报告编号与 SHA-256 指纹</span></div>
            </div>
          </section>
          <section class="card chart-card">
            <div class="chart-head"><div><h3>最近生成</h3><p>已归档的报告记录</p></div><span class="badge gray">${audit.stats.reports} 份</span></div>
            <div class="report-list">
              ${audit.recent_reports.length ? audit.recent_reports.map((item) => `<div class="report-row">
                <span class="rp-icon">${icon(item.type === "class" ? "users" : "user", 14)}</span>
                <div class="rp-body"><b>${esc(item.title)}</b><span>${esc(item.code)} · ${esc(item.generated_at)}</span></div>
                <span class="badge ${item.type === "class" ? "indigo" : "cyan"}">${item.type === "class" ? "班级" : "个人"}</span>
              </div>`).join("") : emptyHTML("还没有生成报告", "使用上方按钮生成第一份 AI 报告")}
            </div>
          </section>
        </div>
      </div>`;

    document.getElementById("class-report-btn").addEventListener("click", async (event) => {
      const button = event.currentTarget;
      const classId = document.getElementById("class-report-class").value;
      const days = document.getElementById("class-report-days").value;
      button.disabled = true;
      button.innerHTML = `<span class="spinner"></span> AI 正在撰写…`;
      try {
        const report = await api("/api/counselor/reports/class", {
          method: "POST",
          body: { class_id: classId ? Number(classId) : null, days: Number(days) },
        });
        toast("班级学情报告已生成并归档", "ok");
        openReportModal(report, {
          download: `/api/counselor/export/report.pdf?type=class&class_id=${classId}&days=${days}`,
          print: `/print/report?type=class&class_id=${classId}&days=${days}`,
          filename: `${report.title}.pdf`,
        });
      } catch (error) {
        toast(error.message, "error");
      } finally {
        button.disabled = false;
        button.innerHTML = `${icon("sparkle", 15)} 生成报告`;
      }
    });

    document.getElementById("student-report-btn").addEventListener("click", async (event) => {
      const button = event.currentTarget;
      const studentId = document.getElementById("student-report-select").value;
      if (!studentId) {
        toast("请先选择一名学生", "warn");
        return;
      }
      button.disabled = true;
      button.innerHTML = `<span class="spinner"></span> AI 正在撰写…`;
      try {
        const report = await api(`/api/counselor/reports/student/${studentId}`, { method: "POST", body: {} });
        toast("个人帮扶报告已生成并归档", "ok");
        openReportModal(report, {
          download: `/api/counselor/export/report.pdf?type=student&id=${studentId}`,
          print: `/print/report?type=student&id=${studentId}`,
          filename: `${report.title}.pdf`,
        });
      } catch (error) {
        toast(error.message, "error");
      } finally {
        button.disabled = false;
        button.innerHTML = `${icon("sparkle", 15)} 生成报告`;
      }
    });
  }

  async function generateStudentReport(studentId) {
    try {
      toast("AI 正在汇总该生学情…", "ok", 1800);
      const report = await api(`/api/counselor/reports/student/${studentId}`, { method: "POST", body: {} });
      openReportModal(report, {
        download: `/api/counselor/export/report.pdf?type=student&id=${studentId}`,
        print: `/print/report?type=student&id=${studentId}`,
        filename: `${report.title}.pdf`,
      });
    } catch (error) {
      toast(error.message, "error");
    }
  }

  async function generateClassReport() {
    try {
      const classId = state.dash.classId;
      toast("AI 正在汇总班级学情…", "ok", 1800);
      const report = await api("/api/counselor/reports/class", {
        method: "POST",
        body: { class_id: classId ? Number(classId) : null, days: state.dash.days },
      });
      openReportModal(report, {
        download: `/api/counselor/export/report.pdf?type=class&class_id=${classId}&days=${state.dash.days}`,
        print: `/print/report?type=class&class_id=${classId}&days=${state.dash.days}`,
        filename: `${report.title}.pdf`,
      });
    } catch (error) {
      toast(error.message, "error");
    }
  }

  function reportSheetHTML(report) {
    const info = (report.info || []).map((item) =>
      `<div><label>${esc(item.label)}</label><b>${esc(item.value)}</b></div>`).join("");
    const metrics = (report.metrics || []).map((item) =>
      `<div class="report-metric"><span>${esc(item.label)}</span><b>${esc(item.value)}<em>${esc(item.unit || "")}</em></b></div>`).join("");
    const sections = (report.sections || []).map((section) => {
      const paragraphs = (section.paragraphs || []).map((text) => `<p>${esc(text)}</p>`).join("");
      const bullets = section.bullets && section.bullets.length
        ? `<ul>${section.bullets.map((text) => `<li>${esc(text)}</li>`).join("")}</ul>` : "";
      const table = section.table
        ? `<table><thead><tr>${section.table.headers.map((cell) => `<th>${esc(cell)}</th>`).join("")}</tr></thead><tbody>${section.table.rows.map((row) => `<tr>${row.map((cell) => `<td>${esc(cell)}</td>`).join("")}</tr>`).join("")}</tbody></table>` : "";
      const callout = section.callout ? `<div class="rcallout">${esc(section.callout)}</div>` : "";
      return `<section class="report-sec"><h2>${esc(section.title)}</h2>${paragraphs}${bullets}${table}${callout}</section>`;
    }).join("");
    return `<div class="report-sheet">
      <div class="report-brandbar">
        <div><b>智学 · AI 学情与学工平台</b><small>ZHIXUE ACADEMIC INTELLIGENCE</small></div>
        <div class="meta">报告编号：${esc(report.code)}<br>生成时间：${esc(fmtDate(report.generated_at))}<br>生成方式：AI 自动生成</div>
      </div>
      <h1>${esc(report.title)}</h1>
      <div class="r-sub">${esc(report.subtitle || "")}</div>
      <div class="report-info">${info}</div>
      <div class="report-metrics">${metrics}</div>
      ${sections}
      <div class="report-sign"><div>辅导员签字：<span></span></div><div>日期：<span></span></div></div>
      <div class="report-foot"><span>本报告由智学平台 AI 依据真实问诊记录自动生成，数据可在“数据留痕”中校验。</span><span class="fingerprint">SHA-256 ${esc((report.hash || "").slice(0, 32))}…</span></div>
    </div>`;
  }

  function openReportModal(report, actions = {}) {
    openModal(`<div class="modal-card report-modal">
      <div class="report-toolbar">
        <div class="rt-title">${icon("file", 15)} ${esc(report.code)} · 已自动归档</div>
        <div class="rt-actions">
          ${actions.print ? `<button class="btn sm" data-print-report>${icon("printer", 14)} 打印</button>` : ""}
          ${actions.download ? `<button class="btn sm primary" data-download-report>${icon("download", 14)} 下载 PDF</button>` : ""}
          <button class="modal-close" data-close style="margin-left:4px">${icon("x", 16)}</button>
        </div>
      </div>
      ${reportSheetHTML(report)}
    </div>`);
    const printBtn = modalRoot.querySelector("[data-print-report]");
    if (printBtn) printBtn.addEventListener("click", () => window.open(actions.print, "_blank"));
    const downloadBtn = modalRoot.querySelector("[data-download-report]");
    if (downloadBtn) downloadBtn.addEventListener("click", () => {
      downloadFile(actions.download, actions.filename || `${report.title}.pdf`, actions.print);
    });
  }

  /* =======================================================================
     Counselor · Ledgers
     ======================================================================= */
  async function pageLedgers() {
    const focusId = document.activeElement && document.activeElement.id;
    const caret = focusId ? document.activeElement.selectionStart : null;
    const filters = state.ledgerFilters;
    const query = buildQuery({
      q: filters.q, intent: filters.intent, status: filters.status,
      course: filters.course, from: filters.from, to: filters.to,
      page: filters.page, page_size: filters.page_size,
    });
    const data = await api(`/api/counselor/ledgers${query}`);
    const summary = data.summary;
    const view = document.getElementById("view");
    const courseOptions = (state.meta.courses || []).map((course) =>
      `<option value="${esc(course)}" ${filters.course === course ? "selected" : ""}>${esc(course)}</option>`).join("");
    const intentOptions = (state.meta.intents || []).map((intent) =>
      `<option value="${esc(intent)}" ${filters.intent === intent ? "selected" : ""}>${esc(intent)}</option>`).join("");
    view.innerHTML = `
      <div class="page fade-up">
        <div class="page-head">
          <div><div class="eyebrow">STUDENT AFFAIRS LEDGER</div><h1>学工台账</h1><p class="lead">每一条台账由 AI 在问诊结束时自动生成，含学生问题、诊断结论、帮扶资源与建议，正文不可修改。</p></div>
          <div class="page-head-actions">
            <button class="btn" id="export-xlsx">${icon("download", 15)} 导出 Excel</button>
            <button class="btn primary" id="export-pdf">${icon("printer", 15)} 导出 PDF</button>
          </div>
        </div>

        <div class="status-tabs" id="ledger-status-tabs">
          ${[["", "全部台账", summary.total], ["待跟进", "待跟进", summary.pending], ["跟进中", "跟进中", summary.following], ["已闭环", "已闭环", summary.closed]].map(([value, label, count]) =>
            `<button class="status-tab ${filters.status === value ? "active" : ""}" data-status="${value}">${label} <b>${count}</b></button>`).join("")}
          <span class="ledger-count">共 ${summary.total} 条 · 涉及 ${summary.students} 名学生</span>
        </div>

        <div class="ledger-toolbar">
          <div class="search-box">${icon("search", 16)}<input id="ledger-search" value="${esc(filters.q)}" placeholder="搜索学生姓名、学号、台账编号或问题内容" /></div>
        </div>
        <div class="filter-panel">
          <span class="date-label">筛选</span>
          <select class="select" id="ledger-intent"><option value="">全部类型</option>${intentOptions}</select>
          <select class="select" id="ledger-course"><option value="">全部课程</option>${courseOptions}</select>
          <input class="input" type="date" id="ledger-from" value="${esc(filters.from)}" title="开始日期" />
          <span class="date-label">至</span>
          <input class="input" type="date" id="ledger-to" value="${esc(filters.to)}" title="结束日期" />
          <button class="btn sm" id="ledger-reset">${icon("refresh", 13)} 重置</button>
          <span class="ledger-count">当前筛选 ${data.total} 条</span>
        </div>

        <div class="table-wrap">
          <table class="data">
            <thead><tr><th>台账编号</th><th>学生</th><th>问题类型</th><th>掌握度</th><th>状态</th><th>学生问题</th><th>帮扶时间</th></tr></thead>
            <tbody>${data.items.length ? data.items.map(ledgerRowHTML).join("") : `<tr><td colspan="7">${emptyHTML("没有匹配的台账", "调整筛选条件后重试")}</td></tr>`}</tbody>
          </table>
        </div>
        <p class="mobile-hint">${icon("chevronRight", 12)} 左右滑动查看完整台账</p>
        <div class="pagination">
          <span class="count">第 ${data.page} / ${data.pages} 页 · 共 ${data.total} 条</span>
          <div class="pages">
            <button class="page-btn" data-page="${data.page - 1}" ${data.page <= 1 ? "disabled" : ""}>${icon("arrowLeft", 13)}</button>
            ${pageNumbers(data.page, data.pages).map((value) => value === "…"
              ? `<span class="page-btn" style="border:0">…</span>`
              : `<button class="page-btn ${value === data.page ? "active" : ""}" data-page="${value}">${value}</button>`).join("")}
            <button class="page-btn" data-page="${data.page + 1}" ${data.page >= data.pages ? "disabled" : ""}>${icon("arrowRight", 13)}</button>
          </div>
        </div>
      </div>`;

    const reload = () => pageLedgers().catch(showPageError);
    view.querySelectorAll("[data-ledger]").forEach((row) => {
      row.addEventListener("click", () => openLedger(Number(row.dataset.ledger)));
    });
    document.getElementById("ledger-status-tabs").addEventListener("click", (event) => {
      const tab = event.target.closest("[data-status]");
      if (!tab) return;
      state.ledgerFilters.status = tab.dataset.status;
      state.ledgerFilters.page = 1;
      reload();
    });
    let searchTimer = null;
    document.getElementById("ledger-search").addEventListener("input", (event) => {
      state.ledgerFilters.q = event.target.value.trim();
      state.ledgerFilters.page = 1;
      clearTimeout(searchTimer);
      searchTimer = setTimeout(reload, 280);
    });
    document.getElementById("ledger-intent").addEventListener("change", (event) => {
      state.ledgerFilters.intent = event.target.value;
      state.ledgerFilters.page = 1;
      reload();
    });
    document.getElementById("ledger-course").addEventListener("change", (event) => {
      state.ledgerFilters.course = event.target.value;
      state.ledgerFilters.page = 1;
      reload();
    });
    document.getElementById("ledger-from").addEventListener("change", (event) => {
      state.ledgerFilters.from = event.target.value;
      state.ledgerFilters.page = 1;
      reload();
    });
    document.getElementById("ledger-to").addEventListener("change", (event) => {
      state.ledgerFilters.to = event.target.value;
      state.ledgerFilters.page = 1;
      reload();
    });
    document.getElementById("ledger-reset").addEventListener("click", () => {
      state.ledgerFilters = { q: "", intent: "", status: "", course: "", from: "", to: "", page: 1, page_size: 10 };
      reload();
    });
    view.querySelectorAll("[data-page]").forEach((button) => {
      button.addEventListener("click", () => {
        const page = Number(button.dataset.page);
        if (page >= 1) {
          state.ledgerFilters.page = page;
          reload();
        }
      });
    });
    const exportQuery = buildQuery({
      q: filters.q, intent: filters.intent, status: filters.status,
      course: filters.course, from: filters.from, to: filters.to,
      class_id: filters.class_id || "",
    });
    document.getElementById("export-xlsx").addEventListener("click", () => {
      downloadFile(`/api/counselor/export/ledgers.xlsx${exportQuery}`, "智学_学工台账.xlsx", `/print/ledgers${exportQuery}`);
    });
    document.getElementById("export-pdf").addEventListener("click", () => {
      downloadFile(`/api/counselor/export/ledgers.pdf${exportQuery}`, "智学_学工台账.pdf", `/print/ledgers${exportQuery}`);
    });
    if (focusId === "ledger-search") {
      const input = document.getElementById("ledger-search");
      if (input) {
        input.focus();
        if (caret !== null && input.setSelectionRange) input.setSelectionRange(caret, caret);
      }
    }
  }

  function pageNumbers(current, total) {
    if (total <= 7) return Array.from({ length: total }, (_, index) => index + 1);
    const pages = new Set([1, total, current, current - 1, current + 1]);
    const list = Array.from(pages).filter((value) => value >= 1 && value <= total).sort((a, b) => a - b);
    const result = [];
    list.forEach((value, index) => {
      if (index > 0 && value - list[index - 1] > 1) result.push("…");
      result.push(value);
    });
    return result;
  }

  async function openLedger(id) {
    try {
      const data = await api(`/api/counselor/ledgers/${id}`);
      const item = data.ledger;
      const diagnosis = data.diagnosis;
      openModal(`<div class="modal-card ledger-modal">
        <div class="modal-head">
          <div class="lc-head" style="color:#4f46e5">${icon("archive", 20)}</div>
          <div><h2>学工台账 · <span class="mono">${esc(item.code)}</span></h2><div class="modal-sub">AI 自动生成 · ${esc(item.help_text)}</div></div>
          <div style="margin-left:auto">${statusBadge(item.status)}</div>
          <button class="modal-close" data-close style="margin-left:8px">${icon("x", 16)}</button>
        </div>
        <div class="ledger-doc">
          <div class="ledger-meta">
            <div><label>学生</label><b>${esc(item.student_name)}</b></div>
            <div><label>学号</label><b>${esc(item.student_no)}</b></div>
            <div><label>班级</label><b>${esc(item.class_name)}</b></div>
            <div><label>课程</label><b>${esc(item.course)}</b></div>
            <div><label>问题类型</label><b>${esc(item.intent)}</b></div>
            <div><label>掌握度</label><b>${item.mastery}/100</b></div>
            <div><label>难度</label><b>${esc(item.difficulty)}</b></div>
            <div><label>帮扶时间</label><b>${esc(item.help_text)}</b></div>
          </div>
          <div class="ledger-block"><h3>${icon("chat", 12)} 学生原始问题</h3><blockquote>${esc(item.problem)}</blockquote></div>
          <div class="ledger-block"><h3>${icon("sparkle", 12)} AI 诊断结论</h3><p>${esc(item.diagnosis_summary)}</p></div>
          <div class="ledger-block"><h3>${icon("target", 12)} 薄弱知识点</h3><div class="tag-row">${item.weak_point_names.map((name) => `<span class="tag primary">${esc(name)}</span>`).join("") || `<span class="tag">—</span>`}</div></div>
          <div class="ledger-block"><h3>${icon("book", 12)} 帮扶资源</h3><p>${esc(item.resource_summary)}</p></div>
          <div class="ledger-block"><h3>${icon("info", 12)} AI 帮扶建议</h3><p>${esc(item.suggestion)}</p></div>
          <div class="ledger-block"><h3>${icon("shield", 12)} 数据指纹与完整性</h3>
            <div class="hash-block">
              <span>SHA-256</span><span class="mono">${esc(item.hash)}</span>
              ${item.integrity ? `<span class="badge green" style="margin-left:auto">${icon("checkCircle", 11)} 链校验通过</span>` : `<span class="badge rose" style="margin-left:auto">校验异常</span>`}
            </div>
            <p class="small faint" style="margin-top:6px">前序哈希：<span class="mono">${esc(item.prev_hash)}</span> · 问诊编号 ${esc(diagnosis.public_id)}</p>
          </div>
        </div>
        <div class="followup-box">
          <h3>${icon("edit", 13)} 跟进记录 <span class="badge gray">仅状态与跟进可修改，正文永久锁定</span></h3>
          <div class="followup-grid">
            <select class="select" id="followup-status">
              ${["待跟进", "跟进中", "已闭环"].map((status) => `<option value="${status}" ${item.status === status ? "selected" : ""}>${status}</option>`).join("")}
            </select>
            <textarea class="textarea" id="followup-text" maxlength="600" placeholder="记录谈话、资源学习或复测结果…">${esc(item.follow_up)}</textarea>
          </div>
          <div class="followup-actions">
            <span class="char-count" id="followup-count">${(item.follow_up || "").length} / 600</span>
            <div class="flex gap-8">
              <button class="btn sm" data-close>取消</button>
              <button class="btn sm primary" id="save-followup">${icon("check", 14)} 保存跟进</button>
            </div>
          </div>
        </div>
      </div>`);

      const textarea = document.getElementById("followup-text");
      const counter = document.getElementById("followup-count");
      textarea.addEventListener("input", () => { counter.textContent = `${textarea.value.length} / 600`; });
      document.getElementById("save-followup").addEventListener("click", async (event) => {
        const button = event.currentTarget;
        button.disabled = true;
        button.innerHTML = `<span class="spinner"></span> 保存中…`;
        try {
          await api(`/api/counselor/ledgers/${id}`, {
            method: "PATCH",
            body: {
              status: document.getElementById("followup-status").value,
              follow_up: textarea.value,
            },
          });
          closeModal();
          toast("台账跟进已保存，操作已写入审计留痕", "ok");
          renderRoute();
        } catch (error) {
          toast(error.message, "error");
          button.disabled = false;
          button.innerHTML = `${icon("check", 14)} 保存跟进`;
        }
      });
    } catch (error) {
      toast(error.message, "error");
    }
  }

  /* =======================================================================
     Counselor · Audit
     ======================================================================= */
  async function pageAudit() {
    const data = await api("/api/counselor/audit");
    const view = document.getElementById("view");
    const ledgerOk = data.ledger_chain.valid;
    const auditOk = data.audit_chain.valid;
    view.innerHTML = `
      <div class="page fade-up">
        <div class="audit-hero">
          <div class="ah-icon">${icon("shield", 27)}</div>
          <div class="ah-body">
            <div class="eyebrow">IMMUTABLE AUDIT TRAIL</div>
            <h1>数据留痕与归档</h1>
            <p>诊断正文、台账正文与审计日志均写入 SHA-256 哈希链，数据库触发器阻止任何修改与删除。${ledgerOk && auditOk ? "当前全部链路校验通过。" : "当前存在校验异常，请立即核查。"}</p>
          </div>
          <div class="ah-actions">
            <button class="btn" id="verify-btn">${icon("shield", 15)} 立即校验完整性</button>
            <button class="btn" id="audit-export">${icon("download", 15)} 导出台账归档</button>
          </div>
        </div>

        <div id="verify-result"></div>

        <div class="chain-grid">
          <section class="card chain-card">
            <div class="chain-top"><h3>${icon("archive", 16)} 学工台账哈希链</h3>${ledgerOk ? `<span class="badge green">${icon("checkCircle", 11)} 完整</span>` : `<span class="badge rose">校验失败</span>`}</div>
            <div class="chain-visual">
              <div class="chain-node"><b>${data.stats.ledgers ? "XG-…001" : "GENESIS"}</b><span>创世块</span></div>
              <div class="chain-link"></div>
              <div class="chain-node"><b>${esc((data.ledger_chain.last_hash || "").slice(0, 12) || "—")}</b><span>${esc(data.ledger_chain.last_code || "最新区块")}</span></div>
            </div>
            <div class="chain-stats">
              <div><b>${data.ledger_chain.checked}</b>已校验台账</div>
              <div><b>${data.stats.ledgers}</b>台账总数</div>
              <div><b>${data.stats.reports}</b>归档报告</div>
              <div><b>${data.stats.audit_events}</b>审计事件</div>
            </div>
            <p class="small muted mt-8">${esc(data.ledger_chain.message)}</p>
          </section>
          <section class="card chain-card">
            <div class="chain-top"><h3>${icon("activity", 16)} 审计日志哈希链</h3>${auditOk ? `<span class="badge green">${icon("checkCircle", 11)} 完整</span>` : `<span class="badge rose">校验失败</span>`}</div>
            <div class="chain-visual">
              <div class="chain-node"><b>GENESIS</b><span>创世块</span></div>
              <div class="chain-link"></div>
              <div class="chain-node"><b>${esc((data.audit_chain.last_hash || "").slice(0, 12) || "—")}</b><span>最新区块</span></div>
            </div>
            <div class="chain-stats">
              <div><b>${data.audit_chain.checked}</b>已校验记录</div>
              <div><b>${data.audit_chain.total}</b>日志总数</div>
              <div><b>${esc(fmtDate(data.stats.last_ledger, false))}</b>最近台账</div>
              <div><b>${esc(fmtDate(data.stats.first_ledger, false))}</b>最早台账</div>
            </div>
            <p class="small muted mt-8">${esc(data.audit_chain.message)}</p>
          </section>
        </div>

        <div class="policy-grid">
          ${data.policies.map((item, index) => `<div class="policy-card">
            <div class="pi">${icon(["lock", "layers", "eye", "archive"][index % 4], 16)}</div>
            <b>${esc(item.title)}</b><p>${esc(item.desc)}</p>
          </div>`).join("")}
        </div>

        <div class="audit-grid">
          <section class="card chart-card">
            <div class="chart-head"><div><h3>审计日志</h3><p>登录、问诊、台账、报告、导出全量记录</p></div><span class="badge gray">最近 ${data.logs.length} 条</span></div>
            <div class="table-wrap">
              <table class="data log-table">
                <thead><tr><th>时间</th><th>操作人</th><th>动作</th><th>对象</th><th>详情</th><th>指纹</th></tr></thead>
                <tbody>${data.logs.map((log) => `<tr>
                  <td class="small" style="white-space:nowrap">${esc(log.at_text)}</td>
                  <td><b class="strong">${esc(log.actor)}</b></td>
                  <td><span class="log-action">${esc(log.action)}</span></td>
                  <td class="mono small">${esc(log.target)}</td>
                  <td class="small">${esc(log.detail)}</td>
                  <td class="log-hash">${esc(log.hash_short)}</td>
                </tr>`).join("")}</tbody>
              </table>
            </div>
          </section>
          <aside class="side-stack">
            <section class="card chart-card">
              <div class="chart-head"><div><h3>近期归档报告</h3></div><span class="badge gray">${data.stats.reports} 份</span></div>
              <div class="report-list">
                ${data.recent_reports.length ? data.recent_reports.map((item) => `<div class="report-row">
                  <span class="rp-icon">${icon(item.type === "class" ? "users" : "user", 14)}</span>
                  <div class="rp-body"><b>${esc(item.title)}</b><span>${esc(item.code)} · ${esc(item.generated_at)}</span></div>
                </div>`).join("") : emptyHTML("暂无归档报告")}
              </div>
            </section>
            <section class="tip-card">
              <div class="eyebrow">COMPLIANCE</div>
              <h4>符合高校学工存档要求</h4>
              <p>台账覆盖学生问题、诊断结果、帮扶资源、帮扶时间与跟进状态，支持 XLSX / PDF 导出，可直接用于学院报备与年度归档。</p>
              <div class="tip-foot">所有导出操作同样写入审计日志</div>
            </section>
          </aside>
        </div>
      </div>`;

    document.getElementById("verify-btn").addEventListener("click", async (event) => {
      const button = event.currentTarget;
      button.disabled = true;
      button.innerHTML = `<span class="spinner"></span> 校验中…`;
      try {
        const result = await api("/api/counselor/audit/verify", { method: "POST", body: {} });
        const box = document.getElementById("verify-result");
        box.innerHTML = `<div class="verify-banner ${result.ok ? "ok" : "bad"}">
          ${icon(result.ok ? "checkCircle" : "alert", 20)}
          <div><b>${result.ok ? "完整性校验通过" : "发现哈希链异常"}</b><div class="small">台账链：${esc(result.ledger.message)}；审计链：${esc(result.audit.message)} · ${esc(result.checked_at)}</div></div>
        </div>`;
        toast(result.ok ? "台账与审计链完整，数据未被篡改" : "校验失败，请核查异常记录", result.ok ? "ok" : "error", 5000);
      } catch (error) {
        toast(error.message, "error");
      } finally {
        button.disabled = false;
        button.innerHTML = `${icon("shield", 15)} 立即校验完整性`;
      }
    });
    document.getElementById("audit-export").addEventListener("click", () => {
      downloadFile("/api/counselor/export/ledgers.xlsx", "智学_学工台账归档.xlsx", "/print/ledgers");
    });
  }

  /* =======================================================================
     Global events & boot
     ======================================================================= */
  document.addEventListener("click", (event) => {
    if (event.target === modalRoot) closeModal();
    if (event.target.closest("[data-close]")) closeModal();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeModal();
      document.body.classList.remove("nav-open");
    }
  });
  window.addEventListener("hashchange", renderRoute);

  async function init() {
    try {
      const session = await api("/api/session");
      if (session.authenticated) {
        state.user = session.user;
        state.csrf = session.csrf;
        await startApp();
      } else {
        renderLogin();
      }
    } catch (error) {
      renderLogin("无法连接服务：请确认启动窗口仍在运行，然后刷新页面。");
    }
  }

  init();
})();
