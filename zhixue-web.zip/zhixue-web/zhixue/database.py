"""SQLite 数据层：表结构、连接、哈希链与启动初始化。

数据设计原则
------------
1. 诊断结果、台账正文、审计日志均为 append-only：数据库触发器阻止 UPDATE/DELETE，
   形成“可追溯、不可篡改”的学工档案。
2. 台账与审计日志各自维护 SHA-256 哈希链，任何一条记录被改动都会在校验时暴露。
3. 全部字段使用 UTF-8 文本保存，便于直接归档与导出。
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Iterator

from . import config

GENESIS_HASH = "0" * 64
_DB_LOCK = threading.RLock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS schema_meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS classes (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL UNIQUE,
    grade        TEXT NOT NULL,
    major        TEXT NOT NULL,
    counselor_id INTEGER,
    created_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN ('student', 'counselor')),
    name          TEXT NOT NULL,
    student_no    TEXT NOT NULL DEFAULT '',
    class_id      INTEGER REFERENCES classes(id) ON DELETE SET NULL,
    major         TEXT NOT NULL DEFAULT '',
    email         TEXT NOT NULL DEFAULT '',
    phone         TEXT NOT NULL DEFAULT '',
    tags          TEXT NOT NULL DEFAULT '[]',
    created_at    TEXT NOT NULL,
    last_login_at TEXT
);

CREATE TABLE IF NOT EXISTS knowledge_points (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    course      TEXT NOT NULL,
    name        TEXT NOT NULL,
    chapter     TEXT NOT NULL DEFAULT '',
    difficulty  INTEGER NOT NULL DEFAULT 3,
    keywords    TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    pitfall     TEXT NOT NULL DEFAULT '',
    UNIQUE (course, name)
);

CREATE TABLE IF NOT EXISTS resources (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    title      TEXT NOT NULL,
    type       TEXT NOT NULL,
    course     TEXT NOT NULL,
    kp_ids     TEXT NOT NULL DEFAULT '[]',
    level      TEXT NOT NULL DEFAULT '基础',
    minutes    INTEGER NOT NULL DEFAULT 15,
    summary    TEXT NOT NULL DEFAULT '',
    content    TEXT NOT NULL DEFAULT '',
    source     TEXT NOT NULL DEFAULT '校本知识库',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS diagnoses (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id         TEXT NOT NULL UNIQUE,
    student_id        INTEGER NOT NULL REFERENCES users(id),
    class_id          INTEGER NOT NULL REFERENCES classes(id),
    question          TEXT NOT NULL,
    course            TEXT NOT NULL,
    intent            TEXT NOT NULL,
    intent_confidence REAL NOT NULL DEFAULT 0,
    difficulty        TEXT NOT NULL,
    mastery           INTEGER NOT NULL,
    weak_points       TEXT NOT NULL DEFAULT '[]',
    misconceptions    TEXT NOT NULL DEFAULT '[]',
    ability_gaps      TEXT NOT NULL DEFAULT '[]',
    tags              TEXT NOT NULL DEFAULT '[]',
    summary           TEXT NOT NULL DEFAULT '',
    structured        TEXT NOT NULL DEFAULT '{}',
    ai_mode           TEXT NOT NULL DEFAULT 'local',
    duration_ms       INTEGER NOT NULL DEFAULT 0,
    created_at        TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS recommendations (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    diagnosis_id INTEGER NOT NULL REFERENCES diagnoses(id) ON DELETE CASCADE,
    resource_id  INTEGER NOT NULL REFERENCES resources(id),
    reason       TEXT NOT NULL DEFAULT '',
    relevance    REAL NOT NULL DEFAULT 0,
    sort_order   INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS learning_records (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id   INTEGER NOT NULL REFERENCES users(id),
    resource_id  INTEGER NOT NULL REFERENCES resources(id),
    diagnosis_id INTEGER REFERENCES diagnoses(id),
    status       TEXT NOT NULL DEFAULT 'opened' CHECK (status IN ('opened', 'completed')),
    created_at   TEXT NOT NULL,
    completed_at TEXT
);

CREATE TABLE IF NOT EXISTS ledgers (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    code              TEXT NOT NULL UNIQUE,
    seq               INTEGER NOT NULL,
    diagnosis_id      INTEGER NOT NULL UNIQUE REFERENCES diagnoses(id),
    student_id        INTEGER NOT NULL REFERENCES users(id),
    class_id          INTEGER NOT NULL REFERENCES classes(id),
    counselor_id      INTEGER,
    problem           TEXT NOT NULL,
    diagnosis_summary TEXT NOT NULL,
    weak_points       TEXT NOT NULL DEFAULT '[]',
    resource_summary  TEXT NOT NULL DEFAULT '',
    help_time         TEXT NOT NULL,
    status            TEXT NOT NULL DEFAULT '待跟进'
                      CHECK (status IN ('待跟进', '跟进中', '已闭环')),
    follow_up         TEXT NOT NULL DEFAULT '',
    suggestion        TEXT NOT NULL DEFAULT '',
    created_at        TEXT NOT NULL,
    updated_at        TEXT NOT NULL,
    hash              TEXT NOT NULL,
    prev_hash         TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    at       TEXT NOT NULL,
    actor    TEXT NOT NULL,
    actor_id INTEGER,
    action   TEXT NOT NULL,
    target   TEXT NOT NULL DEFAULT '',
    detail   TEXT NOT NULL DEFAULT '',
    hash     TEXT NOT NULL,
    prev_hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reports (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    code         TEXT NOT NULL UNIQUE,
    type         TEXT NOT NULL CHECK (type IN ('student', 'class')),
    target_id    INTEGER NOT NULL,
    title        TEXT NOT NULL,
    content      TEXT NOT NULL,
    generated_at TEXT NOT NULL,
    hash         TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    csrf_token TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_users_class ON users(class_id);
CREATE INDEX IF NOT EXISTS idx_diagnoses_student ON diagnoses(student_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_diagnoses_class ON diagnoses(class_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_diagnoses_intent ON diagnoses(intent);
CREATE INDEX IF NOT EXISTS idx_recommendations_diag ON recommendations(diagnosis_id);
CREATE INDEX IF NOT EXISTS idx_learning_student ON learning_records(student_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ledgers_student ON ledgers(student_id, help_time DESC);
CREATE INDEX IF NOT EXISTS idx_ledgers_status ON ledgers(status, help_time DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

-- 不可篡改：诊断、台账正文、审计日志、归档报告禁止删除。
CREATE TRIGGER IF NOT EXISTS trg_diagnoses_no_delete
BEFORE DELETE ON diagnoses
BEGIN SELECT RAISE(ABORT, '学情诊断记录不可删除'); END;

CREATE TRIGGER IF NOT EXISTS trg_diagnoses_no_update
BEFORE UPDATE ON diagnoses
BEGIN SELECT RAISE(ABORT, '学情诊断记录不可修改'); END;

CREATE TRIGGER IF NOT EXISTS trg_ledgers_no_delete
BEFORE DELETE ON ledgers
BEGIN SELECT RAISE(ABORT, '学工台账不可删除'); END;

CREATE TRIGGER IF NOT EXISTS trg_ledgers_immutable
BEFORE UPDATE OF code, seq, diagnosis_id, student_id, class_id, problem,
    diagnosis_summary, weak_points, resource_summary, help_time, created_at, hash, prev_hash
ON ledgers
BEGIN SELECT RAISE(ABORT, '学工台账正文不可修改'); END;

CREATE TRIGGER IF NOT EXISTS trg_audit_no_delete
BEFORE DELETE ON audit_logs
BEGIN SELECT RAISE(ABORT, '审计留痕不可删除'); END;

CREATE TRIGGER IF NOT EXISTS trg_audit_no_update
BEFORE UPDATE ON audit_logs
BEGIN SELECT RAISE(ABORT, '审计留痕不可修改'); END;

CREATE TRIGGER IF NOT EXISTS trg_reports_no_delete
BEFORE DELETE ON reports
BEGIN SELECT RAISE(ABORT, '归档报告不可删除'); END;
"""


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def to_iso(moment: datetime) -> str:
    if moment.tzinfo is None:
        moment = moment.astimezone()
    return moment.isoformat(timespec="seconds")


def parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.astimezone()
    return parsed


@contextmanager
def db() -> Iterator[sqlite3.Connection]:
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    config.TMP_DIR.mkdir(parents=True, exist_ok=True)
    # ThreadingHTTPServer 会并发处理请求。串行化本进程的数据访问，
    # 防止日报编号、哈希链和会话写入在公网并发时互相覆盖。
    with _DB_LOCK:
        connection = sqlite3.connect(config.DB_PATH, timeout=20)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()


def init_db() -> None:
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    config.TMP_DIR.mkdir(parents=True, exist_ok=True)
    with db() as connection:
        connection.executescript(SCHEMA)
        connection.execute("PRAGMA journal_mode = WAL")
        connection.execute(
            "INSERT OR IGNORE INTO schema_meta(key, value) VALUES ('schema_version', '3')"
        )


def row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row is not None else None


def json_load(value: str | None, fallback: Any) -> Any:
    try:
        return json.loads(value) if value else fallback
    except (TypeError, ValueError):
        return fallback


def canonical_json(payload: Any) -> str:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def chain_hash(prev_hash: str, payload: Any) -> str:
    material = prev_hash + "|" + canonical_json(payload)
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def short_hash(value: str, length: int = 12) -> str:
    return (value or "")[:length]


def append_audit(
    connection: sqlite3.Connection,
    *,
    actor: str,
    actor_id: int | None,
    action: str,
    target: str = "",
    detail: str = "",
    at: str | None = None,
) -> str:
    """写入一条哈希链审计记录，返回本条哈希。"""
    at = at or now_iso()
    previous = connection.execute(
        "SELECT hash FROM audit_logs ORDER BY id DESC LIMIT 1"
    ).fetchone()
    prev_hash = previous["hash"] if previous else GENESIS_HASH
    payload = {
        "at": at,
        "actor": actor,
        "actor_id": actor_id,
        "action": action,
        "target": target,
        "detail": detail,
    }
    digest = chain_hash(prev_hash, payload)
    connection.execute(
        """INSERT INTO audit_logs(at, actor, actor_id, action, target, detail, hash, prev_hash)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (at, actor, actor_id, action, target, detail, digest, prev_hash),
    )
    return digest


def next_sequence(connection: sqlite3.Connection, table: str, column: str = "id") -> int:
    row = connection.execute(f"SELECT COALESCE(MAX({column}), 0) AS n FROM {table}").fetchone()
    return int(row["n"]) + 1


def daily_sequence(connection: sqlite3.Connection, table: str, prefix: str, day: str) -> int:
    row = connection.execute(
        f"SELECT COUNT(*) AS n FROM {table} WHERE substr(created_at, 1, 10) = ?", (day,)
    ).fetchone()
    return int(row["n"]) + 1


def seed_demo() -> bool:
    """首次启动写入完整演示数据；已有用户时直接返回 False。"""
    init_db()
    with db() as connection:
        count = connection.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]
        if count:
            return False
    from . import services

    services.seed_demo_data()
    return True


def data_size() -> int:
    path: Path = config.DB_PATH
    return path.stat().st_size if path.exists() else 0
