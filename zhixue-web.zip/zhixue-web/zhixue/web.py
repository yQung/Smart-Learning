"""HTTP 服务：安全会话、JSON API、单页应用与文件导出。"""
from __future__ import annotations

import hmac
import json
import os
import re
import sys
import traceback
import urllib.parse
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from . import config, exports, services
from .errors import AppError, bad_request, forbidden, not_found, unauthorized

STATIC_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".ico": "image/x-icon",
    ".woff2": "font/woff2",
    ".txt": "text/plain; charset=utf-8",
}

CSP = (
    "default-src 'self'; "
    "script-src 'self'; "
    "style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data: blob:; "
    "font-src 'self' data:; "
    "connect-src 'self'; "
    "frame-ancestors 'none'; "
    "base-uri 'self'; "
    "form-action 'self'"
)

PAGES = {"/": "index.html", "/index.html": "index.html"}


def _safe_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _attachment(name: str, fallback: str) -> str:
    quoted = urllib.parse.quote(name)
    return f"attachment; filename=\"{fallback}\"; filename*=UTF-8''{quoted}"


class ZhixueHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = f"Zhixue/{config.APP_VERSION}"

    # ------------------------------------------------------------------
    # HTTP 入口
    # ------------------------------------------------------------------
    def do_GET(self) -> None:  # noqa: N802
        self._dispatch("GET")

    def do_POST(self) -> None:  # noqa: N802
        self._dispatch("POST")

    def do_PATCH(self) -> None:  # noqa: N802
        self._dispatch("PATCH")

    def do_DELETE(self) -> None:  # noqa: N802
        self._dispatch("DELETE")

    def do_HEAD(self) -> None:  # noqa: N802
        self._dispatch("HEAD")

    def do_OPTIONS(self) -> None:  # noqa: N802
        self._send_json(405, {"error": {"code": "METHOD_NOT_ALLOWED", "message": "不支持该请求方法"}})

    def _dispatch(self, method: str) -> None:
        self._pending_cookie = None
        self._json_cache = None
        parsed = urllib.parse.urlsplit(self.path)
        try:
            path = urllib.parse.unquote(parsed.path)
            query = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
            if path.startswith("/api/"):
                self._handle_api(method, path, query)
            elif path.startswith("/print/"):
                if method not in {"GET", "HEAD"}:
                    raise AppError(405, "METHOD_NOT_ALLOWED", "不支持该请求方法")
                self._handle_print(path, query, head=(method == "HEAD"))
            elif method in {"GET", "HEAD"}:
                self._serve_static(path, head=(method == "HEAD"))
            else:
                raise AppError(405, "METHOD_NOT_ALLOWED", "不支持该请求方法")
        except AppError as exc:
            self._send_json(
                exc.status,
                {"error": {"code": exc.code, "message": exc.message}},
                head=(method == "HEAD"),
            )
        except (BrokenPipeError, ConnectionResetError):
            return
        except Exception:
            traceback.print_exc()
            self._send_json(
                500,
                {"error": {"code": "INTERNAL_ERROR", "message": "服务器处理请求时出错，请稍后重试"}},
                head=(method == "HEAD"),
            )

    # ------------------------------------------------------------------
    # API
    # ------------------------------------------------------------------
    def _handle_api(self, method: str, path: str, query: dict[str, list[str]]) -> None:
        # 先把请求体读完，避免 keep-alive 连接上残留 JSON 污染下一个请求。
        if method in {"POST", "PATCH", "DELETE"}:
            self._read_json()
        if path == "/api/health" and method == "GET":
            self._send_json(200, {
                "ok": True,
                "app": config.APP_NAME,
                "version": config.APP_VERSION,
                "time": services.database.now_iso(),
            })
            return

        if path == "/api/session" and method == "GET":
            session = self._get_session()
            if not session:
                self._send_json(200, {"authenticated": False, "user": None, "csrf": None})
            else:
                self._send_json(200, {
                    "authenticated": True,
                    "user": session["user"],
                    "csrf": session["csrf"],
                })
            return

        if path == "/api/login" and method == "POST":
            self._check_origin()
            payload = self._read_json()
            token, csrf, user = services.login(
                str(payload.get("username") or ""),
                str(payload.get("password") or ""),
                self.client_address[0],
            )
            self._set_session_cookie(token)
            self._send_json(200, {"ok": True, "user": user, "csrf": csrf})
            return

        if path == "/api/meta" and method == "GET":
            session = self._require_session()
            self._send_json(200, services.meta(session["user"]))
            return

        match = re.fullmatch(r"/api/diagnosis/(\d+)", path)
        if match and method == "GET":
            session = self._require_session()
            self._send_json(200, services.get_diagnosis_detail(session["user"], int(match.group(1))))
            return

        match = re.fullmatch(r"/api/resource/(\d+)", path)
        if match and method == "GET":
            session = self._require_session()
            self._send_json(200, services.get_resource(session["user"], int(match.group(1))))
            return

        if path == "/api/logout" and method == "POST":
            session = self._require_session()
            self._check_mutation(session)
            services.logout(self._session_token())
            self._clear_session_cookie()
            self._send_json(200, {"ok": True})
            return

        # ---------------- 学生端 ----------------
        if path == "/api/student/overview" and method == "GET":
            session = self._require_session("student")
            self._send_json(200, services.student_overview(session["user"]))
            return

        if path == "/api/student/diagnose" and method == "POST":
            session = self._require_session("student")
            self._check_mutation(session)
            payload = self._read_json()
            result = services.create_diagnosis(session["user"], str(payload.get("question") or ""))
            self._send_json(201, result)
            return

        if path == "/api/student/diagnoses" and method == "GET":
            session = self._require_session("student")
            self._send_json(200, services.list_student_diagnoses(session["user"], {
                "course": self._query_one(query, "course", ""),
                "intent": self._query_one(query, "intent", ""),
                "page": self._query_one(query, "page", "1"),
            }))
            return

        match = re.fullmatch(r"/api/student/diagnoses/(\d+)", path)
        if match and method == "GET":
            session = self._require_session("student")
            self._send_json(200, services.get_diagnosis_detail(session["user"], int(match.group(1))))
            return

        if path == "/api/student/resources" and method == "GET":
            session = self._require_session("student")
            self._send_json(200, services.list_resources(session["user"], {
                "course": self._query_one(query, "course", ""),
                "type": self._query_one(query, "type", ""),
                "q": self._query_one(query, "q", ""),
            }))
            return

        match = re.fullmatch(r"/api/student/resources/(\d+)", path)
        if match and method == "GET":
            session = self._require_session("student")
            self._send_json(200, services.get_resource(session["user"], int(match.group(1))))
            return

        match = re.fullmatch(r"/api/student/resources/(\d+)/learn", path)
        if match and method == "POST":
            session = self._require_session("student")
            self._check_mutation(session)
            payload = self._read_json()
            self._send_json(200, services.mark_learning(
                session["user"], int(match.group(1)),
                int(payload["diagnosis_id"]) if payload.get("diagnosis_id") else None,
            ))
            return

        if path == "/api/student/profile" and method == "GET":
            session = self._require_session("student")
            self._send_json(200, services.student_profile(session["user"]))
            return

        if path == "/api/student/report" and method == "GET":
            session = self._require_session("student")
            self._send_json(200, services.build_student_report(session["user"], session["user"]["id"]))
            return

        if path == "/api/student/export/report.pdf" and method == "GET":
            session = self._require_session("student")
            report = services.generate_student_report(session["user"], session["user"]["id"])
            self._send_report_pdf(report, fallback="zhixue-student-report.pdf")
            return

        # ---------------- 辅导员端 ----------------
        if path == "/api/counselor/overview" and method == "GET":
            session = self._require_session("counselor")
            self._send_json(200, services.counselor_overview(
                session["user"],
                int(self._query_one(query, "days", "14")),
                self._query_int(query, "class_id"),
            ))
            return

        if path == "/api/counselor/students" and method == "GET":
            session = self._require_session("counselor")
            self._send_json(200, services.counselor_students(session["user"], {
                "q": self._query_one(query, "q", ""),
                "risk": self._query_one(query, "risk", "all"),
                "status": self._query_one(query, "status", "all"),
                "class_id": self._query_one(query, "class_id", ""),
            }))
            return

        match = re.fullmatch(r"/api/counselor/students/(\d+)", path)
        if match and method == "GET":
            session = self._require_session("counselor")
            self._send_json(200, services.counselor_student_detail(session["user"], int(match.group(1))))
            return

        match = re.fullmatch(r"/api/counselor/students/(\d+)/report", path)
        if match and method == "GET":
            session = self._require_session("counselor")
            self._send_json(200, services.build_student_report(session["user"], int(match.group(1))))
            return

        if path == "/api/counselor/class-report" and method == "GET":
            session = self._require_session("counselor")
            self._send_json(200, services.build_class_report(
                session["user"],
                self._query_int(query, "class_id"),
                int(self._query_one(query, "days", "30")),
            ))
            return

        if path == "/api/counselor/ledgers" and method == "GET":
            session = self._require_session("counselor")
            self._send_json(200, services.list_ledgers(session["user"], self._ledger_filters(query)))
            return

        match = re.fullmatch(r"/api/counselor/ledgers/(\d+)", path)
        if match and method == "GET":
            session = self._require_session("counselor")
            self._send_json(200, services.get_ledger(session["user"], int(match.group(1))))
            return

        if match and method == "PATCH":
            session = self._require_session("counselor")
            self._check_mutation(session)
            payload = self._read_json()
            self._send_json(200, services.update_ledger(
                session["user"], int(match.group(1)), payload
            ))
            return

        if path == "/api/counselor/audit" and method == "GET":
            session = self._require_session("counselor")
            self._send_json(200, services.audit_overview(session["user"]))
            return

        if path == "/api/counselor/audit/verify" and method == "POST":
            session = self._require_session("counselor")
            self._check_mutation(session)
            self._send_json(200, services.verify_chains(session["user"]))
            return

        match = re.fullmatch(r"/api/counselor/reports/student/(\d+)", path)
        if match and method == "POST":
            session = self._require_session("counselor")
            self._check_mutation(session)
            self._send_json(201, services.generate_student_report(
                session["user"], int(match.group(1))
            ))
            return

        if path == "/api/counselor/reports/class" and method == "POST":
            session = self._require_session("counselor")
            self._check_mutation(session)
            payload = self._read_json()
            self._send_json(201, services.generate_class_report(
                session["user"],
                int(payload["class_id"]) if payload.get("class_id") else None,
                int(payload.get("days") or 30),
            ))
            return

        # ---------------- 导出 ----------------
        if path == "/api/counselor/export/ledgers.xlsx" and method == "GET":
            session = self._require_session("counselor")
            rows, summary = services.export_ledgers(session["user"], self._ledger_filters(query))
            data = exports.ledger_workbook(rows, summary)
            name = f"智学_学工台账_{services.database.now_iso()[:10].replace('-', '')}.xlsx"
            self._send_bytes(
                200, data,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                extra_headers={
                    "Content-Disposition": _attachment(name, "zhixue-ledgers.xlsx"),
                    "Cache-Control": "no-store",
                },
            )
            return

        if path == "/api/counselor/export/ledgers.pdf" and method == "GET":
            session = self._require_session("counselor")
            rows, summary = services.export_ledgers(session["user"], self._ledger_filters(query))
            html_text = exports.ledgers_html(rows, summary)
            self._send_pdf_bytes(html_text, "智学_学工台账.pdf", "zhixue-ledgers.pdf")
            return

        if path == "/api/counselor/export/report.pdf" and method == "GET":
            session = self._require_session("counselor")
            report_type = self._query_one(query, "type", "student")
            target_id = self._query_int(query, "id") or 0
            report = services.export_report(
                session["user"], report_type, target_id,
                class_id=self._query_int(query, "class_id"),
            )
            self._send_report_pdf(report, fallback=f"zhixue-{report_type}-report.pdf")
            return

        raise not_found("接口不存在")

    # ------------------------------------------------------------------
    # 打印视图（PDF 导出失败时的降级方案）
    # ------------------------------------------------------------------
    def _handle_print(self, path: str, query: dict[str, list[str]], head: bool = False) -> None:
        session = self._require_session()
        if path == "/print/report":
            report_type = self._query_one(query, "type", "student")
            if report_type == "class":
                report = services.build_class_report(
                    session["user"], self._query_int(query, "class_id") or None,
                    int(self._query_one(query, "days", "30")),
                )
            else:
                target = self._query_int(query, "id") or session["user"]["id"]
                report = services.build_student_report(session["user"], target)
            self._send_bytes(
                200, exports.report_html(report).encode("utf-8"),
                "text/html; charset=utf-8", head=head,
            )
            return
        if path == "/print/ledgers":
            rows, summary = services.export_ledgers(session["user"], self._ledger_filters(query))
            self._send_bytes(
                200, exports.ledgers_html(rows, summary).encode("utf-8"),
                "text/html; charset=utf-8", head=head,
            )
            return
        raise not_found("打印页面不存在")

    def _send_report_pdf(self, report: dict, fallback: str) -> None:
        html_text = exports.report_html(report)
        name = f"{report.get('code') or '智学报告'}_{report.get('title') or '学情报告'}.pdf"
        self._send_pdf_bytes(html_text, name, fallback)

    def _send_pdf_bytes(self, html_text: str, name: str, fallback: str) -> None:
        data = exports.html_to_pdf(html_text)
        if not data:
            raise AppError(
                503,
                "PDF_UNAVAILABLE",
                "本机未找到可用的 Edge/Chrome，已切换为打印视图：请在新窗口使用“打印 → 另存为 PDF”。",
            )
        self._send_bytes(
            200, data, "application/pdf",
            extra_headers={
                "Content-Disposition": _attachment(exports.safe_filename(name), fallback),
                "Cache-Control": "no-store",
            },
        )

    def _ledger_filters(self, query: dict[str, list[str]]) -> dict[str, Any]:
        return {
            "q": self._query_one(query, "q", ""),
            "intent": self._query_one(query, "intent", ""),
            "status": self._query_one(query, "status", ""),
            "course": self._query_one(query, "course", ""),
            "from": self._query_one(query, "from", ""),
            "to": self._query_one(query, "to", ""),
            "class_id": self._query_one(query, "class_id", ""),
            "page": self._query_one(query, "page", "1"),
            "page_size": self._query_one(query, "page_size", "10"),
        }

    # ------------------------------------------------------------------
    # 会话与请求工具
    # ------------------------------------------------------------------
    def _session_token(self) -> str | None:
        raw = self.headers.get("Cookie")
        if not raw:
            return None
        cookie = SimpleCookie()
        try:
            cookie.load(raw)
        except Exception:
            return None
        morsel = cookie.get(config.SESSION_COOKIE)
        return morsel.value if morsel else None

    def _get_session(self) -> dict[str, Any] | None:
        return services.get_session(self._session_token())

    def _require_session(self, role: str | None = None) -> dict[str, Any]:
        session = self._get_session()
        if not session:
            raise unauthorized()
        services.require_role(session["user"], role)
        return session

    def _check_origin(self) -> None:
        origin = self.headers.get("Origin")
        if not origin:
            return
        parsed = urllib.parse.urlsplit(origin)
        host = (self.headers.get("Host") or "").lower()
        if parsed.netloc.lower() != host:
            raise AppError(403, "BAD_ORIGIN", "请求来源不合法")

    def _check_mutation(self, session: dict[str, Any]) -> None:
        self._check_origin()
        supplied = self.headers.get("X-CSRF-Token", "")
        if not supplied or not hmac.compare_digest(supplied, session["csrf"]):
            raise AppError(403, "BAD_CSRF", "页面安全令牌已失效，请刷新后重试")

    def _read_json(self) -> dict[str, Any]:
        if getattr(self, "_json_cache", None) is not None:
            return self._json_cache
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError as exc:
            raise bad_request("请求长度不正确") from exc
        if length > config.MAX_JSON_BYTES:
            raise AppError(413, "PAYLOAD_TOO_LARGE", "请求内容过大")
        raw = self.rfile.read(length) if length else b""
        if not raw:
            self._json_cache = {}
            return self._json_cache
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise bad_request("请求 JSON 格式不正确") from exc
        if not isinstance(payload, dict):
            raise bad_request("请求体必须是 JSON 对象")
        self._json_cache = payload
        return payload

    @staticmethod
    def _query_one(query: dict[str, list[str]], name: str, default: str) -> str:
        values = query.get(name)
        return values[0].strip() if values else default

    @staticmethod
    def _query_int(query: dict[str, list[str]], name: str) -> int | None:
        values = query.get(name)
        if not values:
            return None
        try:
            return int(values[0])
        except (TypeError, ValueError):
            return None

    def _set_session_cookie(self, token: str) -> None:
        parts = [
            f"{config.SESSION_COOKIE}={token}",
            "Path=/",
            "HttpOnly",
            "SameSite=Lax",
            f"Max-Age={config.SESSION_DAYS * 86400}",
        ]
        if _safe_bool(os.environ.get("CLASSROOM_COOKIE_SECURE"), False):
            parts.append("Secure")
        self._pending_cookie = "; ".join(parts)

    def _clear_session_cookie(self) -> None:
        self._pending_cookie = (
            f"{config.SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0"
        )

    # ------------------------------------------------------------------
    # 静态资源
    # ------------------------------------------------------------------
    def _serve_static(self, path: str, head: bool = False) -> None:
        if path == "/favicon.ico":
            self._send_file(config.STATIC_DIR / "favicon.svg", "image/svg+xml", cache="public, max-age=86400")
            return
        if path in PAGES:
            self._send_file(config.STATIC_DIR / PAGES[path], "text/html; charset=utf-8", cache="no-cache")
            return
        if path.startswith("/static/"):
            relative = path[len("/static/"):]
            self._send_file_from(config.STATIC_DIR, relative, cache="no-cache")
            return
        raise not_found("页面不存在")

    def _send_file_from(self, root: Path, relative: str, cache: str = "no-store") -> None:
        try:
            relative = urllib.parse.unquote(relative)
        except Exception:
            raise not_found("文件不存在")
        if not relative or "\x00" in relative:
            raise not_found("文件不存在")
        target = (root / relative).resolve()
        root = root.resolve()
        if target != root and root not in target.parents:
            raise not_found("文件不存在")
        if any(part.startswith(".") for part in target.relative_to(root).parts):
            raise not_found("文件不存在")
        if not target.is_file():
            raise not_found("文件不存在")
        self._send_file(target, cache=cache)

    def _send_file(self, target: Path, content_type: str | None = None, cache: str = "no-store") -> None:
        if not target.is_file():
            raise not_found("文件不存在")
        data = target.read_bytes()
        if content_type is None:
            content_type = STATIC_TYPES.get(target.suffix.lower(), "application/octet-stream")
        self._send_bytes(200, data, content_type, extra_headers={"Cache-Control": cache})

    # ------------------------------------------------------------------
    # 响应
    # ------------------------------------------------------------------
    def _security_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")

    def _send_json(self, status: int, payload: dict[str, Any], head: bool = False) -> None:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self._send_bytes(
            status, body, "application/json; charset=utf-8",
            extra_headers={"Cache-Control": "no-store"},
            head=head, cookie=getattr(self, "_pending_cookie", None),
        )

    def _send_bytes(
        self,
        status: int,
        body: bytes,
        content_type: str,
        *,
        extra_headers: dict[str, str] | None = None,
        head: bool = False,
        cookie: str | None = None,
    ) -> None:
        self.send_response(status)
        self._security_headers()
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        if extra_headers:
            for key, value in extra_headers.items():
                self.send_header(key, value)
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        if not head and body:
            self.wfile.write(body)

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stderr.write(
            "[%s] %s %s\n" % (self.log_date_time_string(), self.client_address[0], fmt % args)
        )


class ZhixueServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request: Any, client_address: Any) -> None:
        import sys as _sys

        error = _sys.exc_info()[1]
        if isinstance(error, (ConnectionResetError, BrokenPipeError)):
            return
        super().handle_error(request, client_address)


def create_server(host: str = config.HOST, port: int = config.PORT) -> ZhixueServer:
    return ZhixueServer((host, port), ZhixueHandler)
