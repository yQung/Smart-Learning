"""兼容旧启动脚本的占位模块。

新平台不再依赖 3D 模型资料库，但 ``app.py`` 启动横幅仍会调用
``service_status()``，这里保持一个永远离线的最小实现。
"""
from __future__ import annotations

from typing import Any


def service_status(force: bool = False) -> dict[str, Any]:
    return {
        "online": False,
        "url": "",
        "total": 0,
        "message": "本产品不依赖 3D 模型服务",
    }


def list_models(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"items": [], "total": 0}


def get_model(*args: Any, **kwargs: Any):  # pragma: no cover - 兼容占位
    return None


def asset_bytes(*args: Any, **kwargs: Any):  # pragma: no cover - 兼容占位
    return None
