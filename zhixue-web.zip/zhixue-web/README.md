# 智学网页版

这是“智学 · AI 学情诊断与学工辅助平台”的可部署网页版本。原有学生端、辅导员端、学情诊断、资源学习、台账、审计链、XLSX/PDF 导出功能均保留。

## 演示账号

| 角色 | 账号 | 密码 |
| --- | --- | --- |
| 学生 | `20240101` | `Student123!` |
| 辅导员 | `counselor` | `Counselor123!` |

演示账号已显示在登录页，访客可点击自动填入。平台内是合成演示数据，请勿上传或录入真实学生隐私信息。

## 最快上线：GitHub + Render

1. 在 GitHub 新建一个空仓库。
2. 将本目录中的全部文件上传到仓库根目录。Dockerfile、`render.yaml` 和 `zhixue/` 必须处于同一级。
3. 登录 [Render](https://dashboard.render.com/)，选择 **New → Blueprint**。
4. 连接刚才的 GitHub 仓库。Render 会读取 `render.yaml` 并创建 Web Service。
5. 等待首次 Docker 构建完成，使用生成的 `https://...onrender.com` 地址分享给任何人。

首次部署通常需要几分钟，因为镜像会安装 Chromium 和中文字体，以便在线导出 PDF。

## 数据保留说明

默认配置使用免费实例的临时磁盘。平台每次新部署或实例重建时会自动创建一套完好的演示数据，但访客新增的问诊、台账和报告可能随实例重建而重置。

如果希望长期保留数据：

1. 在 Render 将 Web Service 升级到支持 Persistent Disk 的套餐。
2. 添加磁盘并挂载到 `/var/data`。
3. 新增环境变量 `CLASSROOM_DATA_DIR=/var/data`。

SQLite 适合低并发的展示与试用。面向真实学校长期运营时，应改用托管 PostgreSQL、独立对象存储、真实身份认证及隐私合规流程。

## 可选：接入 DeepSeek

不配置模型密钥也能使用内置学情推理引擎。若要叠加 DeepSeek：

在 Render 的环境变量中添加：

```text
CLASSROOM_LLM_API_KEY=你的密钥
CLASSROOM_LLM_BASE=https://api.deepseek.com
CLASSROOM_LLM_MODEL=deepseek-chat
```

不要在代码或 GitHub 仓库中提交密钥。

## 本地验证

使用 Python 3.10+：

```powershell
$env:CLASSROOM_COOKIE_SECURE="false"
python -u zhixue\run.py --host 127.0.0.1 --port 8765 --open
```

打开 <http://127.0.0.1:8765>。停止服务按 `Ctrl+C`。

## Docker 部署

```powershell
docker build -t zhixue-web .
docker run --rm -p 8765:8765 -e PORT=8765 zhixue-web
```

再访问 <http://127.0.0.1:8765>。

## 公网使用边界

- 当前版本适合作品展示、演示和试用。
- 公开演示账号可以查看与修改同一套合成数据，不适合当作正式校园生产系统。
- 正式发布前应更换演示密码、增加注册/身份体系、配置数据备份和隐私告知。
- 使用自有域名时，请保持 HTTPS，并继续设置 `CLASSROOM_COOKIE_SECURE=true`。
